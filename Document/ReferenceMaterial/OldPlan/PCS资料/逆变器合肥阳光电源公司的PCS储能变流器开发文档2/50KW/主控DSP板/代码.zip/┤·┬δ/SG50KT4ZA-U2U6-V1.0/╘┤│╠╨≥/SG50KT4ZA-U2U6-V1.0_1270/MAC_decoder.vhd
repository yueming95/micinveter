-- Header Begin
--
-- According to the signals of three input pin, get the local MAC address. 
--
-- Wang zhihua
-- Last Updated 01/27/2007
--
-- Header End
LIBRARY IEEE;
USE ieee.STD_LOGIC_ARITH.all;
USE ieee.std_logic_1164.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY MAC_decoder IS
PORT(
		MAC_addr_set		:in std_logic_vector(2 downto 0); 
		MAC_addr			:out std_logic_vector(7 downto 0)--local mac addr
);
END MAC_decoder;

ARCHITECTURE RTL1 OF MAC_decoder IS 

BEGIN

	MAC_addr<="11111110" when MAC_addr_set="000" else
	"11111101" when MAC_addr_set="001" else
	"11111011" when MAC_addr_set="010" else
	"11110111" when MAC_addr_set="011" else
	"11101111" when MAC_addr_set="100" else
	"11011111" when MAC_addr_set="101" else
	"10111111" when MAC_addr_set="110" else
	"01111111" ;

END RTL1;



