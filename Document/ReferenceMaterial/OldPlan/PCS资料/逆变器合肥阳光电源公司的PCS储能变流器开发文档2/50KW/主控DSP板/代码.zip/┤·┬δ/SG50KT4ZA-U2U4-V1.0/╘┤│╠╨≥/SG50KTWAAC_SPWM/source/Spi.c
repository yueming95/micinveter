#define spi_GLOBALS
#include "Spi.h"
#include "corecontrol.h"
void  SPI_ACT()
{
	int16	i16IntCount_0;
	volatile int16	i16IntTemp_0;
	
	//-----SPI1-----
	GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;
	GpioDataRegs.GPACLEAR.bit.GPIO1 = 1;
	GpioDataRegs.GPACLEAR.bit.GPIO9 = 1;	    			// IO910=000
    SpibRegs.SPITXBUF = BitSignalout1.all;
	
    	//-----SPI1-----
    	
    	//-----SPI2-----
    	for(i16IntCount_0=0; ((i16IntCount_0<30)&&(SpibRegs.SPISTS.bit.INT_FLAG==0)); i16IntCount_0++)
	{
			asm(" NOP");								// ���ȴ�3.63us
	}
    	BitSignalin1.all = SpibRegs.SPIRXBUF;
    	GpioDataRegs.GPASET.bit.GPIO0 = 1;		    			// IO910=001
    	SpibRegs.SPITXBUF = BitSignalout2.all;
    	//-----SPI2-----

	//-----SPI3-----
    	for(i16IntCount_0=0;((i16IntCount_0<30)&&(SpibRegs.SPISTS.bit.INT_FLAG==0));i16IntCount_0++)
	{
		asm(" NOP");								// ���ȴ�3.63us
	}
    	BitSignalin2.all = SpibRegs.SPIRXBUF;
    	GpioDataRegs.GPASET.bit.GPIO1 = 1;		    			// IO910=011
    	SpibRegs.SPITXBUF = BitSignalout4.all;
    	//-----SPI3-----

	//------SPI4-----
    	for(i16IntCount_0=0;((i16IntCount_0<30)&&(SpibRegs.SPISTS.bit.INT_FLAG==0));i16IntCount_0++)
	{
		asm(" NOP");								// ���ȴ�3.63us
	}
    	BitSignalin4.all = SpibRegs.SPIRXBUF;
    	GpioDataRegs.GPACLEAR.bit.GPIO0 = 1;					// IO910=010
    	SpibRegs.SPITXBUF = BitSignalout3.all;
    	//------SPI4-----

	//-----SPI5-----
    	for(i16IntCount_0=0;((i16IntCount_0<30)&&(SpibRegs.SPISTS.bit.INT_FLAG==0));i16IntCount_0++)
	{
		asm(" NOP");								// ���ȴ�3.63us
	}
    	BitSignalin3.all = SpibRegs.SPIRXBUF;
    	GpioDataRegs.GPASET.bit.GPIO9 = 1;	    				// IO910=1XX
    	SpibRegs.SPITXBUF = BitSignalout5.all;
    	//-----SPI5-----

	//-----SPI6-----
    	for(i16IntCount_0=0;((i16IntCount_0<30)&&(SpibRegs.SPISTS.bit.INT_FLAG==0));i16IntCount_0++)
	{
		asm("NOP");								// ���ȴ�3.63us
	}
    	i16IntTemp_0 = SpibRegs.SPIRXBUF;
    	//-----SPI6-----	
}

void DigitalOper()
{
	if((ProtectRegs.all & 0x0000ffff)>0)
	{
		BitSignal.bit.bFaultInd=0;                  // �����
	}else
	{
		BitSignal.bit.bFaultInd=1;     // �����
	}
	if(StateRegs.bit.binv==3)
	{
		BitSignal.bit.bNormalInd=0;   // �̵���
	}else
	{
		BitSignal.bit.bNormalInd=1;  // �̵���
	}
	BitSignalout1.bit.bINVKM=BitSignalout2.bit.bINVKM=BitSignalout3.bit.bINVKM=BitSignal.bit.bInvKM;
	BitSignalout1.bit.bREV02=BitSignalout2.bit.bREV1=BitSignalout3.bit.bREV1=BitSignal.bit.bModuleReadyOk;
	BitSignalout1.bit.bNormalInd=BitSignal.bit.bNormalInd;
	BitSignalout1.bit.bFaultInd=BitSignal.bit.bFaultInd;
	if((ProtectIn.all & 0x0002f5bf)>0)
	{
		BitSignalout4.bit.bINV_STATE=0;  // AC������ش󱣻�����ֹDC�࿪��
	}else
	{
		BitSignalout4.bit.bINV_STATE=1;  // AC�����ش󱣻�������DC�࿪��
	}
	BitSignalout5.bit.bInvNA = BitSignal.bit.bInvOffToDCDC;	//���չ����жϱ�־Ϊ���߼�|objOutput.m_st_FlagMasToMod.bMasAllOff     laoa change 20130819
	/*if((StateRegs.bit.binvbark != 0) && (StateRegs.bit.binv == 0))
	{
		BitSignal.bit.bInvOffToDCDC = 1;
		SysCnt.InvOff=TM3S;
	}else
	{
		
		if(SysCnt.InvOff>0)
		{
			SysCnt.InvOff--;
		}else
		{
			BitSignal.bit.bInvOffToDCDC = 0;
		}
	}
	StateRegs.bit.binvbark=StateRegs.bit.binv;*/
	if(StateRegs.bit.binv==0)
	{
		BitSignal.bit.bInvOffToDCDC = 1;
	}else
	{
		BitSignal.bit.bInvOffToDCDC = 0;
	}
}
