// TI File $Revision: /main/4 $
// Checkin $Date: August 2, 2006   13:51:13 $
//###########################################################################
//
// FILE:   DSP280x_EPwm.c
//
// TITLE:  DSP280x ePWM Initialization & Support Functions.
//
//###########################################################################
// $TI Release: DSP280x Header Files V1.60 $
// $Release Date: December 3, 2007 $
//###########################################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File
#include "DSP280x_Examples.h"   // DSP280x Examples Include File
#include "Spi.h"
#define KIntPrdCnst 4167
#define KSwPrdCnst  4167
#pragma CODE_SECTION(Drv_PWMInactive, "ramfuncs");
#pragma CODE_SECTION(Drv_PWMActive, "ramfuncs");
//---------------------------------------------------------------------------
// InitEPwm: 
//---------------------------------------------------------------------------
// This function initializes the ePWM(s) to a known state.
//
void InitEPwm(void)
{
   // Initialize ePWM1/2/3/4/5/6

	EALLOW;
	EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPWM1A = High state)
	EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPWM1B = High state)
	EPwm1Regs.TZFRC.bit.OST = 1;					// Forces a fault on the OST latch and sets the OSTFLG bit.
	EDIS;
    EPwm1Regs.TBPRD = KIntPrdCnst;       	     	// Int Period Counter
    EPwm1Regs.CMPA.half.CMPA = KSwPrdCnst;  			// KSwPrdCnst
    EPwm1Regs.TBCTL.bit.CTRMODE = TB_UP_DOWN;
    EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;      	// Phase loading disabled
    EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;  	// PWM1���㷢ͬ���ź�
    EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;     	// TBCLK = SYSCLK
    EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm1Regs.AQCTLA.bit.CAU = AQ_CLEAR;           	// CNT = CMP up   ->1
    EPwm1Regs.AQCTLA.bit.CAD = AQ_SET;         		// CNT = CMP down ->0
    EPwm1Regs.AQCTLB.bit.CAU = AQ_CLEAR;         	// CNT = CMP up   ->0
    EPwm1Regs.AQCTLB.bit.CAD = AQ_SET;           	// CNT = CMP down ->1
   	EPwm1Regs.AQSFRC.bit.RLDCSF = 3;		        // the active register load immediately
   	EPwm1Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;		// Software forcing disabled, i.e., has no effect
	EPwm1Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;
    EPwm1Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm1Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
    EPwm1Regs.DBRED = KDeadTimeCnst;
    EPwm1Regs.DBFED = KDeadTimeCnst;
    EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     	// �����ж�
    EPwm1Regs.ETSEL.bit.INTEN = 1;
    EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;

    EALLOW;
	EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPWM2A = High state)
	EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPWM2B = High state)
	EPwm2Regs.TZFRC.bit.OST = 1;					// Forces a fault on the OST latch and sets the OSTFLG bit.
	EDIS;
    EPwm2Regs.TBPRD = KSwPrdCnst;                	// Switch Period Counter
    EPwm2Regs.CMPA.half.CMPA = KSwPrdCnst>>2;    	// KSwPrdCnst/4
    EPwm2Regs.TBCTL.bit.CTRMODE = TB_UP_DOWN;
    EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;       	// Phase loading disabled
    EPwm2Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;   	// PWM2����ͬ���źŲ���Ϊ���
    EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;     	// TBCLK = SYSCLK
    EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm2Regs.AQCTLA.bit.CAU = AQ_CLEAR;           	// CNT = CMP up   ->1
    EPwm2Regs.AQCTLA.bit.CAD = AQ_SET;         		// CNT = CMP down ->0
    EPwm2Regs.AQCTLB.bit.CAU = AQ_CLEAR;         	// CNT = CMP up   ->0
    EPwm2Regs.AQCTLB.bit.CAD = AQ_SET;           	// CNT = CMP down ->1
   	EPwm2Regs.AQSFRC.bit.RLDCSF = 3;		        // the active register load immediately
   	EPwm2Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;		// Software forcing disabled, i.e., has no effect
	EPwm2Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;
    EPwm2Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm2Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
    EPwm2Regs.DBRED = KDeadTimeCnst;				//	1uS
    EPwm2Regs.DBFED = KDeadTimeCnst;

 	EALLOW;
	EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPWM3A = High state)
	EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPWM3B = High state)
	EPwm3Regs.TZFRC.bit.OST = 1;					// Forces a fault on the OST latch and sets the OSTFLG bit.
	EDIS;
    EPwm3Regs.TBPRD = KSwPrdCnst;                   // Switch Period Counter
    EPwm3Regs.CMPA.half.CMPA = KSwPrdCnst>>1;   	// KSwPrdCnst/2
    EPwm3Regs.TBCTL.bit.CTRMODE = TB_UP_DOWN;
    EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;       	// Phase loading enabled
    EPwm3Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;   	// PWM3����ͬ���źŲ���Ϊ���
    EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;     	// TBCLK = SYSCLK
    EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm3Regs.AQCTLA.bit.CAU = AQ_CLEAR;           	// CNT = CMP up   ->1
    EPwm3Regs.AQCTLA.bit.CAD = AQ_SET;         		// CNT = CMP down ->0
    EPwm3Regs.AQCTLB.bit.CAU = AQ_CLEAR;         	// CNT = CMP up   ->0
    EPwm3Regs.AQCTLB.bit.CAD = AQ_SET;           	// CNT = CMP down ->1
   	EPwm3Regs.AQSFRC.bit.RLDCSF = 3;		        // the active register load immediately
   	EPwm3Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;		// Software forcing disabled, i.e., has no effect
	EPwm3Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;
    EPwm3Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm3Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
    EPwm3Regs.DBRED = KDeadTimeCnst;				//	1uS
    EPwm3Regs.DBFED = KDeadTimeCnst;

    EALLOW;
	EPwm4Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPwm4A = High state)
	EPwm4Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPwm4B = High state)
	EPwm4Regs.TZFRC.bit.OST = 1;					// Forces a fault on the OST latch and sets the OSTFLG bit.
	EDIS;
    EPwm4Regs.TBPRD = KSwPrdCnst;                   // Switch Period Counter
    EPwm4Regs.CMPA.half.CMPA = (KSwPrdCnst*3)>>2;   // KSwPrdCnst*3/4
    EPwm4Regs.TBCTL.bit.CTRMODE = TB_UP_DOWN;
    EPwm4Regs.TBCTL.bit.PHSEN = TB_ENABLE;       	// Phase loading enabled
    EPwm4Regs.TBCTL.bit.PRDLD = TB_SHADOW;
    EPwm4Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;   	// PWM3����ͬ���źŲ���Ϊ���
    EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;     	// TBCLK = SYSCLK
    EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV1;
    EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
    EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
    EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;           	// CNT = CMP up   ->1
    EPwm4Regs.AQCTLA.bit.CAD = AQ_SET;         		// CNT = CMP down ->0
    EPwm4Regs.AQCTLB.bit.CAU = AQ_CLEAR;         	// CNT = CMP up   ->0
    EPwm4Regs.AQCTLB.bit.CAD = AQ_SET;           	// CNT = CMP down ->1
   	EPwm4Regs.AQSFRC.bit.RLDCSF = 3;		        // the active register load immediately
   	EPwm4Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;		// Software forcing disabled, i.e., has no effect
	EPwm4Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;
    EPwm4Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
    EPwm4Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
    EPwm4Regs.DBRED = KDeadTimeCnst;				//1uS
    EPwm4Regs.DBFED = KDeadTimeCnst;

    EALLOW;
	EPwm6Regs.TZCTL.bit.TZA = TZ_FORCE_LO;			// Forced high (EPWM6A = low state)
	EPwm6Regs.TZCTL.bit.TZB = TZ_FORCE_LO;			// Forced high (EPWM6B = low state)
	EPwm6Regs.TZFRC.bit.OST = 1;					// Forces a fault on the OST latch and sets the OSTFLG bit.
	EDIS;
	EPwm6Regs.TBPRD = 30000;       	     			// 30000*32*10*10ns=96ms
	EPwm6Regs.CMPB = 2500;  						// TBPRD,[3906*2,2232*2]=[40Hz,70Hz]
	EPwm6Regs.TBCTL.bit.CTRMODE = TB_COUNT_UP;
	EPwm6Regs.TBCTL.bit.PHSEN = TB_DISABLE;       	// Phase loading disabled
	EPwm6Regs.TBCTL.bit.PRDLD = TB_IMMEDIATE;
	EPwm6Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_DISABLE;	// DISABLE
	EPwm6Regs.TBCTL.bit.HSPCLKDIV = 5;     			// /10
	EPwm6Regs.TBCTL.bit.CLKDIV = 5;					// /32
	EPwm6Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;
	EPwm6Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
	EPwm6Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
	EPwm6Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;	// load on CTR = Zero or PRD
	EPwm6Regs.AQCTLA.bit.CAU = AQ_CLEAR;           	// CNT = CMP up   ->0
	EPwm6Regs.AQCTLA.bit.CAD = AQ_SET;         		// CNT = CMP down ->1
	EPwm6Regs.AQCTLB.bit.CBU = AQ_CLEAR;         	// CNT = CMP up   ->0
	EPwm6Regs.AQCTLB.bit.PRD = AQ_SET;           	// PRD		      ->1
	EPwm6Regs.AQSFRC.bit.RLDCSF = 3;		        // the active register load immediately
	EPwm6Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;		// Software forcing disabled, i.e., has no effect
	EPwm6Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;
	EPwm6Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;
	EPwm6Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
	EPwm6Regs.DBRED = 0;
	EPwm6Regs.DBFED = 0;

    EPwm1Regs.TBPHS.half.TBPHS = 0;              	// Set Phase register to zero
    EPwm2Regs.TBPHS.half.TBPHS = 0;              	// Set Phase register to zero
    EPwm3Regs.TBPHS.half.TBPHS = 0;              	// Set Phase register to zero
    EPwm4Regs.TBPHS.half.TBPHS = 0;              	// Set Phase register to zero
   	EPwm6Regs.TBPHS.half.TBPHS = 0;              	// Set Phase register to zero
    EPwm1Regs.TBCTR = 0;                         	// clear TB counter
    EPwm2Regs.TBCTR = 0;                         	// clear TB counter
    EPwm3Regs.TBCTR = 0;                         	// clear TB counter
    EPwm4Regs.TBCTR = 0;                         	// clear TB counter
    EPwm6Regs.TBCTR = 0;                         	// clear TB counter

}
void Drv_PWMInactive(void)    // ��pwm
{
		BitSignalout2.bit.bInvOffToCPLD = 0;
		GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;

		EALLOW;
		EPwm2Regs.TZFRC.bit.OST = 1;
		EPwm3Regs.TZFRC.bit.OST = 1;
		EPwm4Regs.TZFRC.bit.OST = 1;
		EDIS;

		EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPwm4A = High state)
		EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPwm4B = High state)
		EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPwm4A = High state)
		EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPwm4B = High state)
		EPwm4Regs.TZCTL.bit.TZA = TZ_FORCE_HI;			// Forced Hi (EPwm4A = High state)
		EPwm4Regs.TZCTL.bit.TZB = TZ_FORCE_HI;			// Forced Hi (EPwm4B = High state)
}
void Drv_PWMActive(void)   // ��pwm
{
	BitSignalout2.bit.bInvOffToCPLD = 0xE7;
	GpioDataRegs.GPBSET.bit.GPIO34 = 1;

	EALLOW;
	EPwm2Regs.TZCLR.bit.OST = 1;					// Clear Flag for One-Shot Trip (OST) Latch
	EPwm3Regs.TZCLR.bit.OST = 1;
	EPwm4Regs.TZCLR.bit.OST = 1;
	EDIS;
}
//---------------------------------------------------------------------------
// Example: InitEPwmGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as ePWM pins
//
// Each GPIO pin can be configured as a GPIO pin or up to 3 different
// peripheral functional pins. By default all pins come up as GPIO
// inputs after reset.  
// 

void InitEPwmGpio(void)
{
   InitEPwm1Gpio();
   InitEPwm2Gpio();
   InitEPwm3Gpio();
//#if DSP28_EPWM4
   InitEPwm4Gpio();
//#endif // endif DSP28_EPWM4
//#if DSP28_EPWM5    
   InitEPwm5Gpio();
//#endif // endif DSP28_EPWM5
//#if DSP28_EPWM6
   InitEPwm6Gpio();
//#endif // endif DSP28_EPWM6 
}

void InitEPwm1Gpio(void)
{
   EALLOW;
   
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO0 = 0;    // Enable pull-up on GPIO0 (EPWM1A)
    GpioCtrlRegs.GPAPUD.bit.GPIO1 = 0;    // Enable pull-up on GPIO1 (EPWM1B)   
   
/* Configure ePWM-1 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM1 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO0 = 1;   // Configure GPIO0 as EPWM1A
    GpioCtrlRegs.GPAMUX1.bit.GPIO1 = 1;   // Configure GPIO1 as EPWM1B
   
    EDIS;
}

void InitEPwm2Gpio(void)
{
   EALLOW;
	
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO2 = 0;    // Enable pull-up on GPIO2 (EPWM2A)
    GpioCtrlRegs.GPAPUD.bit.GPIO3 = 0;    // Enable pull-up on GPIO3 (EPWM3B)

/* Configure ePWM-2 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM2 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO2 = 1;   // Configure GPIO2 as EPWM2A
    GpioCtrlRegs.GPAMUX1.bit.GPIO3 = 1;   // Configure GPIO3 as EPWM2B
   
    EDIS;
}

void InitEPwm3Gpio(void)
{
   EALLOW;
   
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO4 = 0;    // Enable pull-up on GPIO4 (EPWM3A)
    GpioCtrlRegs.GPAPUD.bit.GPIO5 = 0;    // Enable pull-up on GPIO5 (EPWM3B)
       
/* Configure ePWM-3 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM3 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO4 = 1;   // Configure GPIO4 as EPWM3A
    GpioCtrlRegs.GPAMUX1.bit.GPIO5 = 1;   // Configure GPIO5 as EPWM3B
	
    EDIS;
}


//#if DSP28_EPWM4
void InitEPwm4Gpio(void)
{
   EALLOW;
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;    // Enable pull-up on GPIO6 (EPWM4A)
    GpioCtrlRegs.GPAPUD.bit.GPIO7 = 0;    // Enable pull-up on GPIO7 (EPWM4B)

/* Configure ePWM-4 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM4 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 1;   // Configure GPIO6 as EPWM4A
    GpioCtrlRegs.GPAMUX1.bit.GPIO7 = 1;   // Configure GPIO7 as EPWM4B
	
    EDIS;
}
//#endif // endif DSP28_EPWM4  


//#if DSP28_EPWM5
void InitEPwm5Gpio(void)
{
   EALLOW;
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO8 = 0;    // Enable pull-up on GPIO8 (EPWM5A)
    GpioCtrlRegs.GPAPUD.bit.GPIO9 = 0;    // Enable pull-up on GPIO9 (EPWM5B)

/* Configure ePWM-5 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM5 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO8 = 1;   // Configure GPIO8 as EPWM5A
    GpioCtrlRegs.GPAMUX1.bit.GPIO9 = 1;   // Configure GPIO9 as EPWM5B
	
    EDIS;
}
//#endif // endif DSP28_EPWM5


//#if DSP28_EPWM6
void InitEPwm6Gpio(void)
{
   EALLOW;

/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAPUD.bit.GPIO10 = 0;    // Enable pull-up on GPIO10 (EPWM6A)
    GpioCtrlRegs.GPAPUD.bit.GPIO11 = 0;    // Enable pull-up on GPIO11 (EPWM6B)

/* Configure ePWM-6 pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be ePWM6 functional pins.
// Comment out other unwanted lines.

    GpioCtrlRegs.GPAMUX1.bit.GPIO10 = 1;   // Configure GPIO10 as EPWM6A
    GpioCtrlRegs.GPAMUX1.bit.GPIO11 = 1;   // Configure GPIO11 as EPWM6B
	
    EDIS;
}
//#endif // endif DSP28_EPWM6  

//---------------------------------------------------------------------------
// Example: InitEPwmSyncGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as ePWM Synch pins
//

void InitEPwmSyncGpio(void)
{

   EALLOW;

/* Configure EPWMSYNCI  */
   
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

   GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;    // Enable pull-up on GPIO6 (EPWMSYNCI)
// GpioCtrlRegs.GPBPUD.bit.GPIO32 = 0;   // Enable pull-up on GPIO32 (EPWMSYNCI)    

/* Set qualification for selected pins to asynch only */
// This will select synch to SYSCLKOUT for the selected pins.
// Comment out other unwanted lines.

   GpioCtrlRegs.GPAQSEL1.bit.GPIO6 = 0;   // Synch to SYSCLKOUT GPIO6 (EPWMSYNCI)
// GpioCtrlRegs.GPBQSEL1.bit.GPIO32 = 0;  // Synch to SYSCLKOUT GPIO32 (EPWMSYNCI)    

/* Configure EPwmSync pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be EPwmSync functional pins.
// Comment out other unwanted lines.   

   GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 2;    // Enable pull-up on GPIO6 (EPWMSYNCI)
// GpioCtrlRegs.GPBMUX1.bit.GPIO32 = 2;   // Enable pull-up on GPIO32 (EPWMSYNCI)    



/* Configure EPWMSYNC0  */

/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.

// GpioCtrlRegs.GPAPUD.bit.GPIO6 = 0;    // Enable pull-up on GPIO6 (EPWMSYNC0)
   GpioCtrlRegs.GPBPUD.bit.GPIO33 = 0;   // Enable pull-up on GPIO33 (EPWMSYNC0)    

// GpioCtrlRegs.GPAMUX1.bit.GPIO6 = 3;    // Enable pull-up on GPIO6 (EPWMSYNC0)
   GpioCtrlRegs.GPBMUX1.bit.GPIO33 = 2;   // Enable pull-up on GPIO33 (EPWMSYNC0)    

}



//---------------------------------------------------------------------------
// Example: InitTzGpio: 
//---------------------------------------------------------------------------
// This function initializes GPIO pins to function as Trip Zone (TZ) pins
//
// Each GPIO pin can be configured as a GPIO pin or up to 3 different
// peripheral functional pins. By default all pins come up as GPIO
// inputs after reset.  
// 

void InitTzGpio(void)
{
   EALLOW;
   
/* Enable internal pull-up for the selected pins */
// Pull-ups can be enabled or disabled by the user. 
// This will enable the pullups for the specified pins.
// Comment out other unwanted lines.
   GpioCtrlRegs.GPAPUD.bit.GPIO12 = 0;    // Enable pull-up on GPIO12 (TZ1)
   GpioCtrlRegs.GPAPUD.bit.GPIO13 = 0;    // Enable pull-up on GPIO13 (TZ2)
   GpioCtrlRegs.GPAPUD.bit.GPIO14 = 0;    // Enable pull-up on GPIO14 (TZ3)
   GpioCtrlRegs.GPAPUD.bit.GPIO15 = 0;    // Enable pull-up on GPIO15 (TZ4)

   GpioCtrlRegs.GPAPUD.bit.GPIO16 = 0;    // Enable pull-up on GPIO16 (TZ5)
// GpioCtrlRegs.GPAPUD.bit.GPIO28 = 0;    // Enable pull-up on GPIO28 (TZ5)

   GpioCtrlRegs.GPAPUD.bit.GPIO17 = 0;    // Enable pull-up on GPIO17 (TZ6) 
// GpioCtrlRegs.GPAPUD.bit.GPIO29 = 0;    // Enable pull-up on GPIO29 (TZ6)  
   
/* Set qualification for selected pins to asynch only */
// Inputs are synchronized to SYSCLKOUT by default.  
// This will select asynch (no qualification) for the selected pins.
// Comment out other unwanted lines.

   GpioCtrlRegs.GPAQSEL1.bit.GPIO12 = 3;  // Asynch input GPIO12 (TZ1)
   GpioCtrlRegs.GPAQSEL1.bit.GPIO13 = 3;  // Asynch input GPIO13 (TZ2)
   GpioCtrlRegs.GPAQSEL1.bit.GPIO14 = 3;  // Asynch input GPIO14 (TZ3)
   GpioCtrlRegs.GPAQSEL1.bit.GPIO15 = 3;  // Asynch input GPIO15 (TZ4)

   GpioCtrlRegs.GPAQSEL2.bit.GPIO16 = 3;  // Asynch input GPIO16 (TZ5)
// GpioCtrlRegs.GPAQSEL2.bit.GPIO28 = 3;  // Asynch input GPIO28 (TZ5)

   GpioCtrlRegs.GPAQSEL2.bit.GPIO17 = 3;  // Asynch input GPIO17 (TZ6) 
// GpioCtrlRegs.GPAQSEL2.bit.GPIO29 = 3;  // Asynch input GPIO29 (TZ6)  

   
/* Configure TZ pins using GPIO regs*/
// This specifies which of the possible GPIO pins will be TZ functional pins.
// Comment out other unwanted lines.   
   GpioCtrlRegs.GPAMUX1.bit.GPIO12 = 1;  // Configure GPIO12 as TZ1
   GpioCtrlRegs.GPAMUX1.bit.GPIO13 = 1;  // Configure GPIO13 as TZ2
   GpioCtrlRegs.GPAMUX1.bit.GPIO14 = 1;  // Configure GPIO14 as TZ3
   GpioCtrlRegs.GPAMUX1.bit.GPIO15 = 1;  // Configure GPIO15 as TZ4

   GpioCtrlRegs.GPAMUX2.bit.GPIO16 = 3;  // Configure GPIO16 as TZ5
// GpioCtrlRegs.GPAMUX2.bit.GPIO28 = 3;  // Configure GPIO28 as TZ5

   GpioCtrlRegs.GPAMUX2.bit.GPIO17 = 3;  // Configure GPIO17 as TZ6               
// GpioCtrlRegs.GPAMUX2.bit.GPIO29 = 3;  // Configure GPIO29 as TZ6  

   EDIS;
}



//===========================================================================
// End of file.
//===========================================================================
