################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
LIB_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/lib/IQmath.lib 


