################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Rec.cpp 

OBJS += \
./App/Rec.obj 

CPP_DEPS += \
./App/Rec.pp 

CPP_DEPS__QUOTED += \
"App\Rec.pp" 

OBJS__QUOTED += \
"App\Rec.obj" 

CPP_SRCS__QUOTED += \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Rec.cpp" 


