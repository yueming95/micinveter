################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/F2808.cmd 

LIB_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/rts2800_ml.lib 


