#include "stdlib.h"
#include "..\Driver\Drivers.h"
#include "Publics.h"
#include "Classes\Define.h"
//#include "SysCanDefine.h"
#include "Classes\SysCanDefine.h"


#include "Classes\DischargerAlgorithm.h"
#include "Classes\DCBus.h"
#include "Classes\Discharger.h"
#include "Classes\Battery.h"
#include "Classes\DigitalIO.h"
#include "Classes\LogicManager.h"
#include "Classes\EEPROM.h"
#include "Classes\Fan.h"
#include "Classes\System.h"
#include "Classes\MonInterface.h"
#include "Classes\Debug.h"
#include "Classes\FlashUpdate.h"

//#include "SCI\RecSCI.h"

#include "PrdInt.h"
//#include "SCIInt.h"

//----------
//#include "Classes\TemplateCmd.h"
//#include "Classes\TemplateQueue.h"
//#include "Classes\TemplateList.h"
//#include "Classes\SysCanProtocol.h"
//#include "Classes\SysCanApp.h"
//#include "Classes\SysCanDataExchg.h"
//#include "Classes\SysCanDefine.h"
//#include "Classes\SysCanQueue.h"
#include "Classes\SysCanNEW.h"
#include "Classes\SysDataExchgNEW.h"
#include "Classes\CanOpen.h"

//-----


#include "..\Driver\TI\2808Device.cpp"
#include "..\Driver\Drivers.cpp"

#include "..\Driver\GPIODrv.cpp"
#include "..\Driver\SCIDrv.cpp"
#include "..\Driver\SPIDrv.cpp"
#include "..\Driver\CANDrv.cpp"
#include "..\Driver\I2CDrv.cpp"
#include "..\Driver\ADCDrv.cpp"
#include "..\Driver\PWMDrv.cpp"
#include "..\Driver\CAPDrv.cpp"
#include "..\Driver\SysDrv.cpp"
#include "..\Driver\WatchDogDrv.cpp"
#include "..\Driver\RAMDrv.cpp"
#include "..\Driver\FlashDrv.cpp"
#include "..\Driver\TimerDrv.cpp"

#include "Publics.cpp"
//#include "SCI\RecSCI.CPP"

//#include "Classes\SysCanHal.cpp"
//#include "Classes\SysCanProtocol.cpp"
//#include "Classes\SysCanApp.cpp"
//#include "Classes\SysCanDataExchg.cpp"
#include "Classes\SysCanNEW.cpp"
#include "Classes\SysDataExchgNEW.cpp"
#include "Classes\CanOpen.cpp"



#include "Classes\DCBus.CPP"
#include "Classes\Battery.CPP"
#include "Classes\DigitalIO.CPP"
#include "Classes\EEPROM.CPP"
#include "Classes\Fan.CPP"
#include "Classes\System.CPP"
#include "Classes\DischargerAlgorithm.CPP"
#include "Classes\LogicManager.CPP"
#include "Classes\MonInterface.CPP"
#include "Classes\Debug.CPP"
#include "Classes\Discharger.CPP"
#include "Classes\FlashUpdate.CPP"

#include "CodeStartBranch.cpp"
#include "Main.cpp"
#include "PrdInt.cpp"
//#include "SCIInt.cpp"


