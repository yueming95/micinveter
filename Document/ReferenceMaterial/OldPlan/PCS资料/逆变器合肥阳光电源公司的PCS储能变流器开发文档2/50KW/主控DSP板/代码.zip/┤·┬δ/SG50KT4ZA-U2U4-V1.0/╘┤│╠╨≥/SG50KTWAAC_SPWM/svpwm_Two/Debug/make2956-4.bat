@echo off
echo 'Building file: E:/work/SG50KT4ZA/program/SG50KTWAAC_two/source/corecontrol.c'
