// ��  ��   ��:  CanOpen.cpp
// ��  ��   ��:  qtc
// ��������:  2011��08��17��
// ��           ��:  �����Э���ʵ��
//-------------------------------��ǰ�汾�޶�-------------------------------------------------
// ��  ��   ��: 
// �桡 	��: 
// �޸�����: 
// �衡 	��:
//=============================================================================================
#include "CanOpen.h"


PROTECT ProtectShow;


void CanOpen::CanDataPack()
{
	Uint16 temp;	
	InterfaceCan.SendL.all=ProtectShow.all;
	temp=objDischarger.m_i16_DischargerState_0;
	InterfaceCan.SendH.bit.Lbit=temp;
	
}
//unsigned char laoa001;
void CanOpen::CPHandleRecMsg()
{
	struct ECAN_REGS ECanaShadow;
	CanSendTime++;
	if(CanSendTime>=120)   // 10 ms
	{
	    CanSendTime=0;
		CanDataPack();
	//============������Ϣ===========================
		ECanaShadow.CANRMP.all = ECanaRegs.CANRMP.all;
		if (ECanaShadow.CANRMP.bit.RMP2 == 1)			//���յ���Ϣ
		{
			InterfaceCan.RdatL.all = ECanaMboxes.MBOX2.MDL.all;      
			InterfaceCan.RdatH.all = ECanaMboxes.MBOX2.MDH.all;
			ECanaShadow.CANRMP.bit.RMP2 = 1;
			ECanaRegs.CANRMP.all = ECanaShadow.CANRMP.all;
		}
//================������Ϣ����---------------------------
		if((InterfaceCan.RdatL.bit.Hbit & 0x0001)>0)
		{
			//laoa001++;
			objMonInterface.m_st_CtrlCmd_D.u16MasterInvOnCmd = 1;	
			objMonInterface.m_st_CtrlCmd_D.u16MasterInvOffCmd = 0;
		}else
		{
			objMonInterface.m_st_CtrlCmd_D.u16MasterInvOnCmd = 0;
			objMonInterface.m_st_CtrlCmd_D.u16MasterInvOffCmd = 1;		
		}
		if((InterfaceCan.RdatL.bit.Hbit & 0x0002)>0)
		{
			objMonInterface.m_st_RecCmdFlag.bReset=1;
		}else
		{
			objMonInterface.m_st_RecCmdFlag.bReset=0;
		}
		if((InterfaceCan.RdatL.bit.Hbit & 0x0004)>0)
		{
			objMonInterface.m_st_RecCmdFlag.FanUp=1;
		}else
		{
			objMonInterface.m_st_RecCmdFlag.FanUp=0;
		}
	//=============������Ϣ=============================
		ECanaMboxes.MBOX1.MDL.all = InterfaceCan.SendL.all;// & 0xffffff00)|CANHEAD; //CANHEAD���ڽ��շ�У���Ƿ��ܵ�������ȷ����
		ECanaMboxes.MBOX1.MDH.all=InterfaceCan.SendH.all;
		ECanaShadow.CANTRS.all = ECanaRegs.CANTRS.all;
		ECanaShadow.CANTRS.bit.TRS1=1;
		ECanaRegs.CANTRS.all = ECanaShadow.CANTRS.all;
		if (ECanaShadow.CANTA.bit.TA1 == 1)	//���ͳɹ�
		{		
			ECanaShadow.CANTA.bit.TA1 = 1;
			ECanaRegs.CANTA.all = ECanaShadow.CANTA.all;
		}
	}
}
//=================================================================================================
//														File End
//=================================================================================================

