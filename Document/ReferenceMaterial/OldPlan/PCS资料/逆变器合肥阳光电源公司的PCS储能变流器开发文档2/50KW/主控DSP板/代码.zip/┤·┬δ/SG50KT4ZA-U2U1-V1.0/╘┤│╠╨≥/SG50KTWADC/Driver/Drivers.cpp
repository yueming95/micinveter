/*==========================================================*/
/* Title		:	Drivers.cpp							*/
/* Description	: 	ControlChip definition					*/
/* Date			:	Oct.2007								*/
/*==========================================================*/


#include "Drivers.h"



 Class_ADCDrv objADCDrv;


 Class_CAPDrv objCAPDrv;
 Class_FlashDrv objFlashDrv;

 Class_GPIODrv objGPIODrv;
 Class_I2CDrv objI2CDrv;


 Class_PWMDrv objPWMDrv;
 Class_RAMDrv objRAMDrv;


 Class_SCIDrv objSCIDrv;
 Class_SPIDrv objSPIDrv;


 Class_SysDrv objSysDrv;
 Class_TimerDrv objTimerDrv;

 Class_WatchDogDrv objWatchDogDrv;

//============================================================
// End of file.
//============================================================
