#ifndef _PID_H
#define _PID_H
#include "IQmathLib.h"
#ifdef pid_GLOBALS
#define pid_GLOBALS
#else
#define pid_GLOBALS extern
#endif
//iq21 =-1024~1024
typedef struct
{
	_iq21 Kp;
	_iq21 Ki;
	_iq21 Out;
	_iq21 OutMax;
	_iq21 OutMin;
	_iq21 Err;
	_iq21 Kc;
	_iq21 Ref;
	_iq21 Tf;
	_iq21 Pi;
}PID;
void PidCalc(PID *v);
pid_GLOBALS PID QPid;
pid_GLOBALS PID DPid;
#endif

