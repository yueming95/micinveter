#ifndef _DQ_H
#define _DQ_H
#include "DSP280x_Device.h"
#include "IQmathLib.h"
#ifdef dq_GLOBALS
#define dq_GLOBALS
#else
#define dq_GLOBALS extern
#endif
typedef struct
{
	_iq Theta;
	_iq iqcos;
	_iq iqsin;
	_iq D;
	_iq Q;
	_iq Sa;
	_iq Sb;
	_iq Sc;
}CLARKEPARK;
void DQFun(CLARKEPARK *v);
#endif

