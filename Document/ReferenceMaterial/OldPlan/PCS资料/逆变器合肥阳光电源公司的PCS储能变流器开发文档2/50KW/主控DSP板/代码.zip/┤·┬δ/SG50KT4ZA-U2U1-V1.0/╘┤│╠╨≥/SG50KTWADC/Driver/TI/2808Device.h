//###########################################################################
//
// FILE:   2808Device.h
//
// TITLE:  DSP280x Device Definitions.
//
//###########################################################################
// $TI Release: DSP280x V1.20 $
// $Release Date: September 19, 2005 $
//###########################################################################
typedef interrupt void(*PINT)(void);

#ifndef DSP280x_DEVICE_H
#define DSP280x_DEVICE_H

#ifdef __cplusplus
extern "C" {
#endif




//---------------------------------------------------------------------------
// Include All Peripheral Header Files:


#include "Types.h" 

#include "Adc.h"                // ADC Registers
#include "DevEmu.h"             // Device Emulation Registers
#include "CpuTimers.h"          // 32-bit CPU Timers
#include "ECan.h"               // Enhanced eCAN Registers
#include "ECap.h"               // Enhanced Capture
#include "EPwm.h"               // Enhanced PWM 
#include "EQep.h"               // Enhanced QEP
#include "Gpio.h"               // General Purpose I/O Registers
#include "I2c.h"                // I2C Registers
#include "PieCtrl.h"            // PIE Control Registers
#include "PieVect.h"            // PIE Vector Table
#include "Spi.h"                // SPI Registers
#include "Sci.h"                // SCI Registers
#include "SysCtrl.h"            // System Control/Power Modes
#include "XIntrupt.h"           // External Interrupts




#define   TARGET   1
//---------------------------------------------------------------------------
// User To Select Target Device:

#define   DSP28_2808   TARGET
#define   DSP28_2806   0
#define   DSP28_2801   0

//---------------------------------------------------------------------------
// Common CPU Definitions:
//

extern cregister volatile unsigned int IFR;
extern cregister volatile unsigned int IER;



#define  EINT   asm(" clrc INTM")
#define  DINT   asm(" setc INTM")
#define  ERTM   asm(" clrc DBGM")
#define  DRTM   asm(" setc DBGM")
#define  EALLOW asm(" EALLOW")
#define  EDIS   asm(" EDIS")
#define  ESTOP0 asm(" ESTOP0")

#define M_INT1  0x0001
#define M_INT2  0x0002
#define M_INT3  0x0004
#define M_INT4  0x0008
#define M_INT5  0x0010
#define M_INT6  0x0020
#define M_INT7  0x0040
#define M_INT8  0x0080
#define M_INT9  0x0100
#define M_INT10 0x0200
#define M_INT11 0x0400
#define M_INT12 0x0800
#define M_INT13 0x1000
#define M_INT14 0x2000
#define M_DLOG  0x4000
#define M_RTOS  0x8000

#define BIT0    0x0001
#define BIT1    0x0002
#define BIT2    0x0004
#define BIT3    0x0008
#define BIT4    0x0010
#define BIT5    0x0020
#define BIT6    0x0040
#define BIT7    0x0080
#define BIT8    0x0100
#define BIT9    0x0200
#define BIT10   0x0400
#define BIT11   0x0800
#define BIT12   0x1000
#define BIT13   0x2000
#define BIT14   0x4000
#define BIT15   0x8000



//�� λ�� varx = varx|(SBIT9|SBIT8)
#define SBIT0		0x0001
#define SBIT1		0x0002
#define SBIT2		0x0004
#define SBIT3		0x0008
#define SBIT4		0x0010
#define SBIT5		0x0020
#define SBIT6		0x0040
#define SBIT7		0x0080
#define SBIT8		0x0100
#define SBIT9		0x0200
#define SBIT10		0x0400
#define SBIT11		0x0800
#define SBIT12		0x1000
#define SBIT13		0x2000
#define SBIT14		0x4000
#define SBIT15		0x8000

//�� λ��varx = varx & (SBIT9 & SBIT8)
#define CBIT0		0x0FFFE
#define CBIT1		0x0FFFD
#define CBIT2		0x0FFFB
#define CBIT3		0x0FFF7
#define CBIT4		0x0FFEF
#define CBIT5		0x0FFDF
#define CBIT6		0x0FFBF
#define CBIT7		0x0FF7F
#define CBIT8		0x0FEFF
#define CBIT9		0x0FDFF
#define CBIT10		0x0FBFF
#define CBIT11		0x0F7FF
#define CBIT12		0x0EFFF
#define CBIT13		0x0DFFF
#define CBIT14		0x0BFFF
#define CBIT15		0x07FFF

//����λ��λ�����ã���varx = varx & CBIT9 | SBIT8: BIT98=01

/*-----------------------------------------------------------------------------
      Specify the clock rate of the CPU (SYSCLKOUT) in nS.

      Take into account the input clock frequency and the PLL multiplier
      selected in step 1.
 
      Use one of the values provided, or define your own.
      The trailing L is required tells the compiler to treat 
      the number as a 64-bit value.  

      Only one statement should be uncommented.

      Example:  CLKIN is a 10MHz crystal. 
 
                In step 1 the user specified PLLCR = 0xA for a 
                100Mhz CPU clock (SYSCLKOUT = 100MHz).  

                In this case, the CPU_RATE will be 10.000L
                Uncomment the line:  #define CPU_RATE   10.000L
-----------------------------------------------------------------------------*/

#define CPU_RATE   10.000L   // for a 100MHz CPU clock speed (SYSCLKOUT)
//#define CPU_RATE   13.330L   // for a 75MHz CPU clock speed (SYSCLKOUT)
//#define CPU_RATE   20.000L   // for a 50MHz CPU clock speed  (SYSCLKOUT)
//#define CPU_RATE   33.333L   // for a 30MHz CPU clock speed  (SYSCLKOUT)
//#define CPU_RATE   41.667L   // for a 24MHz CPU clock speed  (SYSCLKOUT)
//#define CPU_RATE   50.000L   // for a 20MHz CPU clock speed  (SYSCLKOUT)
//#define CPU_RATE   66.667L   // for a 15MHz CPU clock speed  (SYSCLKOUT)
//#define CPU_RATE  100.000L   // for a 10MHz CPU clock speed  (SYSCLKOUT)

//----------------------------------------------------------------------------

// DO NOT MODIFY THIS LINE.  
#define DELAY_US(A)  DSP28x_usDelay(((((long double) A * 1000.0L) / (long double)CPU_RATE) - 9.0L) / 5.0L)

#ifdef __cplusplus
}
#endif /* extern "C" */



#endif

//===========================================================================
// End of file.
//===========================================================================
