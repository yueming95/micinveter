################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Classes/template.cpp 

OBJS += \
./App/Classes/template.obj 

CPP_DEPS += \
./App/Classes/template.pp 

CPP_DEPS__QUOTED += \
"App\Classes\template.pp" 

OBJS__QUOTED += \
"App\Classes\template.obj" 

CPP_SRCS__QUOTED += \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Classes/template.cpp" 


