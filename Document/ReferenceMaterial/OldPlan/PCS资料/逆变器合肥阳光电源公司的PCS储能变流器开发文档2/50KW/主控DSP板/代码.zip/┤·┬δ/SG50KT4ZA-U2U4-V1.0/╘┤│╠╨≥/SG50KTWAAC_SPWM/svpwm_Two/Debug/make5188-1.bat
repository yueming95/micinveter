@echo off
DEL /F "E:\work\SG50KT4WA\program\SG50KTWAAC_two\Debug\can.obj" "E:\work\SG50KT4WA\program\SG50KTWAAC_two\Debug\corecontrol.obj" "E:\work\SG50KT4WA\program\SG50KTWAAC_two\Debug\main.obj" "E:\work\SG50KT4WA\program\SG50KTWAAC_two\Debug\pid.obj" 
