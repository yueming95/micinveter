/* Quartus II Version 10.1 Build 197 01/19/2011 Service Pack 1 SJ Web Edition */
JedecChain;
	FileRevision(JESD32A);
	DefaultMfr(6E);

	P ActionCode(Cfg)
		Device PartName(EPM570F256) Path("E:/innovpower/innov_xiaogai/innov_33dcdccpld_xiaogai/") File("rec_logic.pof") MfrSpec(OpMask(7) SEC_Device(EPM570F256) Child_OpMask(2 7 7));

ChainEnd;

AlteraBegin;
	ChainType(JTAG);
AlteraEnd;
