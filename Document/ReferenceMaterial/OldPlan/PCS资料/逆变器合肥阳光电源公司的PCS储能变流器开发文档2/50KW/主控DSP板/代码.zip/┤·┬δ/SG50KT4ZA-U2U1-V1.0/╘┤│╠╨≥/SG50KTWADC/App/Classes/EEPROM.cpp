/*==========================================================*/
/* Title		:	EEPROM.cpp								*/
/* Description	: 	Class_EEPROM realization 				*/
/* Date			:	Oct.2007								*/
/*==========================================================*/
#include  "EEPROM.h"

//��ʼ��
void	Class_EEPROM::Dat_EEPROMInit(void)
{	
	UINT16 u16_Temp0;

	m_pHistoryBuffW = objMonInterface.m_u16_HistoryRecord;
	m_pHistoryBuffR = objMonInterface.m_u16_HistoryRecord;

	u16_Temp0 = App_ParamRead(HistoryNumAddr);
	if(u16_Temp0 < 512)
	{
		m_u16_HistoryNumW = u16_Temp0;
	}
	else
	{
		m_u16_HistoryNumW = 0;
	}

	u16_Temp0 = App_ParamRead(HistoryCntAddr);
	if(u16_Temp0 <= 512)
	{
		m_u16_HistoryCnt = u16_Temp0;
		//m_u16_HistoryCnt = 0;	
	}
	else
	{
		m_u16_HistoryCnt = 0;
	}

	u16_Temp0 = App_ParamRead(FaultWAddr);
	if((u16_Temp0 >= FaultRecordAddr)&&(u16_Temp0 < 0x4000))
	{
		m_u16_FaultAddrW = u16_Temp0 & 0x0FF00;				//��֤���ϼ�¼��ַΪ256�ı���
		m_u16_FaultAddrNext = m_u16_FaultAddrW;
	}
	else
	{
		m_u16_FaultAddrW = FaultRecordAddr;
		m_u16_FaultAddrNext = FaultRecordAddr;
	}

	u16_Temp0 = App_ParamRead(FaultCntAddr);
	if(u16_Temp0 <= 40)
	{
		m_u16_FaultCnt = u16_Temp0;
	}
	else
	{
		m_u16_FaultCnt = 0;
	}

	m_pFaultAddrW = &m_u16_FaultAddrW;
	m_pFaultWriteCnt = &m_i16_FaultWriteCnt;
	m_pFaultBuffR = objDebug.m_u16_FaultRecordWrite;
	
}


//���������е����ݰ���д��EEPROM��
void	Class_EEPROM::App_ParamEEPROMW(void)
{	
//�밴��Э��˳����д��
//���濪ʼʹ��u16SetParamFresh, ��0x0001 ��ʼֱ��0x8000����ע���޸������õ�ʮ�����������������
//u16SetParamFresh�Ѿ����꣬����������

	//�����ѹУ��ϵ��
	if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0001) == 0x0001)
	{
		objI2CDrv.Drv_I2CWordWrite(VPVInputScalAddr, objMonInterface.m_i16_InVltRevCoef);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFFE);
	}
	//�������У��ϵ����1 ��
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0002) == 0x0002)
	{
		objI2CDrv.Drv_I2CWordWrite(IPVInputScalAddr1, objMonInterface.m_i16_InCurrRevCoef1);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFFD);
	}
	//�����ѹУ��ϵ����2 ��
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0004) == 0x0004)
	{
		objI2CDrv.Drv_I2CWordWrite(IPVInputScalAddr2, objMonInterface.m_i16_InCurrRevCoef2);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFFB);
	}
	//��ĸ�ߵ�ѹУ������
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0008) == 0x0008)
	{
		objI2CDrv.Drv_I2CWordWrite(VBusPScalAddr, objMonInterface.m_i16_PostBusVltRevCoef);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFF7);
	}
	//��ĸ�ߵ�ѹУ������
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0010) == 0x0010)
	{
		objI2CDrv.Drv_I2CWordWrite(VBusNScalAddr, objMonInterface.m_i16_NegBusVltRevCoef);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFEF);
	}
	//���Ա�����ַ1
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0020) == 0x0020)
	{
		objI2CDrv.Drv_I2CWordWrite(DegVar1AddressAddr, objMonInterface.u_16_DbgVar1Adr);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFDF);
	} 
	//���Ա�����ַ2
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0040) == 0x0040)
	{
		objI2CDrv.Drv_I2CWordWrite(DegVar2AddressAddr, objMonInterface.u_16_DbgVar2Adr);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FFBF);
	}
	//���Ա�����ַ3
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0080) == 0x0080)
	{
		objI2CDrv.Drv_I2CWordWrite(DegVar3AddressAddr, objMonInterface.u_16_DbgVar3Adr);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FF7F);
	}
	/*���Բ���1*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0100) == 0x0100)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp1Addr, objMonInterface.u16DCTempDebug1);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FEFF);
	}
	/*���Բ���2*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0200) == 0x0200)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp2Addr, objMonInterface.u16DCTempDebug2);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FDFF);
	}
	/*���Բ���3*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0400) == 0x0400)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp3Addr, objMonInterface.u16DCTempDebug3);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0FBFF);
	}
	/*���Բ���4*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0800) == 0x0800)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp4Addr, objMonInterface.u16DCTempDebug4);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0xF7FF);
	}
	/*���Բ���5*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x1000) == 0x1000)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp5Addr, objMonInterface.u16DCTempDebug5);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0EFFF);
	}
	/*���Բ���6*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x2000) == 0x2000)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp6Addr, objMonInterface.u16DCTempDebug6);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0DFFF);
	}	
	/*���Բ���7*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x4000) == 0x4000)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp7Addr, objMonInterface.u16DCTempDebug7);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x0BFFF);
	}
	/*���Բ���8*/
	else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x8000) == 0x8000)
	{
		objI2CDrv.Drv_I2CWordWrite(DCDebugTemp8Addr, objMonInterface.u16DCTempDebug8);
		objMonInterface.m_st_RecSet_UD.u16SetParamFresh = (objMonInterface.m_st_RecSet_UD.u16SetParamFresh & 0x07FFF);
	}	
//ע������Ϊ16�����ò������Ѿ�������u16SetParamFresh�������ڴ�λ�ò����������������������
//���濪ʼʹ��u16SetParamFresh1 , ��0x0001 ��ʼֱ��0x8000����ע���޸������õ�ʮ�����������������


}


//������u16_AddrΪ�׵�ַ��1��У������
inline	UINT16 	Class_EEPROM::App_ParamRead(UINT16 u16_Addr)
{
	UINT16 u16_ParamTemp;
	
	objI2CDrv.Drv_I2CRead(u16_Addr, 1, &u16_ParamTemp);
	
	return(u16_ParamTemp);			
			
}

//��*pSourceָ�������4����ʷ��¼����д�뵽��������
void 	Class_EEPROM::App_HistoryRecordW(UINT16 *pSource)
{
	INT16 i16_Temp;
	
	for(i16_Temp = 0;i16_Temp < HistoryWords;i16_Temp++)
	{
		*(m_pHistoryBuffW + i16_Temp) = *(pSource + i16_Temp);
	}

	m_i16_HistoryWriteCnt = m_i16_HistoryWriteCnt + HistoryWords;
	
	if(m_pHistoryBuffW == &objMonInterface.m_u16_HistoryRecord[252])
	{
		m_pHistoryBuffW = objMonInterface.m_u16_HistoryRecord;
	}
	else
	{
		m_pHistoryBuffW = m_pHistoryBuffW + HistoryWords;
	}
	
}


//����ʷ��¼�������е�����д�뵽EEPROM��(ÿ��д4��,��֤��¼��������)
void		Class_EEPROM::App_HistoryEEPROMW(void)
{
	UINT16	u16_Temp, u16_HistoryAddrW;
	UINT16	u16_Temp0[2];
	UINT16	*pSource;

	u16_Temp = m_u16_HistoryNumW/10;	
	
	if( u16_Temp == m_u16_HistoryNum10Cnt)
	{
		u16_HistoryAddrW = HistoryAddr + (m_u16_HistoryNumW << 3);
			
		objI2CDrv.Drv_I2CPageWrite(u16_HistoryAddrW, HistoryWords, m_pHistoryBuffR);

		if(m_pHistoryBuffR == &objMonInterface.m_u16_HistoryRecord[252])
		{
			m_pHistoryBuffR = objMonInterface.m_u16_HistoryRecord;
		}
		else
		{
			m_pHistoryBuffR = m_pHistoryBuffR + HistoryWords;
		}

		m_i16_HistoryWriteCnt = m_i16_HistoryWriteCnt - HistoryWords;	
		m_u16_HistoryCnt++;
		if(m_u16_HistoryCnt >= 512)
		{
			m_u16_HistoryCnt = 512;
		}
		m_u16_HistoryNumW++;
		if(m_u16_HistoryNumW >= 512)
		{
			m_u16_HistoryNumW = 0;
		}
	}
	else
	{
		//if(m_u16_HistoryCnt <= 512)
		//{
			u16_Temp0[0] = m_u16_HistoryNumW;
			u16_Temp0[1] = m_u16_HistoryCnt;
			pSource = u16_Temp0;
				
			objI2CDrv.Drv_I2CPageWrite(HistoryNumAddr, 2, pSource);
		//}
		//else
		//{
		//	objI2CDrv.Drv_I2CWordWrite(HistoryNumAddr,m_u16_HistoryNumW);
		//}
		
		m_u16_HistoryNum10Cnt = u16_Temp;
	}
}
	


//������0x0800Ϊ�׵�ַ��Num����ʷ��¼,Num<=128
void		Class_EEPROM::App_HistoryRead(void)
{
	UINT16 	u16_HistoryAddr;
	UINT16	*HistoryBuffWrite;				//д��ʷ��¼������ָ��(���ڴ�EEPROM��ȡ����д�뻺����)
	INT16	i16_Num;
	INT16	i16_Temp, i16_Temp1;
	
	//while((m_i16_HistoryReadComand == 1)&&(objDigitalIO.Dat_GetIOFlag().bModuleReady == 0))
	//{
		if(m_i16_HistoryReady == 0)
		{	
			//���㹲���ȡ���ٴ�
			i16_Temp = m_u16_HistoryCnt >> 6;
			i16_Temp1 = m_u16_HistoryCnt % 64;
			if(i16_Temp1 != 0)
			{
				i16_Temp = i16_Temp + 1;
			}			
			
			if(m_i16_HistoryReadCnt < i16_Temp)
			{
				HistoryBuffWrite = objMonInterface.m_u16_HistoryRecord;

				//����ÿ�����ȡ������
				if((m_i16_HistoryReadCnt == (i16_Temp -1)) && (i16_Temp1 != 0))
				{
					i16_Num = i16_Temp1<<2;
				}
				else
				{
					i16_Num = 256;	
				}	

				if(m_i16_HistoryReadCnt == 0)
				{
					m_u16_HistoryNumR = App_ParamRead(HistoryNumAddr);
            	
					if(m_u16_HistoryNumR == 0)
					{
						m_u16_HistoryNumR = 512;
					}
				}
    	    	
				while(i16_Num > 0)
				{					
					u16_HistoryAddr = HistoryAddr + ((m_u16_HistoryNumR - 1) << 3);				
					
					objI2CDrv.Drv_I2CRead(u16_HistoryAddr, HistoryWords, HistoryBuffWrite);
            	 	
					m_u16_HistoryNumR -- ;
    							
					if(m_u16_HistoryNumR == 0)
					{
						m_u16_HistoryNumR = 512;
					}						
    	    	
					i16_Num = i16_Num - HistoryWords;	
						
					HistoryBuffWrite = HistoryBuffWrite + HistoryWords;
										
				}
    	    	
				m_i16_HistoryReady = 1;			
				m_i16_HistoryReadCnt ++;
			}
			else
			{
				m_i16_HistoryReadCnt = 0;
				m_i16_HistoryReadComand  = 0;
			}
			
		}
	//}

}


//�ѹ��ϼ�¼�������е�����д�뵽EEPROM��
void 	Class_EEPROM::App_FaultEEPROMW(void)
{
	UINT16 *pTemp;
	UINT16  u16_Temp0[2];
	UINT16 *pSource;
	
	if(m_i16_FaultWriteCnt > 0)
	{
		pTemp = objI2CDrv.Drv_I2CWriteAll(m_pFaultAddrW, m_pFaultWriteCnt, m_pFaultBuffR);

		m_pFaultBuffR = pTemp;
		
		if(m_u16_FaultAddrW == 0x4000)
		{
			m_u16_FaultAddrW = FaultRecordAddr;
		}
	}
	
	else
	{
		m_pFaultBuffR = objDebug.m_u16_FaultRecordWrite;			//дָ������ָ��д���������׵�ַ
		
		m_u16_FaultAddrNext = m_u16_FaultAddrW;
		
		m_u16_FaultCnt++;
		if(m_u16_FaultCnt <= 40)
		{
			u16_Temp0[0] = m_u16_FaultAddrNext;
			u16_Temp0[1] = m_u16_FaultCnt;
			pSource = u16_Temp0;
				
			objI2CDrv.Drv_I2CPageWrite(FaultWAddr, 2, pSource);
		}
		else
		{
			m_u16_FaultCnt = 40;
			objI2CDrv.Drv_I2CWordWrite(FaultWAddr, m_u16_FaultAddrNext);
		}
		
		m_i16_FaultWRequest = 0;
	}
}


//��ȡ���ϼ�¼�����ʼ��(�ɼ����������ʱ����)	
void		Class_EEPROM::App_FaultReadTaskInit(INT16 i16_FaultNum)					
{
	UINT16	u16_NumPointerReset;	

	u16_NumPointerReset = (m_u16_FaultAddrNext-FaultRecordAddr)/FaultBytesPer;		//����ָ��ѭ���߽�Ĺ��ϼ�¼����
	if(i16_FaultNum > u16_NumPointerReset)
	{
		m_u16_FaultAddrR = 0x4000 - ((i16_FaultNum- u16_NumPointerReset)<< 8);
	}
	else
	{	
		m_u16_FaultAddrR = m_u16_FaultAddrNext - (i16_FaultNum << 8);			//��ȡ���µĵ�i16_FaultNum �����ϼ�¼
	}
		
	m_pFaultBuffW = objMonInterface.m_u16_FaultRecordRead;
	m_i16_WordsCnt = 128;
	
}


//��EEPROM����ָ����1�����ϼ�¼,���뻺����
void		Class_EEPROM::App_FaultRead(void)
{
	if(m_i16_FaultReadReady == 0)
	{	
		if(m_i16_WordsCnt > 0)
		{
			if(m_i16_WordsCnt >= MaxWordsRead)
			{
				objI2CDrv.Drv_I2CRead(m_u16_FaultAddrR, MaxWordsRead, m_pFaultBuffW);

				m_u16_FaultAddrR = m_u16_FaultAddrR + (MaxWordsRead << 1);
				m_pFaultBuffW = m_pFaultBuffW + MaxWordsRead;

				m_i16_WordsCnt = m_i16_WordsCnt - MaxWordsRead;
		
			}
			else
			{
				objI2CDrv.Drv_I2CRead(m_u16_FaultAddrR, m_i16_WordsCnt, m_pFaultBuffW);
				m_i16_WordsCnt = 0;
			}
		}

		if(m_i16_WordsCnt == 0)
		{
			m_i16_FaultReadReady = 1;			
			m_i16_FaultReadComand = 0;
		}
		
	}	
}


//EEPROM��д����
void	 Class_EEPROM::App_EEPROMAction(void)
{
	UINT16	u16_AddrTemp[4];
	UINT16	*pAddrSource;
	
	if(objTimerDrv.Drv_1msCome() == 1)
	{
		m_i16_t1msCnt++;
		
		if(m_i16_t1msCnt>5)
		{
			m_i16_t1msCnt = 0;
			
			
			if((objDigitalIO.Dat_GetIOFlag().bPower15VFault == 1)
				||(objDigitalIO.Dat_GetIOFlag().bPower24VFault == 1))
			//if(m_i16_FaultWNotOver == 0)
			{
				u16_AddrTemp[0] = m_u16_HistoryNumW;
				u16_AddrTemp[1] = m_u16_HistoryCnt;
				u16_AddrTemp[2] = m_u16_FaultAddrNext;
				u16_AddrTemp[3] = m_u16_FaultCnt;
				pAddrSource = u16_AddrTemp;

				objI2CDrv.Drv_I2CPageWrite(0x0200, 4, pAddrSource);				
			}

			else if((objMonInterface.m_st_RecSet_UD.u16SetParamFresh != 0)
					||(objMonInterface.m_st_RecSet_UD.u16SetParamFresh1 != 0)
					||(objBattery.m_st_BatteryIntFlag_0.bScalVchgPFresh == 1)
					||(objBattery.m_st_BatteryIntFlag_0.bScalVchgNFresh == 1))								//�ȴ�д�����ݸ�������0
			{
				App_ParamEEPROMW();
			}

			else if(m_i16_HistoryWriteCnt > 0)
			{
				App_HistoryEEPROMW();
			}

			else if(m_i16_FaultWRequest == 1)
			{
				App_FaultEEPROMW();
			}

			else if(m_i16_FaultReadComand == 1)
			{
				App_FaultRead();
			}
		}


	}

}
//============================================================
// End of file.
//============================================================
