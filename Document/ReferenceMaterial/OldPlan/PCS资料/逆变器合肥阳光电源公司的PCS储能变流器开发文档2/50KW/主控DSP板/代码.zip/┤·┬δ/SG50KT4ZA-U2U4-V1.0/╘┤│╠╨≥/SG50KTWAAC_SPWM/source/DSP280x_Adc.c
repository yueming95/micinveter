// TI File $Revision: /main/1 $
// Checkin $Date: December 1, 2004   11:11:30 $
//###########################################################################
//
// FILE:	DSP280x_Adc.c
//
// TITLE:	DSP280x ADC Initialization & Support Functions.
//
//###########################################################################
// $TI Release: DSP280x Header Files V1.60 $
// $Release Date: December 3, 2007 $
//###########################################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File
#include "DSP280x_Examples.h"   // DSP280x Examples Include File
#include "corecontrol.h"
#include "Spi.h"
#define ADC_usDELAY  5000L
#pragma CODE_SECTION(Drv_Int_Sampling1Data, "ramfuncs");
#pragma CODE_SECTION(Drv_Int_Sampling2Data, "ramfuncs");

//---------------------------------------------------------------------------
// InitAdc: 
//---------------------------------------------------------------------------
// This function initializes ADC to a known state.
//
// PLEASE NOTE, ADC INIT IS DIFFERENT ON 281x vs 280x DEVICES!!!
//
void InitAdc(void)
{
    extern void DSP28x_usDelay(Uint32 Count);

    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks, followed by powering up the bandgap, reference circuitry, and ADC core.
    // Before the first conversion is performed a 5ms delay must be observed 
	// after power up to give all analog circuits time to power up and settle

    // Please note that for the delay function below to operate correctly the 
	// CPU_CLOCK_SPEED define statement in the DSP280x_Examples.h file must 
	// contain the correct CPU clock period in nanoseconds. 

    AdcRegs.ADCTRL3.all = 0x00E0;  // Power up bandgap/reference/ADC circuits
    DELAY_US(ADC_usDELAY);         // Delay before converting ADC channels
}	
void Drv_ADAdjust(void)
{	
	int16	i16MainAX,i16MainBX,i16MainDX;
	int32	i32MainGX;
	
	GpioDataRegs.GPASET.bit.GPIO0 = 1;
	GpioDataRegs.GPACLEAR.bit.GPIO1 = 1;
	GpioDataRegs.GPACLEAR.bit.GPIO9 = 1;	    // IO910=001
//������ʱ,��ҪΪ�˽��1V�����л��ź��ܹ���COLD���
	for( i16MainBX=0; i16MainBX<=500; i16MainBX++)
	{  
		DELAY_US(1000);
	}
	
    	GpioDataRegs.GPASET.bit.GPIO8 = 1;	    	// ѡ���һ�β���ͨ��
    
	BitSignalout2.bit.bADCAdjust = 1;				// SA=1 SB=0ѡͨ1V
	SpibRegs.SPITXBUF = BitSignalout2.all;
	for(i16MainAX=0; ((i16MainAX<15)&&(SpibRegs.SPISTS.bit.INT_FLAG==0)); i16MainAX++)
	{
		asm(" RPT #9 || NOP");				// ���ȴ�3.63us
	}
	i16MainAX = SpibRegs.SPIRXBUF;
	
    for( i16MainBX=0; i16MainBX<=5000; i16MainBX++)
	{  
		DELAY_US(1000);
		AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
		asm("	NOP");
		AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;
		asm(" RPT #29 || NOP");
		for(i16MainAX=0; ((i16MainAX<40)&&(AdcRegs.ADCST.bit.SEQ1_BSY==1));i16MainAX++)
		{
			asm(" RPT #9 || NOP");				// ���ȴ�9.6us
		}
		i32MainGX = AdcRegs.ADCRESULT8>>4;
		m_unAdResult1V.dword += ((i32MainGX<<16) - m_unAdResult1V.dword)>>4;  
		
		// Inverter Current U and W Reverse
		i32MainGX = AdcRegs.ADCRESULT3>>4;                               
		m_unAdIinvaMid.dword += ((i32MainGX<<16) - m_unAdIinvaMid.dword)>>4;
		i32MainGX = AdcRegs.ADCRESULT4>>4;                               
		m_unAdIinvbMid.dword += ((i32MainGX<<16) - m_unAdIinvbMid.dword)>>4;
		i32MainGX = AdcRegs.ADCRESULT5>>4;                               
		m_unAdIinvcMid.dword += ((i32MainGX<<16) - m_unAdIinvcMid.dword)>>4;
										
	}

    GpioDataRegs.GPACLEAR.bit.GPIO8 = 1;	    // ѡ��ڶ��β���ͨ��
	BitSignalout2.bit.bADCAdjust  =  2;				// SA=0 SB=1ѡͨ2V
	SpibRegs.SPITXBUF = BitSignalout2.all;
	for(i16MainAX=0; ((i16MainAX<15)&&(SpibRegs.SPISTS.bit.INT_FLAG==0)); i16MainAX++)
	{
		asm(" RPT #9 || NOP");					// ���ȴ�3.63us
	}
	i16MainAX = SpibRegs.SPIRXBUF;
	
    
    for( i16MainBX = 0; i16MainBX <= 5000; i16MainBX++)
	{    
		DELAY_US(1000); 
		AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;
		asm("	NOP");
		AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;
		asm(" RPT #29 || NOP");
		for(i16MainAX=0; ((i16MainAX<40)&&(AdcRegs.ADCST.bit.SEQ1_BSY==1)); i16MainAX++)
		{
			asm(" RPT #9 || NOP");				// ���ȴ�9.6us
		}
		i32MainGX = AdcRegs.ADCRESULT8>>4;
		m_unAdResult2V.dword += ((i32MainGX<<16) - m_unAdResult2V.dword)>>4; 
		
	}   
	   
	GpioDataRegs.GPASET.bit.GPIO8 = 1;	    	// ѡ���һ�β���ͨ��
	BitSignalout2.bit.bADCAdjust = 0;				// SA=0 SB=0ѡͨiVdc_0
	SpibRegs.SPITXBUF = BitSignalout2.all;
	for(i16MainAX=0; ((i16MainAX<15)&&(SpibRegs.SPISTS.bit.INT_FLAG==0)); i16MainAX++)
	{
		asm(" RPT #9 || NOP");					// ���ȴ�3.63us
	}
	i16MainAX = SpibRegs.SPIRXBUF;
	
	i16MainDX = m_unAdResult2V.half.hword-m_unAdResult1V.half.hword;
	m_i16ADCSlope = ((int32)1365<<12)/i16MainDX;       //б��У׼ϵ��
	m_i16ADCOffset = ((int32)m_unAdResult2V.half.hword*1365-(int32)m_unAdResult1V.half.hword*2730)/i16MainDX;  //ƫ����У׼ϵ��

	if(m_unAdIinvaMid.dword>0x08A00000) m_unAdIinvaMid.dword=0x08A00000;
	if(m_unAdIinvaMid.dword<0x07600000) m_unAdIinvaMid.dword=0x07600000;
	if(m_unAdIinvbMid.dword>0x08A00000) m_unAdIinvbMid.dword=0x08A00000;
	if(m_unAdIinvbMid.dword<0x07600000) m_unAdIinvbMid.dword=0x07600000;
	if(m_unAdIinvcMid.dword>0x08A00000) m_unAdIinvcMid.dword=0x08A00000;
	if(m_unAdIinvcMid.dword<0x07600000) m_unAdIinvcMid.dword=0x07600000;
	
	if(abs(m_i16ADCSlope-4096) > 200)
	{
		m_i16ADCSlope = 4096;
		m_i16ADCOffset = 0;
	}


}

/************************************************************************************
��������	Drv_ADInit()
����������	ADģ���ʼ��
�������ã�	��
************************************************************************************/
void Drv_ADInit(void)
{
	/* <=== ADC Registers initialization ===> */   

    // To powerup the ADC the ADCENCLK bit should be set first to enable
    // clocks, followed by powering up the bandgap, reference circuitry, and ADC core.
    // Before the first conversion is performed a 5ms delay must be observed 
	// after power up to give all analog circuits time to power up and settle	

    AdcRegs.ADCTRL3.all = 0x00E0;            // Power up bandgap/reference/ADC circuits

    DELAY_US(5000);     // Delay 5ms before converting ADC channels

    AdcRegs.ADCTRL1.all = 0x0490;
 							                 // CPS = 1
 							                 // ��������ΪADCCLK��5
 							                 // ����������
 							                 // ����/ֹͣģʽ
    AdcRegs.ADCTRL2.all = 0x4040;
 							                 // Reset SEQ1 and SEQ2
 							                 // Disable Intrupt
    AdcRegs.ADCTRL3.bit.SMODE_SEL = 0;       // ����������ͬʱ����
    AdcRegs.ADCTRL3.bit.ADCCLKPS = 1;        // ADCCLK = HSPCLK/4=12.5MHz
 							                 
    AdcRegs.ADCMAXCONV.all = 0x0F;
    AdcRegs.ADCCHSELSEQ1.all = 0x03210;	     //˳����� 
    AdcRegs.ADCCHSELSEQ2.all = 0x07654;	     // 
    AdcRegs.ADCCHSELSEQ3.all = 0x0BA98;	     // 
    AdcRegs.ADCCHSELSEQ4.all = 0x0FEDC;	     // 

}
/************************************************************************************
//�������ƣ�    Drv_Int_Sampling1Data()
//����������    ���յ�һ�ֲ�������
************************************************************************************/
			
void Drv_Int_Sampling1Data(void)
{
		volatile _iq temp;	
		unsigned char i16IntCount_0;
		AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			
		asm("	NOP");
		AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;       			// ������һ�ֲ���
		
		// ע�⣺Ϊ��ȷʹ�ñ�־SEQ1_BSY��������AD����SEQ1_BSY��־֮��������Ҫ25��nop��ִ��ʱ�䡣

		for(i16IntCount_0=0; ((i16IntCount_0<40)&&(AdcRegs.ADCST.bit.SEQ1_BSY == 1)); i16IntCount_0++)
		{
			asm(" RPT #9 || NOP");						// ���ȴ�9.6us
		}

		GpioDataRegs.GPACLEAR.bit.GPIO8 = 1;	    // ѡ��ڶ��β���ͨ��
	//20110726�޸� ����A��C��ָ�����λ��	
	AI.Iga = AdcRegs.ADCRESULT3>>4;
	AI.Igb = AdcRegs.ADCRESULT4>>4;
	AI.Igc = AdcRegs.ADCRESULT5>>4;
	AI.Uinva= AdcRegs.ADCRESULT6>>4;
	AI.Uinvb= AdcRegs.ADCRESULT7>>4;
	AI.Uinvc = AdcRegs.ADCRESULT8>>4;

	
	AI.UdcP = AdcRegs.ADCRESULT15>>4;
	
	AI.Iga = ((int32)m_i16ADCSlope*(AI.Iga-m_unAdIinvaMid.half.hword))>>12;//m_unAdIinvaMid.half.hword
	AI.Igb = ((int32)m_i16ADCSlope*(AI.Igb-m_unAdIinvbMid.half.hword))>>12;
	AI.Igc = ((int32)m_i16ADCSlope*(AI.Igc-m_unAdIinvcMid.half.hword))>>12;							
	AI.Uinva = (((int32)m_i16ADCSlope*AI.Uinva)>>12)+m_i16ADCOffset-2048;
	AI.Uinvb = (((int32)m_i16ADCSlope*AI.Uinvb)>>12)+m_i16ADCOffset-2048;
	AI.Uinvc = (((int32)m_i16ADCSlope*AI.Uinvc)>>12)+m_i16ADCOffset-2048;

	AI.Uinvab=AI.Uinva-AI.Uinvb;
	AI.Uinvbc=AI.Uinvb-AI.Uinvc;
	AI.Uinvca=AI.Uinvc-AI.Uinva;

	InputSignal.Uinva = ((int32)((AI.Uinvab<<1)+AI.Uinvbc)*K1div3Cnst);
	InputSignal.Uinvb = ((int32)(-AI.Uinvab+AI.Uinvbc)*K1div3Cnst);
	InputSignal.Uinvc = -InputSignal.Uinva -InputSignal.Uinvb;

	AI.UdcP  = (((int32)m_i16ADCSlope*AI.UdcP)>>12)+m_i16ADCOffset; 
		temp=AI.UdcP;
	temp=temp<<19;
	InputSignal.UdcP=_IQ19mpy(temp,KUDC)<<2;  
		temp=AI.Iga;
	temp=temp<<19;
	InputSignal.Iga=_IQ19mpy(temp,KIOUT)<<2;
	temp=AI.Igb;
	temp=temp<<19;
	InputSignal.Igb=_IQ19mpy(temp,KIOUT)<<2;
	temp=AI.Igc;
	temp=temp<<19;
	InputSignal.Igc=_IQ19mpy(temp,KIOUT)<<2;
	temp=InputSignal.Uinva;
	temp=temp<<7;
	InputSignal.Uinva=_IQ19mpy(temp,KUINV)<<2;
	temp=InputSignal.Uinvb;
	temp=temp<<7;
	InputSignal.Uinvb=_IQ19mpy(temp,KUINV)<<2;
	temp=InputSignal.Uinvc;
	temp=temp<<7;
	InputSignal.Uinvc=_IQ19mpy(temp,KUINV)<<2;

	InputSignal.IgAdd=InputSignal.Iga+InputSignal.Igb+InputSignal.Igc;


}

/************************************************************************************
//�������ƣ�    Drv_Int_Sampling2Data()
//����������    ���յڶ��ֲ�������
************************************************************************************/
			
void 	Drv_Int_Sampling2Data(void)
{
		volatile _iq temp;	
		unsigned char i16IntCount_0;

		AdcRegs.ADCTRL2.bit.RST_SEQ1 = 1;			
    	asm("	NOP");
    	AdcRegs.ADCTRL2.bit.SOC_SEQ1 = 1;        			// �����ڶ��ֲ���

    	for(i16IntCount_0=0;((i16IntCount_0<40)&&(AdcRegs.ADCST.bit.SEQ1_BSY==1));i16IntCount_0++)
		{
			asm(" RPT #9 || NOP");						// ���ȴ�9.6us
		}
    	
   		GpioDataRegs.GPASET.bit.GPIO8 = 1;	     // ѡ���һ�β���ͨ��
	              
	AI.Uoutab = AdcRegs.ADCRESULT9>>4;
	AI.Uoutbc = AdcRegs.ADCRESULT10>>4; 
	AI.Uoutca = AdcRegs.ADCRESULT11>>4;


	AI.UdcN = AdcRegs.ADCRESULT15>>4;
	
	AI.Uoutab = (((int32)m_i16ADCSlope*AI.Uoutab)>>12)+m_i16ADCOffset-2048;  //У׼���е�ƫ��
	AI.Uoutbc = (((int32)m_i16ADCSlope*AI.Uoutbc)>>12)+m_i16ADCOffset-2048;
	AI.Uoutca = (((int32)m_i16ADCSlope*AI.Uoutca)>>12)+m_i16ADCOffset-2048;	
	AI.UdcN  = (((int32)m_i16ADCSlope*AI.UdcN)>>12)+m_i16ADCOffset;

	
	InputSignal.Uouta = ((int32)((AI.Uoutab<<1)+AI.Uoutbc)*K1div3Cnst);
	InputSignal.Uoutb = ((int32)(-AI.Uoutab+AI.Uoutbc)*K1div3Cnst);
	InputSignal.Uoutc = -InputSignal.Uouta -InputSignal.Uoutb;
	temp=InputSignal.Uouta<<7;
	InputSignal.Uouta=_IQ19mpy(temp,KUOUT)<<2;
	temp=InputSignal.Uoutb<<7;
	InputSignal.Uoutb=_IQ19mpy(temp,KUOUT)<<2;
	temp=InputSignal.Uoutc<<7;
	InputSignal.Uoutc=_IQ19mpy(temp,KUOUT)<<2;
	temp=AI.UdcN;
	temp=temp<<19;
	InputSignal.UdcN=_IQ19mpy(temp,KUDC)<<2;
}

//===========================================================================
// End of file.
//===========================================================================
