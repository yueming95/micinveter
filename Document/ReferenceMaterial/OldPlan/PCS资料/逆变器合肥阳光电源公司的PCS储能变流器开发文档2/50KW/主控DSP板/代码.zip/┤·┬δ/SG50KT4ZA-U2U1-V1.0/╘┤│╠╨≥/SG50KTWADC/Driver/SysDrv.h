/*==========================================================*/
/* Title		:	SysDrv.h								*/
/* Description	: 	Class_SysDrv definition					*/
/* Date			:	Oct.2007								*/
/*==========================================================*/

#ifndef DSP280x_SYSDRV_H
#define DSP280x_SYSDRV_H


//============================================================
//	Class_SysDrv���ⲿ�Ľӿ�
//	1)����objWatchDogDrv.Drv_DisableDog()
//	2)
//============================================================
class Class_SysDrv
{
	private:
//		struct	PIE_VECT_TABLE	m_st_PieVectTableInit;
		INT16	m_i16_ClockMissing;							//ʱ�Ӷ�ʧ��־λ
		UINT16	m_u16_DSPRevision;							//DSP�汾��
	public:
		void	Drv_Init(void);								//��ʼ��
		void	Drv_InitPLL(void);							//This function initializes the PLLCR register.
		
		//This function initializes the clocks to the peripheral modules.
		void	Drv_InitPeripheralClocks(void);
		
		//This function initializes the PIE control registers to a known state.				
		void	Drv_InitPieCtrl(void);	
		
		//This function initializes the PIE vector table to a known state.
		//This function must be executed after boot time.					
		void	Drv_InitPieVectTable(void);	
		
		//This function deal the PIE module and CPU interrupts,used in interrupt program				
		void	Drv_Int_InterruptFlagClear(void);	
		
		void	Drv_InitInterrupts(void);					//This function enable the PIE module and CPU interrupts
		inline	INT16	Drv_ClockMissingGet(void);			//���ʱ�Ӷ�ʧ��־λ
		inline	void	Drv_InterruptEnable(void);			// Enable Interrupts at the CPU level
		inline	void	Drv_InterruptDisable(void);			//Disable Interrupts at the CPU level
		void	Drv_DSPVersionSet(void);					//DSP�汾������
		
		
		inline	UINT16	Drv_GetDSPVersion(void);			//��ȡDSP�汾��
};

#endif
//============================================================
// End of file.
//============================================================
