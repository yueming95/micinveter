#define pid_GLOBALS
#include "pid.h"
#pragma CODE_SECTION(PidCalc, "ramfuncs");
void PidCalc(PID *v)
{
	v->Err=v->Ref-v->Tf; //error
	v->Out=(v->Pi+_IQ21mpy(v->Kp,v->Err)); //output
	
	if(v->Out>v->OutMax)
	{
		v->Pi=v->Pi+_IQ21mpy(v->Ki,v->Err)+_IQ21mpy(v->Kc,(v->OutMax-v->Out));
		v->Out=v->OutMax;
	}else if(v->Out<v->OutMin)
	{
		v->Pi =v->Pi+_IQ21mpy(v->Ki,v->Err)+_IQ21mpy(v->Kc,(v->OutMin-v->Out));
		v->Out=v->OutMin;
	}
	else
	{
		v->Pi=v->Pi+_IQ21mpy(v->Ki,v->Err);
	}
}

