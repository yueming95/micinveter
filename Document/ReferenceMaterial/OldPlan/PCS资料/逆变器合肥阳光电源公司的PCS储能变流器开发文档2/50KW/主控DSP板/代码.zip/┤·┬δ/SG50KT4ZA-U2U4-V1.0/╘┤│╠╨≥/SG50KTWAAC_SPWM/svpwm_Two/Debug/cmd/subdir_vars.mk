################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/DSP280x_Headers_nonBIOS.cmd \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/F2808.cmd 


