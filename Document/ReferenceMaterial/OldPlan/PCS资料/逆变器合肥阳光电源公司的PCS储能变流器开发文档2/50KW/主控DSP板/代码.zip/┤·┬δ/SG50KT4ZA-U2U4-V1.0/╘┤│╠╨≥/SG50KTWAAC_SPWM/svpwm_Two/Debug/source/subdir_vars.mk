################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_CodeStartBranch.asm \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_usDelay.asm 

C_SRCS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Adc.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_DefaultIsr.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_ECan.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_EPwm.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_GlobalVariableDefs.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Gpio.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_MemCopy.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieCtrl.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieVect.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Spi.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_SysCtrl.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/SVGen.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/Spi.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/can.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/corecontrol.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/main.c \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/pid.c 

OBJS += \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_CodeStartBranch.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_DefaultIsr.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_ECan.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_EPwm.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_GlobalVariableDefs.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Gpio.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_MemCopy.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_PieCtrl.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_PieVect.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Spi.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_SysCtrl.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_usDelay.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/SVGen.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/Spi.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/can.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/main.obj \
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/pid.obj 

ASM_DEPS += \
./source/DSP280x_CodeStartBranch.pp \
./source/DSP280x_usDelay.pp 

C_DEPS += \
./source/DSP280x_Adc.pp \
./source/DSP280x_DefaultIsr.pp \
./source/DSP280x_ECan.pp \
./source/DSP280x_EPwm.pp \
./source/DSP280x_GlobalVariableDefs.pp \
./source/DSP280x_Gpio.pp \
./source/DSP280x_MemCopy.pp \
./source/DSP280x_PieCtrl.pp \
./source/DSP280x_PieVect.pp \
./source/DSP280x_Spi.pp \
./source/DSP280x_SysCtrl.pp \
./source/SVGen.pp \
./source/Spi.pp \
./source/can.pp \
./source/corecontrol.pp \
./source/main.pp \
./source/pid.pp 

C_DEPS__QUOTED += \
"source\DSP280x_Adc.pp" \
"source\DSP280x_DefaultIsr.pp" \
"source\DSP280x_ECan.pp" \
"source\DSP280x_EPwm.pp" \
"source\DSP280x_GlobalVariableDefs.pp" \
"source\DSP280x_Gpio.pp" \
"source\DSP280x_MemCopy.pp" \
"source\DSP280x_PieCtrl.pp" \
"source\DSP280x_PieVect.pp" \
"source\DSP280x_Spi.pp" \
"source\DSP280x_SysCtrl.pp" \
"source\SVGen.pp" \
"source\Spi.pp" \
"source\can.pp" \
"source\corecontrol.pp" \
"source\main.pp" \
"source\pid.pp" 

OBJS__QUOTED += \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_Adc.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_CodeStartBranch.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_DefaultIsr.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_ECan.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_EPwm.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_GlobalVariableDefs.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_Gpio.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_MemCopy.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_PieCtrl.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_PieVect.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_Spi.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_SysCtrl.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\DSP280x_usDelay.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\SVGen.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\Spi.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\can.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\corecontrol.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\main.obj" \
"E:\work\SG50KT4ZA\program\SPWM\SG50KTWAAC_SPWM\Debug\pid.obj" 

ASM_DEPS__QUOTED += \
"source\DSP280x_CodeStartBranch.pp" \
"source\DSP280x_usDelay.pp" 

C_SRCS__QUOTED += \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Adc.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_DefaultIsr.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_ECan.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_EPwm.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_GlobalVariableDefs.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Gpio.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_MemCopy.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieCtrl.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieVect.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Spi.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_SysCtrl.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/SVGen.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/Spi.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/can.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/corecontrol.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/main.c" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/pid.c" 

ASM_SRCS__QUOTED += \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_CodeStartBranch.asm" \
"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_usDelay.asm" 


