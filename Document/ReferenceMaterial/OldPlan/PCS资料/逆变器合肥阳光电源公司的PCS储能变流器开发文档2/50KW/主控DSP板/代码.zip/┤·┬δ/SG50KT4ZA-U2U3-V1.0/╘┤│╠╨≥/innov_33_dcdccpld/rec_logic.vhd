--**************************************- 
--Rack Mount UPS Rec cpld Firmware
--2007.07.07
--**************************************- 
--
--
--
--
-----------------------------------------------------------------------
LIBRARY ieee;
USE ieee.STD_LOGIC_ARITH.all;
USE ieee.std_logic_1164.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;
--
--
ENTITY rec_logic IS
--
PORT
(
------------------------------------------------------------------------------------------
	gpio_0				        : in	std_logic;-- 
	gpio_1				        : in	std_logic;-- 
	gpio_2			        	: in	std_logic;-- 
	gpio_3			        	: in	std_logic;-- 
	gpio_4			        	: in	std_logic;-- 
	gpio_5			         	: in	std_logic;-- 
	
	gpio_6				        : in	std_logic;-- 
	gpio_7       				: in	std_logic;-- 
	gpio_8				        : in	std_logic;-- 
	gpio_9				        : in	std_logic;-- 
	gpio_10			            : in	std_logic;-- 
	gpio_11			         	: in	std_logic;-- 
	
	gpio_12_spi_b_simo			: in	std_logic;-- 
	gpio_13_spi_b_somi			: out	std_logic;-- 
	gpio_14_spi_b_clk			: in	std_logic;-- 
	gpio_15_spi_b_ste			: in	std_logic;-- 
	
	gpio_16				    	: in	std_logic;-- 
	gpio_17				     	: in	std_logic;-- 
	gpio_18				    	: in	std_logic;-- 
	gpio_19				    	: in	std_logic;-- 
	
	gpio_20				    	: in	std_logic;-- 
	gpio_21				    	: in	std_logic;-- 
	gpio_22_sci_b_txd			: in	std_logic;-- 
	gpio_23_sci_b_rxd			: out	std_logic;-- 
	gpio_24			        	: out	std_logic;-- 
	gpio_25				        : in	std_logic;-- 
	gpio_26				        : in	std_logic;-- 
	gpio_27				        : in	std_logic;-- 
	gpio_28_sci_a_rxd			: out	std_logic;-- 
	gpio_29_sci_a_txd			: in	std_logic;-- 
	--gpio_30					    : in	std_logic;-- 
	--gpio_31					    : out	std_logic;-- 
	gpio_30					    : out	std_logic;-- 
	gpio_31					    : in	std_logic;-- 

	gpio_32				    	: in	std_logic;-- 
	gpio_33				    	: in	std_logic;-- 
	gpio_34				     	: inout	std_logic;-- 

------------------------------------------------------------------------------------------	
	rec_ext_io_0				: out	std_logic;--rec: eeprom
	rec_ext_io_1				: out	std_logic;--rec: ad cs1
	rec_ext_io_2				: out	std_logic;--rec: ad cs2
	rec_ext_io_3				: out	std_logic;--rec: ad cs3
	rec_ext_io_4				: in	std_logic;--rec: soft start in

	rec_ext_io_5				: in	std_logic;--rec: rec_boot_en	
	rec_ext_io_6				: out	std_logic;--rec: soft start out
	rec_ext_io_7				: in	std_logic;--rec: module id0
	rec_ext_io_8				: in	std_logic;--rec: module type
	rec_ext_io_9				: in	std_logic;--rec: module ready       

	rec_ext_io_10				: in	std_logic;--rec: module id1        
	rec_ext_io_11				: in	std_logic;--rec: module id2
	rec_ext_io_12				: in	std_logic;--rec: module id3
	rec_ext_io_13				: out	std_logic;--rec: 
	rec_ext_io_14				: out	std_logic;--rec: ---gpio34

	rec_ext_io_15				: out	std_logic;--rec:  
	rec_ext_io_16				: out	std_logic;--rec: 
	rec_ext_io_17				: in	std_logic;--rec: bat earth short 
	rec_ext_io_18				: in	std_logic;--rec: power ok
	rec_ext_io_19				: in	std_logic;--rec: power fault

	rec_ext_io_20				: in	std_logic;--rec:  mod_otp 
	rec_ext_io_21				: in	std_logic;--rec: chg ovp
	rec_ext_io_22				: in	std_logic;--rec: bus ovp
	rec_ext_io_23				: in	std_logic;--rec: bridge short
	rec_ext_io_24				: out	std_logic;--rec: rec_reset

	rec_ext_io_25				: out	std_logic;--rec: fan pwm  
	rec_ext_io_26				: out	std_logic;--rec: other start from bat en
	rec_ext_io_27				: out	std_logic;--rec: rec_shutdown
	rec_ext_io_28				: out	std_logic;--rec: bat scr1 charger
	rec_ext_io_29				: out	std_logic;--rec: bat scr2 discharger

	rec_ext_io_30				: out	std_logic;--rec: chg pwm+
	rec_ext_io_31				: out	std_logic;--rec: chg pwm-
   rec_ext_io_32				: out	std_logic;--rec: scr a up
	rec_ext_io_33				: out	std_logic;--rec: scr a down		-- DC_IN_DRV:DC SWITCH driver
	rec_ext_io_34				: out	std_logic;--rec: scr b up

	rec_ext_io_35				: out	std_logic;--rec: scr b down		-- DC_SOFTSTART_RELAY
	rec_ext_io_36				: out	std_logic;--rec: scr c up
	rec_ext_io_37				: out	std_logic;--rec: scr c down		-- Relese_DRV
------------------------------------------------------------------------------------------	
	rec_inv_io_0				: out	std_logic;--rec off
	rec_inv_io_1				: out	std_logic;--rec fault					--WR
	rec_inv_io_2				: out	std_logic;--bat discharge status		--DATA
	rec_inv_io_3				: out	std_logic;--
	rec_inv_io_4				: out	std_logic;--

	rec_inv_io_5				: in	std_logic;--inv status /inv start

	rec_inv_io_6				: in	std_logic;--7line--STE
	rec_inv_io_7				: in	std_logic;--7line--WR
	rec_inv_io_8				: in	std_logic;--7line--DATA
	rec_inv_io_9				: out	std_logic;--7line--RECEIVE_OK

	rec_inv_io_10				: in	std_logic;--carrier_f
	rec_inv_io_11				: out	std_logic;-- module id0

	rec_inv_io_12				: in	std_logic;-- 								--INV RECEIVE OK
	rec_inv_io_13				: out	std_logic;-- power fault
	rec_inv_io_14				: out	std_logic;-- //module over temp

------------------------------------------------------------------------------------------	
	rec_da_clk				    : out	std_logic;
	rec_da_cs				    : out	std_logic;
	rec_da_data				    : out	std_logic;
	
	rec_ad_adj1				    : out	std_logic;
	rec_ad_adj2				    : out	std_logic;

	service_mode_in				: in	std_logic;

	rec_dsp_1_gh1				: out	std_logic;
	rec_dsp_1_gb1				: out	std_logic;
	rec_dsp_1_gh2				: out	std_logic;
	rec_dsp_1_gb2				: out	std_logic;
	rec_dsp_1_gh3				: out	std_logic;
	rec_dsp_1_gb3				: out	std_logic;

	rec_dsp_2_gh1				: out	std_logic;
	rec_dsp_2_gb1				: out	std_logic;
	rec_dsp_2_gh2				: out	std_logic;
	rec_dsp_2_gb2				: out	std_logic;
	rec_dsp_2_gh3				: out	std_logic;
	rec_dsp_2_gb3				: out	std_logic;

	rec_ds_a			     	: out	std_logic;
	rec_ds_b				    : out	std_logic;

   rec_set              : in 	std_logic;		--connect to GND, Always "0"


	rec_sci_txd			    	: out	std_logic;
	rec_sci_rxd				    : in	std_logic;
	
	rec_485_txd			  	    : out	std_logic;
	rec_485_rxd			    	: in	std_logic;
	
	rec_can_txd		     	    : out	std_logic;
	rec_can_rxd			    	: in	std_logic;
	
	rec_indictor                : out	std_logic;
	
	
	epo_n				    	: in	std_logic;
   rec_cpld_clk				: in	std_logic;
	rec_cpld_reset				: in	std_logic
);
END rec_logic;






ARCHITECTURE rtl OF rec_logic IS
--------------------------------------------------------------------------
function vote (a, b ,c : std_logic) return std_logic is
begin
	if a = b or a = c then
		return a;
	else
		return b;
	end if;
end vote;
--------------------------------------------------------------------------
--------------------------------------------------------------------------
signal			mex_io_count		: std_logic_vector(3 downto 0);
shared variable		mex_io_count_v16		: integer range 0 to 15;

signal			mex_io_count_2		: std_logic_vector(3 downto 0);
shared variable		mex_io_count_v16_2		: integer range 0 to 15;


signal			data_to_dsp		: std_logic_vector(15 downto 0);
signal			data_from_inv_cpld		: std_logic_vector(15 downto 0);
signal			data_to_inv_cpld			: std_logic_vector(15 downto 0);	--20111122tiajian


signal        transfer_onging   :std_logic;
signal        transfer_onging_2   :std_logic;

signal delay_cnt1 	: integer range 0 to 7;
signal delay_cnt2 	: integer range 0 to 7;


--shared variable				ex_io_count		: std_logic_vector(3 downto 0);
signal ex_io_count		: std_logic_vector(3 downto 0);

shared variable				ex_io_count_b		: std_logic_vector(3 downto 0);
shared variable		ex_io_count_v16_b		: integer range 0 to 15;
shared variable		ex_io_count_v16		: integer range 0 to 15;
--shared variable	ex_io_count_v8		: integer range 0 to 7;signal			ex_out_a_reg		: std_logic_vector(15 downto 0);

signal			ex_out_a_reg		: std_logic_vector(15 downto 0);
signal			ex_out_b_reg		: std_logic_vector(15 downto 0);
signal			ex_out_c_reg		: std_logic_vector(15 downto 0);
signal			ex_out_d_reg		: std_logic_vector(15 downto 0);

signal			ex_in_a			: std_logic_vector(15 downto 0);
signal			ex_in_b			: std_logic_vector(15 downto 0);
signal			ex_in_c			: std_logic_vector(15 downto 0);
signal			ex_in_d			: std_logic_vector(15 downto 0);

-------------------------------------------------------	
signal         rec_dsp_burned_ok     :std_logic;
signal         rec_cpld_burned_ok     :std_logic;

-------------------------------------------------------	
signal          fan_cs1	: std_logic;
signal          fan_cs2	: std_logic;
signal			fan_pwm_cnt		: integer range 0 to 511;
signal          fam_pwm_cmp_value : integer range 0 to 511;
-------------------------------------------------------	
signal	       led_cnt	 : integer range 0 to 268435455;
--constant         PWM_SS_TIME   : integer range 0 to 127 := 120;  --the longest aux IGBT Ton =  120*50ns=6us
-------------------------------------------------------	

signal       softstart_relay_control	: std_logic;

signal	   epo_verify_cnt	 : integer range 0 to 127;
signal     epo_status_older	: std_logic;
signal     epo_status_oldest	: std_logic;
signal     fault_clear  : std_logic;

signal     pwm_off_epo  :std_logic;-- epo rec  off signal

signal 	  rendebug		:std_logic;-- Debug
signal 	  rendebug1		:std_logic;-- Debug


signal 	  sig_rec_inv_io_9		:std_logic;-- 20111122tiaojian
signal 	  sig_rec_inv_io_12		:std_logic;-- 20111122tiaojian
------------------------------------------------------------------




BEGIN



-------------------------------------------------------------------	
--Process???SPI???? 
--???spi?clk??????spi?clk?????
-------------------------------------------------------------------	
process(gpio_15_spi_b_ste)-- Proc?IO Extend
begin
	ex_io_count_v16 := conv_integer(ex_io_count);
--	ex_io_count_v8 := conv_integer(ex_io_count(2 downto 0));

--	rec_temp <= ex_io_count;		
	
	if rec_cpld_reset = '0' then
		ex_io_count <= "1111";
		ex_out_a_reg <= "0000000000000000";
		ex_out_b_reg <= "0000000000000000";
		ex_out_c_reg <= "0000000000000000";
		ex_out_d_reg <= "0000000000000000";	
	--	gpio_13_spi_b_somi <= 'Z';	
	else--rec_cpld_reset = '1' 			
		if gpio_15_spi_b_ste = '1' then
--			ex_io_count <= "0000";
			ex_io_count <= "1111";
		else
--			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '1' then		-- output extend count +1
			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '0' then		-- output extend count +1
				ex_io_count <= ex_io_count - 1;
			end if;

--			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '0' then		-- output extend
			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '1' then		-- output extend
				if gpio_25 = '0' and gpio_26 = '0' and gpio_27 = '0' then 
					ex_out_a_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;
				elsif  gpio_25 = '1' and gpio_26 = '0' and gpio_27 = '0' then 
					ex_out_b_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				elsif  gpio_25 = '0' and gpio_26 = '1' and gpio_27 = '0' then 
					ex_out_c_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				elsif  gpio_25 = '1' and gpio_26 = '1' and gpio_27 = '0' then 
					ex_out_d_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				end if;	
			end if;
	
			if gpio_25 = '0' and gpio_26 = '0' then 					-- input extend
				gpio_13_spi_b_somi <= ex_in_a(ex_io_count_v16);
			elsif  gpio_25 = '1' and gpio_26 = '0' then 
				gpio_13_spi_b_somi <= ex_in_b(ex_io_count_v16);
			elsif  gpio_25 = '0' and gpio_26 = '1' then 
				gpio_13_spi_b_somi <= ex_in_c(ex_io_count_v16);
			elsif  gpio_25 = '1' and gpio_26 = '1' then 
				gpio_13_spi_b_somi <= ex_in_d(ex_io_count_v16);
			end if;	
		
	 end if;
		
	end if;--rec_cpld_reset 
end process;
-------------------------------------------------------------------	



-------------------------------------------------------------------	
--Process???CPLD?????????
--???/
-------------------------------------------------------------------	
process(rec_cpld_reset,rec_cpld_clk)-- Proc?Input
begin
if rec_cpld_reset = '0' then

else
   	if rec_cpld_clk'event and rec_cpld_clk = '0' then
      if rec_set = '0'  then
        rec_cpld_burned_ok <= '1';		-- always here.
      else
        rec_cpld_burned_ok <= '0';
      end if;
    end if;
end if;
end process;
-------------------------------------------------------------------	















-------------------------------------------------------------------	
--Process???EPO????
--???/
-------------------------------------------------------------------
process(rec_cpld_reset,rec_cpld_clk)-- Proc?
begin

if rec_cpld_reset = '0'  or rec_cpld_burned_ok = '0' or rec_dsp_burned_ok = '0' then 
    --------------------------------------
	    epo_verify_cnt <= 63;
	    epo_status_older <= '1';
	    epo_status_oldest <= '1';
    --------------------------------------
        pwm_off_epo <= '1';   --EPO?? ???????

    --------------------------------------

else
	if rec_cpld_clk'event and rec_cpld_clk = '1' then
	    --------------------------------------
         epo_status_older <= epo_n;
         epo_status_oldest <= epo_status_older;

         if epo_status_older = '0' and epo_status_oldest = '1' then		-- epo_n delay 
            epo_verify_cnt <= 1;
         end if;


         if epo_verify_cnt > 0 and  epo_verify_cnt < 60 then
            epo_verify_cnt <= epo_verify_cnt + 1;
         end if;

        --------------------------------------
         if  epo_status_oldest = '0' and epo_verify_cnt = 60 then
          pwm_off_epo <= '0';   --?? ?????
        --inv_indictor <= '1';
		 else 		
          pwm_off_epo <= '1';   --EPO?? ???????
         end if;--//end of epo
----------------------------------------------------------------		
    end if;--//end if clk
end if; --// end if reset
end process;
----------------------------------------------------------------		














-------------------------------------------------------------------	
--Process???MOSFET ??????
--???/
-------------------------------------------------------------------	
process(rec_cpld_reset,rec_cpld_clk)--Proc?Output
begin

if rec_cpld_reset = '0' then

 	rec_dsp_2_gh1 <= '0';			
	rec_dsp_2_gb1 <= '0';					
	rec_dsp_2_gh2 <= '0';						
	rec_dsp_2_gb2 <= '0';					
	rec_dsp_2_gh3 <= '0';					
	rec_dsp_2_gb3 <= '0';					
 
 	rec_dsp_1_gh1 <= '0';			
	rec_dsp_1_gb1 <= '0';	
	rec_dsp_1_gh2 <= '0';						
	rec_dsp_1_gb2 <= '0';					
	rec_dsp_1_gh3 <= '0';					
	rec_dsp_1_gb3 <= '0';					
--------------------------------------------	
else 


--   	if rec_cpld_clk'event and rec_cpld_clk = '0' then
--------------------------------------------	
       if   ex_out_d_reg(2) = '1'  then
    	 	rec_dsp_2_gh1 <= '0';			
			rec_dsp_2_gb1 <= '0';					
			rec_dsp_2_gh2 <= '0';						
			rec_dsp_2_gb2 <= '0';					
			rec_dsp_2_gh3 <= '0';					
			rec_dsp_2_gb3 <= '0';					
		 
		 	rec_dsp_1_gh1 <= '0';			
			rec_dsp_1_gb1 <= '0';					
			rec_dsp_1_gh2 <= '0';						
			rec_dsp_1_gb2 <= '0';					
			rec_dsp_1_gh3 <= '0';					
			rec_dsp_1_gb3 <= '0';	
        else 
	    --------------------------------------
		  	rec_dsp_1_gh1 <= not gpio_0;			
			rec_dsp_2_gh1 <= not gpio_0;				

			rec_dsp_1_gb1 <= not gpio_1;					
			rec_dsp_2_gb1 <= not gpio_1;				
        --------------------------------
			rec_dsp_1_gh2 <= not gpio_2;						
			rec_dsp_2_gh2 <= not gpio_2;					

			rec_dsp_1_gb2 <= not gpio_3;					
			rec_dsp_2_gb2 <= not gpio_3;					
        --------------------------------
			rec_dsp_1_gh3 <= not gpio_4;					
			rec_dsp_2_gh3 <= not gpio_4;				

			rec_dsp_1_gb3 <= not gpio_5;					
			rec_dsp_2_gb3 <= not gpio_5;		
	    --------------------------------------



        end if;  --//if epo
			----------------------------------------
 --    end if;  --//if clk
end if;  --//if reset


end process;
----------------------------------------------------------------------------------------
















-------------------------------------------------------------------	
--Process??????MOSFET????
--???/
-------------------------------------------------------------------	
process(rec_cpld_reset,rec_cpld_clk)--Proc?Output
begin

if rec_cpld_reset = '0' then
	--------------------------------------
	rec_ext_io_30 <= '0';	
	rec_ext_io_31 <= '0';	
	--------------------------------------
else 
        if   ex_out_d_reg(2) = '1'   then --battery mode
			--------------------------------------
			rec_ext_io_30 <= '0';	
			rec_ext_io_31 <= '0';	
			--------------------------------------
        else
	        rec_ext_io_30 <= not gpio_6; -- chg+ //?? REC_PWM_BAL+
	        rec_ext_io_31 <= not gpio_7;-- chg-//?? REC_PWM_BAL-
			----------------------------------------
        end if;  --//if epo
end if;  --//if reset
end process;
----------------------------------------------------------------------------------------










-------------------------------------------------------------------	
--Process???SPI?????? 
--???/
-------------------------------------------------------------------	
process(rec_cpld_reset)--Proc?Output
begin
------------------ rec_led----------------------
--if rec_cpld_reset = '0' then
--	rec_ds_a <= '0';
--	rec_ds_b <= '0';
--else
--	rec_ds_a <= ex_out_d_reg(0);
--	rec_ds_b <= ex_out_d_reg(1);
--end if;


---------------dsp ????????---------------
if ex_out_d_reg(8) = '1' then    	--  SOFTWARE_HARDWARE_OK
	rec_dsp_burned_ok <= '1';     
	else
	rec_dsp_burned_ok <= '0';
end if;
------------------ rec_da-------------------------
if  gpio_27 = '1' and gpio_15_spi_b_ste = '0' then		-- gpio_27 = '1'
			rec_da_cs <= '0';		
			rec_da_clk <= gpio_14_spi_b_clk;
			rec_da_data <= gpio_12_spi_b_simo;
else
			rec_da_cs <= '1';		
			rec_da_clk <= '0';
			rec_da_data <= '0';
end if;
--------------- rec_ext_io output--------------
    rec_ad_adj1 <= ex_out_d_reg(14);			-- AD_CS
    rec_ad_adj2 <= ex_out_d_reg(15);
----------------------------------------------


--------------- scr drive output-------------------
if rec_cpld_reset = '0' then--or rec_cpld_burned_ok = '0' or rec_dsp_burned_ok = '0' then
		rec_ext_io_32 <= '0';--				
		rec_ext_io_33 <= '0';--				
		rec_ext_io_34 <= '0';--				
		rec_ext_io_35 <= '0';--				
		rec_ext_io_36 <= '0';--	
		rec_ext_io_37 <= '0';--	
		rec_ext_io_28 <= '0';--	 
		rec_ext_io_29 <= '0';--	 
		fan_cs1 <=  '0';--	
		fan_cs2 <=  '0';--	
		fault_clear <= '0';--	
		rec_ext_io_24 <= '0';--	
		rec_ext_io_26 <= '0';--	
		rec_inv_io_0 <= '0';--	
--		rec_inv_io_1 <= '0';				--	20111123xiaogai
--		rec_inv_io_11 <= '0';--	
		softstart_relay_control<= '0';

else
        --A
--		rec_ext_io_32 <= vote(ex_out_a_reg(2),ex_out_b_reg(2),ex_out_c_reg(2));--		: out	
--		rec_ext_io_33 <= vote(ex_out_a_reg(3),ex_out_b_reg(3),ex_out_c_reg(3));--		: out	
        --B
--		rec_ext_io_34 <= vote(ex_out_a_reg(4),ex_out_b_reg(4),ex_out_c_reg(4));--		: out	
--		rec_ext_io_35 <= vote(ex_out_a_reg(5),ex_out_b_reg(5),ex_out_c_reg(5));--		: out	
        --C
--		rec_ext_io_36 <= vote(ex_out_a_reg(0),ex_out_b_reg(0),ex_out_c_reg(0));--		: out	
--		rec_ext_io_37 <= vote(ex_out_a_reg(1),ex_out_b_reg(1),ex_out_c_reg(1));--		scr out	
--       if  epo_n = '0' and epo_verify_cnt = 120 then
       if ex_out_d_reg(2) = '1' then

		rec_ext_io_32 <= '0';--				
		rec_ext_io_33 <= '0';--				
		rec_ext_io_34 <= '0';--				
		rec_ext_io_35 <= '0';--				
		rec_ext_io_36 <= '0';--	
		rec_ext_io_37 <= '0';--	
		rec_ext_io_28 <= '0';--	 
		rec_ext_io_29 <= '0';--	 
		
       else
      rec_ext_io_32 <= ex_out_a_reg(0);--		scr out	
		rec_ext_io_33 <= ex_out_a_reg(1);--		: out		DC_IN_DRV
		rec_ext_io_34 <= ex_out_a_reg(2);--		: out	
		rec_ext_io_35 <= ex_out_a_reg(3);--		: out		DC_SOFTSTART_RELAY
		rec_ext_io_36 <= ex_out_a_reg(4);--		: out	
		rec_ext_io_37 <= ex_out_a_reg(5);--					Relese_DRV
		rec_ext_io_29 <= ex_out_a_reg(6);--		discharge	bat scr2 discharger
		rec_ext_io_28 <= ex_out_a_reg(7);--		charger	    bat scr1 charger
       end if;


      fan_cs1 <= ex_out_a_reg(8);--			
      fan_cs2 <= ex_out_a_reg(9);--			
		rec_ext_io_26 <= ex_out_a_reg(10);--	
      rec_ext_io_24 <= ex_out_a_reg(12);--		REC_RESET	??	why using is same here	??
      fault_clear <= ex_out_a_reg(12);--		  	fault_reset	??	why using is same here	??
      rec_inv_io_0 <= ex_out_a_reg(13);--		REC_OFF to INV 1
 --   rec_inv_io_1 <= vote(ex_out_a_reg(15),ex_out_b_reg(15),ex_out_c_reg(15));--		REC_FAULT to INV 1	20111123xiaogai
 --   rec_inv_io_11 <= vote(ex_out_a_reg(12),ex_out_b_reg(12),ex_out_c_reg(12));--		
      softstart_relay_control <= ex_out_a_reg(11);--	KM_OPEN
  

-- to inv
end if;






--f  rec_ext_io_8 = '1'  then     -- bypass module
--        rec_ext_io_28 <= rec_inv_io_8;
--else                               
--		rec_ext_io_28 <= vote(ex_out_a_reg(6),ex_out_b_reg(6),ex_out_c_reg(6));--	
--end if;




------------------------------------------------------------
end process;
----------------------------------------------------------------------------------------







-------------------------------------------------------------------	
--Process???SPI?????? 
--???/
-------------------------------------------------------------------	
--process(epo_n)-- Proc?Input
process(rec_cpld_reset,rec_cpld_clk)
begin
-------------------------------------------------------------------------------------------

	ex_in_a(0) <= rec_ext_io_23;--bridge short
	ex_in_a(1) <= rec_ext_io_22;--bus ovp	
	ex_in_a(2) <= rec_ext_io_21;--chg ovp		
--	ex_in_a(3) <= '0';--		
	ex_in_a(4) <= rec_ext_io_19;--power fault		
	rec_inv_io_13 <= rec_ext_io_19;--power fault	

	ex_in_a(5) <= rec_ext_io_18;--		 power_ok
	ex_in_a(6) <= rec_ext_io_17;-- 	bat earth short 
	ex_in_a(7) <= rec_ext_io_9;--	module ready	
	ex_in_a(8) <= rec_ext_io_8;--	module type	

------------------------CHANGE-----------------------	
--*************************************************----	
--  ex_in_a(9) <= rec_ext_io_7;--rec: module id0   	
--	
--  ex_in_a(10) <= rec_ext_io_10;--rec: module id1
--  ex_in_a(11) <= rec_ext_io_11;--rec: module id2
--  ex_in_a(12) <= rec_ext_io_12;--rec: module id3 
-------------------------------------------------------	
    ex_in_a(9) <= rec_ext_io_10;--rec: module id1   	
    ex_in_a(10) <= rec_ext_io_11;--rec: module id2
    ex_in_a(11) <= rec_ext_io_12;--rec: module id3
    ex_in_a(12) <= rec_ext_io_7;--rec: module id0 
--*************************************************----	
-------------------------------------------------------	

    ex_in_a(13) <= service_mode_in;
 --   ex_in_a(14) <= rec_inv_io_6;  --????????????????
    ex_in_a(15) <= '0';  --
-------------------------------------------------------------------------------------------
    ex_in_b(7 downto 1) <= "0000000";-- reserved	
    ex_in_b(0) <= rec_ext_io_20; -- mod_otp
    ex_in_b(8) <= epo_n;          --	epo_n	
	ex_in_b(9) <= rec_inv_io_5;   --	inv status/inv start
--	ex_in_b(10) <= rec_inv_io_8; -- solar project//net inv state
	ex_in_b(13) <= rec_set;       --	??? ???????
----------------------------------------------------------------------
    ex_in_c(0) <= '0';   --Version control bit
    ex_in_c(1) <= '1';   --Version control bit 	
    ex_in_c(2) <= '0';   --Version control bit 
    ex_in_c(3) <= '0';   --Version control bit 	
------------------------------------------------------------
	--????????4????16???????????
	--0000  --->  
	--0001  --->  
	--0010  --->  
    --...
	--???????VxxxBxxxDxxx???Dxxx?CPLD?????V??
--------------------------------------------------------------
    ex_in_c(15 downto 10) <= "000000";-- reserved
	--ex_in_d(15 downto 0) <= "0000000000000000";--reserved
----------------------------------------------------------------------



end process;
----------------------------------------------------------------------







-------------------------------------------------------------------	
--Process???GPIO????????
--???/
-------------------------------------------------------------------
process(rec_cpld_reset,rec_cpld_clk)--Proc?Special_softswitch
begin
----------------------------------------------
	rec_ext_io_1 <= gpio_16;--rec: ad cs1		first sampling or second sampling cs  and choose deplay value  cs1
	rec_ext_io_2 <= gpio_17;--rec: ad cs2		choose deplay value  cs2
	rec_ext_io_3 <= gpio_18;--rec: ad cs3		choose deplay value  cs3
--	rec_inv_io_2 <= gpio_28_sci_a_rxd;-- discharge_mode
--	rec_inv_io_2 <= ex_out_a_reg(14);-- discharge_mode
	
	rec_inv_io_11 <= rec_ext_io_7; --mod_id0
	rec_inv_io_14 <= rec_ext_io_20;--mod otp		module over temperture protect
----------------------------------------------
-- 485
	rec_485_txd <= not gpio_29_sci_a_txd;		
	rendebug1 <= not gpio_6;	
   gpio_28_sci_a_rxd <= rec_485_rxd;
	
-- 232
	rec_sci_txd <= not gpio_22_sci_b_txd;
	gpio_23_sci_b_rxd <= not rec_sci_rxd;
----------------------------------------------
    gpio_24 <= rec_inv_io_10;     --carrier f	solar	   ECAP1, FROM INV
----------------------------------------------
-- can
-- can
	rec_can_txd	 <= gpio_31;	     	--CAN_Monitor_H	   	xiaogai
	gpio_30 <= rec_can_rxd; 				--CAN_Monitor_L
	
	
    rec_inv_io_4 <= ex_out_d_reg(1);		--module led status hsb		rec_fault
    rec_inv_io_3 <= ex_out_d_reg(0);		--module led status lsb

	
----------------flash update ??--------------
-- ??gpio_19
-----------------------------------------------

	if rec_ext_io_5 = '0' then 		-- rec_boot_en
	 gpio_34 <='0';
	else 
	 rec_ext_io_14 <= gpio_34; --
	 gpio_34 <= 'Z';
	end if;



end process;
-------------------------------------------------------------------	




-------------------------------------------------------------------	
--Process???-
--???
-------------------------------------------------------------------
process(rec_cpld_clk,rec_cpld_reset)-- soft start relay control
begin
if rec_cpld_reset = '0' then
  rec_ext_io_6 <= '1';	--soft_start_out
  rec_ext_io_27 <= '0';---rec shutdown disable
else
  if rec_cpld_clk'event and rec_cpld_clk = '0' then
--softstart_relay_control-----------------
-- input 0 means off
-- input 1 means on
   if softstart_relay_control = '1' then
	   rec_ext_io_6 <=  '0';-- on--solar		soft_start run
   else
	   rec_ext_io_6 <=  '1';-- off--solar
   end if;
  end if;
end if;

end process;
--------------------------------------------

-------------------------------------------------------------------	
--Process???-fan speed control-
--???????pwm,rec_ext_io_25???
-------------------------------------------------------------------
process(rec_cpld_clk,rec_cpld_reset)-- soft switch
begin
--------------------------------------------

if fan_cs2 = '0' and fan_cs1 = '0' then
fam_pwm_cmp_value <= 120;   --"001010000";    --0.6 14V
 
elsif fan_cs2 = '0' and fan_cs1 = '1' then
fam_pwm_cmp_value <= 148;   ---"010100000";  --0.74 16V

elsif fan_cs2 = '1' and fan_cs1 = '0' then
fam_pwm_cmp_value <= 168;   ---"011110000";  --20V output

else       --   '1'                '1'
fam_pwm_cmp_value <= 201;   --"101000000";   --1.0 24V
end if;

--------------------------------------------
if rec_cpld_reset = '0' then
   fan_pwm_cnt <= 0;    --"000000000";
   rec_ext_io_25 <= '0';   ----  no active fan pwm
else
   	if rec_cpld_clk'event and rec_cpld_clk = '0' then

         if  fan_pwm_cnt < 200  then
              fan_pwm_cnt <= fan_pwm_cnt + 1;
         else
               fan_pwm_cnt <= 0;   --"000000000";
         end if;

         if    fan_pwm_cnt < fam_pwm_cmp_value  then		
               rec_ext_io_25 <= '0';   ----  on		active fan 
         else
               rec_ext_io_25 <= '1';   ----  off
         end if;
    end if;
end if;

end process;
-------------------------------------------------------------------	



-------------------------------------------------------------------	
-------------------------------------------------------------------
process(rec_cpld_reset,rec_cpld_clk)		-- LED gpio_6
begin
if  rec_cpld_reset = '0' then
    led_cnt <= 0;
else

	rendebug <= gpio_6;
--  if rec_cpld_clk'event and rec_cpld_clk = '1' then 
--  if rendebug'event and rendebug = '1' then 
  if rendebug1'event and rendebug1 = '1' then 
      led_cnt <= led_cnt + 1;


--	  if  led_cnt = 10000 then  --20000000
	  if  led_cnt = 2000 then  --20000000
	        led_cnt <=  1;

--		   if led_temp_reg < 6  then
--		      led_temp_reg <= led_temp_reg + 1;
--		   end if;
	  end if;

  if  led_cnt < 1000 then  --10000000
 --      rec_ds_a <= '0';
--     rec_ds_b <= '1';
--ex_in_d(0)<= '1';
--ex_in_d(5)<= '0';
rec_indictor <= '0';			-- LED open
--rec_dsp_1_gh1 <= '1';
  else
--     rec_ds_a <= '1';
--      rec_ds_b <= '0';
--rec_dsp_1_gh1 <= '0';
--ex_in_d(0)<= '0';
--ex_in_d(5)<= '1';
rec_indictor <= '1';			-- LED close 
  end if;

  end if;
  



end if;
end process;


--process()
--begin
--end process;



--?????? 
process(rec_cpld_clk,rec_cpld_reset)-- Proc?IO Extend			SPI INV_CPLD-REC_CPLD
begin
	mex_io_count_v16 := conv_integer(mex_io_count);
	mex_io_count_v16_2 := conv_integer(mex_io_count_2);
if rec_cpld_reset = '0' then
		mex_io_count <= "1111";
		data_from_inv_cpld <= "0000000000000000";
        rec_inv_io_9 <= '0';  -- spi receive OK - 0
        transfer_onging <= '0';
        delay_cnt1 <= 7;
        delay_cnt2 <= 7;
		  
		  mex_io_count_2 <= "1111";
        rec_inv_io_1 <= '1';         --out--  --WR--carrier f
		  rec_inv_io_2 <= '0'; 	    --out--  --DATA--solar project//net inv status
        transfer_onging_2 <= '0';
		  
else--rec_cpld_reset = '1' 

	if rec_cpld_clk'event and rec_cpld_clk = '1' then		-- output extend	

		sig_rec_inv_io_12 <= rec_inv_io_12;      --in -- ReceiveOK--
	
		if rec_inv_io_6 = '1' then		--spiste
				mex_io_count <= "1111";
            rec_inv_io_9 <= '0';  -- OK - 0
            transfer_onging <= '0';
            delay_cnt1 <= 7;
            delay_cnt2 <= 7;
				
----------------------------------------------------------------------
            if  mex_io_count_v16_2 > 0 then
                   if transfer_onging_2 = '0' and   sig_rec_inv_io_12 = '0' then 	--receive is ok
					    rec_inv_io_2 <= data_to_inv_cpld(mex_io_count_v16_2);
			            rec_inv_io_1 <= '0';
			            transfer_onging_2 <= '1';		  -- ready to next data
 			            mex_io_count_2 <= mex_io_count_2 - 1;
--                      delay_cnt <= delay_cnt -1;
--		                delay_cnt <=1;
				    end if;
----------------------------------------------------------------------
  	               if  sig_rec_inv_io_12 = '1' then --and delay_cnt = 6  then   --receive is not ok
		                rec_inv_io_1 <= '1';
		                transfer_onging_2 <= '0';		-- it cannot transfer next data
		           end if;
            end if;-- end mex_io_count
----------------------------------------------------------------------------	
		else		--spiste "0"
		
				 mex_io_count_2 <= "1111";
			    rec_inv_io_1 <= '1'; 
			    rec_inv_io_2 <= '0'; 
	          transfer_onging_2 <= '0';
			
------------------------------------------------------------------------------	
            if 	mex_io_count = "1111"   then 
	            if  rec_inv_io_7 = '0' and transfer_onging = '0' then 
                data_from_inv_cpld(mex_io_count_v16) <= rec_inv_io_8;
	            rec_inv_io_9 <= '1';				
	            transfer_onging <= '1';	--transfer is going on
	            delay_cnt1 <=1;
                end if;
       ----------------------------------------------------------------------
                if delay_cnt1 < 3 then 
                delay_cnt1 <=  delay_cnt1 + 1;
                end if; 
       ----------------------------------------------------------------------
	            if  rec_inv_io_7 = '1' and delay_cnt1 = 3 then 
	            rec_inv_io_9 <= '0';			--RECEIVE OK
	            transfer_onging <= '0';
				mex_io_count <= mex_io_count - 1;
				delay_cnt2 <= 1;
                delay_cnt1 <= 7; 

	            end if;
	        end if;
------------------------------------------------------------------------------	
            if ( mex_io_count > 1 or mex_io_count = 1 ) and mex_io_count < "1111"   then
                   if transfer_onging = '0' and   rec_inv_io_7 = '0' and delay_cnt2 = 3 then 
                        data_from_inv_cpld(mex_io_count_v16) <= rec_inv_io_8;
			            rec_inv_io_9 <= '1';
			            transfer_onging <= '1';
			            delay_cnt1 <= 1; 
                   end if;
----------------------------------------------------------------------------
	                if delay_cnt1 < 3 then 
	                delay_cnt1 <=  delay_cnt1 + 1;
	                end if; 
----------------------------------------------------------------------------
		            if delay_cnt2 < 3 then 
	                delay_cnt2 <=  delay_cnt2 + 1;
	                end if; 
                ------------------------------------------------------------------
		            if  rec_inv_io_7 = '1' and delay_cnt1 = 3 then 
		                rec_inv_io_9 <= '0';
		                transfer_onging <= '0';
					    mex_io_count <= mex_io_count - 1;
						delay_cnt2 <= 1;
                        delay_cnt1 <= 7; 
		            end if;
            end if;-- end mex_io_count
----------------------------------------------------------------------------



        end if; --end if ste
    end if; -- end if clk
end if;--rec_cpld_reset 
end process;


--???????? 
-------------------------------------------------------------------	
process(rec_cpld_clk,rec_cpld_reset)
begin

--rec_ds_a <= data_from_inv_cpld(15);		--REC Debug LED1
data_to_inv_cpld(15 downto 3) <= ex_out_c_reg(15 downto 3);

rec_ds_a <= ex_out_d_reg(4);
rec_ds_b <= data_from_inv_cpld(14);		--REC Debug LED2

ex_in_d(12 downto 0) <= data_from_inv_cpld(13 downto 1);--reserved

ex_in_a(3) <= data_from_inv_cpld(0);

ex_in_a(14) <= data_from_inv_cpld(15);--rec_inv_io_6;  --????????????????
ex_in_b(10) <= data_from_inv_cpld(15);--rec_inv_io_8; -- solar project//net inv state

end process;
---------------------------------------------------------------


-------------------------------------------------------------------
-- COMPONENT instantiations
-------------------------------------------------------------------
END rtl;
