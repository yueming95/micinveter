/***************************************************************************************
* 
* Filename: 		SysCanApp.h
* Contributor:
* Author: 		Wang Zhihua	
* Date: 			3/17/2008
* Copyright 		2008 ENPC Corporation, All Rights Reserved
*
* Description: 	
* 
* 
* Version
* Last rev by:		Wang Zhihua
* Last rev date:	3/17/2008
* Last rev desc:	
****************************************************************************************/
#ifndef SYS_DATA_EXCHG_NEW_H
#define SYS_DATA_EXCHG_NEW_H

//---------------------------------------------------------------------------
//Head files
//#include "Define.h"
//#include "SysCanApp.h"
#include "SysCanDefine.h"


#define XMIT_INFO_MAX_LEN 100

#define CTRL_MSG_OBJ_SIZE 27

typedef struct
{
	UINT16 bSrvcCod	:8;
	UINT16 bMsgLen	:8;
	UINT16 *pData;
	//_REC_ANALOG_T DataBuff;
}REC_ANALOG_MSG_OBJ_T;


typedef struct
{
	REC_ANALOG_MSG_OBJ_T MsgObj[REC_ANALOG_RECV_MSG_SIZE];
	_REC_RECV_ANALOG_T DataBuff;
}REC_ANALOG_RECV_OBJ_T;

typedef struct
{
	UINT16 bSrvcCod	:8;
	UINT16 bMsgLen	:8;
	UINT16 *pData;
}REC_CFG_MSG_T;

typedef struct
{
	UINT16 bFromMon 	:8;
	UINT16 bToMon		:8;
}REC_FIRST_CFG_FLAG_T;

typedef struct
{
	REC_CFG_MSG_T FromMon[REC_CFG_FROM_MON_OBJ_SIZE];
	REC_CFG_MSG_T ToMon[REC_CFG_TO_MON_OBJ_SIZE];
	REC_FIRST_CFG_FLAG_T FirstCfgFlag;
}REC_CFG_INFO_T;

typedef struct
{
	UINT16 uEventID;
	UINT16 bEventInWord: 	2;
	UINT16 bOffSet:			4;
	UINT16 		  :			10;
	UINT16 uMaskVal;
	UINT16 uSetVal;
}MONITOR_EVENT_MSG_T;

	//Ӧ�ò�֡��ʽ
	typedef struct msg_data_struct
	{
		UINT16 u16MsgClass;
		UINT16 u16ServiceCode 	: 8;
		UINT16 u16DeltOver		: 8;
		UINT16 u16XmReDirection;	
		UINT16 u16ByteLength;
		UINT16 u16DataNum;
		Uint16 *pDataPtr;

	}MONITOR_APDU_T;			


//EXTERN UINT16 uInvAnalogLen[INV_ANALOG_MSG_OBJ_SIZE];

enum MONITOR_MSG_CLASS_ENUM
{
	CFG_MSG_CLASS = 10,
	CTRL_MSG_CLASS = 6,
	ALRMSTATE_MSG_CLASS = 8,
	ANALOG_MSG_CLASS = 3,
	MSG_CLASS_EOL
};
//-------------------------------------------------------------------------------
//������Ϣ
class SysDataExchgNEW;
typedef VOID (SysDataExchgNEW::*m_MSG_RECV_T)(VOID);

//������Ϣ��ش����ṹ��
typedef struct
{
	UINT16 bSrvcCode:	7;
	UINT16 bLength	:	4;
	UINT16 			:	5;
	m_MSG_RECV_T MsgRecvFcb;
}REC_CTRL_MSG_T;


class SysDataExchgNEW
{
public:
			VOID m_SciRecvMsgdelt(IN MONITOR_APDU_T *pApdu);
			VOID m_CanRecvMsgdelt(IN MONITOR_APDU_T *pApdu);
			MONITOR_APDU_T Data_pApduObj;

		   	VOID FaultClrCmd(VOID);
			VOID MasterStartupCmd(VOID);
			VOID MasterShutCmd(VOID);
			VOID RelayOpenCmd(VOID);
			VOID RelayCloseCmd(VOID);

			VOID MaualStartupCmd(VOID);
			VOID MaualShutCmd(VOID);
			VOID EpoCmd(VOID);
			VOID AbnormalShutConfirmCmd(VOID);
			VOID AbnormalShutCancelCmd(VOID);
			VOID IndirectSwitchCmd(VOID);

			VOID RecFlashUpdate(VOID);
			VOID InvFlashUpdate(VOID);
			VOID BypFlashUpdate(VOID);

private:
			INT16	CfgMsgRecvProc(IN MONITOR_APDU_T *pApdu);		//����
			INT16	CtrlMsgRecvProc(IN MONITOR_APDU_T *pApdu);		//��������
			INT16	AlrmStateMsgXmitProc(IN MONITOR_APDU_T *pApdu);	//�澯
//			INT16	StateMsgRecvProc(IN MONITOR_APDU_T *pApdu);		//״̬
			INT16	AnalogMsgRecvProc(IN MONITOR_APDU_T *pApdu);	//ģ������������DC_DSP
			INT16	AnalogMsgXmitProc(IN MONITOR_APDU_T *pApdu);	//ģ�������������
			
			INT16 CfgMsgFromMonProc(IN MONITOR_APDU_T *pApdu, IN UINT16 u16Idx);
			INT16 SyncTimeMsgProc( IN MONITOR_APDU_T *pApdu);
			INT16 GetFaultData(OUT MONITOR_APDU_T *pApdu);


			REC_ANALOG_RECV_OBJ_T Monitor_AnalogRecvMsgObj;
	
			//Cfg msg
			REC_CFG_INFO_T m_CfgMsgObj;

		 	//Ctrl msg
		 	REC_CTRL_MSG_T m_CtrlMsgObj[CTRL_MSG_OBJ_SIZE];

			Uint16 m_CanAlrmStateMsgObj[2];

			UCHAR m_ucFaultClearFlag;
			struct 
			{
				MONITOR_APDU_T MonitorCanApdu;
				Uint16 DataBuff[50];
			}m_CanXmitMsgBuff;

			UINT16 m_u16FlashupdateMsg;
			UINT16 m_u16FlashupdateSecnodMsg;

};



#endif 

































