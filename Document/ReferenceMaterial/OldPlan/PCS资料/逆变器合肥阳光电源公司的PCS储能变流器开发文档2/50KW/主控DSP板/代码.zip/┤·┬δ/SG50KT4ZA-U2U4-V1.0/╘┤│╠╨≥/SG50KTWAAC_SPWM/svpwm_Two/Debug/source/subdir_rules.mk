################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Adc.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_Adc.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_CodeStartBranch.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_CodeStartBranch.asm $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_CodeStartBranch.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_DefaultIsr.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_DefaultIsr.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_DefaultIsr.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_ECan.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_ECan.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_ECan.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_EPwm.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_EPwm.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_EPwm.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_GlobalVariableDefs.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_GlobalVariableDefs.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_GlobalVariableDefs.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Gpio.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Gpio.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_Gpio.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_MemCopy.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_MemCopy.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_MemCopy.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_PieCtrl.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieCtrl.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_PieCtrl.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_PieVect.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_PieVect.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_PieVect.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Spi.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Spi.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_Spi.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_SysCtrl.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_SysCtrl.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_SysCtrl.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_usDelay.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_usDelay.asm $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/DSP280x_usDelay.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/SVGen.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/SVGen.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/SVGen.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/Spi.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/Spi.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/Spi.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/can.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/can.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/can.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/corecontrol.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/corecontrol.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/main.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/main.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/main.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/pid.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/pid.c $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" --include_path="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include" -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --preproc_with_compile --preproc_dependency="source/pid.pp" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


