// TI File $Revision: /main/2 $
// Checkin $Date: December 2, 2004   11:50:58 $
//###########################################################################
//
// FILE:	DSP280x_Gpio.c
//
// TITLE:	DSP280x General Purpose I/O Initialization & Support Functions.
//
//###########################################################################
// $TI Release: DSP280x Header Files V1.60 $
// $Release Date: December 3, 2007 $
//###########################################################################

#include "DSP280x_Device.h"     // DSP280x Headerfile Include File
#include "DSP280x_Examples.h"   // DSP280x Examples Include File

//---------------------------------------------------------------------------
// InitGpio: 
//---------------------------------------------------------------------------
// This function initializes the Gpio to a known (default) state.
//
// For more details on configuring GPIO's as peripheral functions,
// refer to the individual peripheral examples and/or GPIO setup example. 
void InitGpio(void)
{
	   EALLOW;
	    GpioCtrlRegs.GPAMUX1.all = 0x0FF405550;  // GPIO functionality GPIO0-GPIO15
	    										 // Config GPIO0~1 and GPIO8~10 as IO
	    										 // Config GPIO2~7 and GPIO11 as PWM
	    										 // Config GPIO12~15 as SPIB
	    GpioCtrlRegs.GPAMUX2.all = 0x5555FF00;   // GPIO functionality GPIO16-GPIO31
	    										 // Config GPIO16~19 as IO
	    										 // Config GPIO20~23 as CANB/SCIB
	    										 // Config GPIO24~27 as ECAP
	    										 // Config GPIO28~31 as SCIA/CANA
	    GpioCtrlRegs.GPBMUX1.all = 0x00000005;   // GPIO functionality GPIO32-GPIO34
	    										 // Config GPIO32~34 as IO

	    // Each input can have different qualification
	    GpioCtrlRegs.GPAQSEL1.all = 0x00000000;      // GPIO0-GPIO15 Synch to SYSCLKOUT
	    GpioCtrlRegs.GPAQSEL2.all = 0x00000000;      // GPIO16-GPIO31 Synch to SYSCLKOUT
	    GpioCtrlRegs.GPBQSEL1.all = 0x00000000;      // GPIO32-GPIO34 Synch to SYSCLKOUT

	    // Pull-ups can be enabled or disabled.
	    GpioCtrlRegs.GPAPUD.all = 0x80000000;        // Pullup's enabled GPIO0-GPIO30 Pullup's disabled GPIO31
	    GpioCtrlRegs.GPBPUD.all = 0x00000000;        // Pullup's enabled GPIO32-GPIO34

	    // Set IO ports initial status
	    GpioDataRegs.GPASET.all = 0x00000100;    // Set GPIO8 High
	    GpioDataRegs.GPACLEAR.all = 0xFFFFFEFF;  // Set GPIO0-GPIO31 Low(GPIO8 Exclude)
	    GpioDataRegs.GPBSET.all = 0x00000000;	 // Set GPIO32 High��LED��
	    GpioDataRegs.GPBCLEAR.all = 0x00000007;  // Set GPIO33-GPIO34 Low
	    GpioCtrlRegs.GPADIR.all = 0x0BFFFFFFF;   // GPIO0-GPIO29.GPIO31 are GP outputs GPIO30 is input
	    GpioCtrlRegs.GPBDIR.all = 0x00000007;        // GPIO33 as input, GPIO32,GPIO34 as output    7 xiaogai
		GpioDataRegs.GPBSET.all = 0x00000002;	  //Set GPIO33 High��PWM���ǿ��Ϊ����̬
		EDIS;
}	
	
//===========================================================================
// End of file.
//===========================================================================
