# FIXED

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Adc.c
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Device.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Adc.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DevEmu.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_CpuTimers.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECan.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECap.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EPwm.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EQep.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Gpio.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2c.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieCtrl.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieVect.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Spi.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Sci.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_SysCtrl.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_XIntrupt.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Examples.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_GlobalPrototypes.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ePwm_defines.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2C_defines.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DefaultISR.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/corecontrol.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/IQmathLib.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/DSP280x_Adc.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Spi.h

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/DSP280x_Adc.c: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Device.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Adc.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DevEmu.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_CpuTimers.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECan.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECap.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EPwm.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EQep.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Gpio.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2c.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieCtrl.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieVect.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Spi.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Sci.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_SysCtrl.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_XIntrupt.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Examples.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_GlobalPrototypes.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ePwm_defines.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2C_defines.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DefaultISR.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/corecontrol.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/IQmathLib.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Spi.h: 
