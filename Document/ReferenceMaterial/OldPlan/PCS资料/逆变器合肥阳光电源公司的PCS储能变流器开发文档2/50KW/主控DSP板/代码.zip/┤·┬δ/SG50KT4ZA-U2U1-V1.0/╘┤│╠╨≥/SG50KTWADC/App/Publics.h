#ifndef PUBLICS_H
#define PUBLICS_H

class Class_Battery ;
class Class_Charger ;
class Class_ChargerAlgorithm;
class Class_DCBus ;
class Class_Debug ;
class Class_DigitalIO ;
class Class_Discharger;
class Class_DischargerAlgorithm;
class Class_EEPROM ;
class Class_Fan;
class Class_LogicManager;
class Class_MonitorInterface ;
class Class_Rectifier;
class Class_RectifierAlgorithm;
class Class_System ;
class Class_Utility ;

class SysCanProtocol;
class SysCanApp;
class SysCanDataExchg;
class SysCanNEW;
class SysDataExchgNEW;

class SysCanRecvQueue;
class SysCanXmitQueue;
class SysCanFragXmitQueue;

extern Class_Battery 		objBattery;
extern Class_Charger 		objCharger;
extern Class_ChargerAlgorithm objChargerAlgorithm;
extern Class_DCBus 		objDCBus;
extern Class_Debug 		objDebug;
extern Class_DigitalIO 	objDigitalIO;
extern Class_Discharger 	objDischarger;
extern Class_DischargerAlgorithm objDischargerAlgorithm;
extern Class_EEPROM 		objEEPROM;
extern Class_Fan objFan;
extern Class_LogicManager 	objLogicManager;
extern Class_MonitorInterface 	objMonitorInterface;
extern Class_Rectifier 	objRectifier;
extern Class_RectifierAlgorithm objRectifierAlgorithm;
extern Class_System 		objSystem;
extern Class_Utility 		objUtility;

extern SysCanProtocol ProtocolObj;
extern SysCanApp SysCanAppObj;
//Ӧ�ò���Ϣ��������
extern SysCanDataExchg DataExchgObj;
extern SysDataExchgNEW ObjDataExchgNEW;

//���ж�����
//extern SysCanRecvQueue SysCanRecvQueueObj;
//extern SysCanXmitQueue SysCanXmitQueueObj;
//extern SysCanFragXmitQueue SysCanFragXmitQueueObj;

typedef union
{
  	long	dword;
	struct
	{
		UINT16 breserved1:8;
		UINT16 breserved2:8;
		UINT16 breserved3:8;
		UINT16 breserved4:6;
		UINT16 bit31:1;
		UINT16 breserved5:1;
	}	bits;
}MYLONGSQRT;


#define	UpDownLimit16(Value,UpValue,DownValue)	{Value = (Value >= UpValue) ? UpValue : Value;	Value = (Value <= DownValue) ? DownValue : Value;}                                                                                                                                              
#define	UpDownLimit32(Value,UpValue,DownValue)	{Value = (Value >= UpValue) ? UpValue : Value;	Value = (Value <= DownValue) ? DownValue : Value;}

#define	DownLimit16(Value,DownValue){Value = (Value <= DownValue) ? DownValue : Value;}
#define	UpLimit16(Value,UpValue){Value = (Value >= UpValue) ? UpValue : Value;}

//#define	abs(x)	((x >= 0) ? (x) : (-(x)))	
#define	s2u(x)	(*((UINT16*)(&x)))								//struct->uint
#define	SignInt(input)	(input > 0)

extern const INT16 i16_ArcCosTab[1030];
extern const INT16 i16_SinTab[1030];
extern const INT16 i16_SqrtTab[1026];
extern const INT16 i16_VbusInvTab[1010];
extern const INT16 i16_InvModeTab[1040];

INT16 CalSin(INT16 Angle);
INT16 CalSqrt(long ax);		
UINT16 uHysteresis(const UINT16 *uTabAddr,INT16 iVal,UINT16 uOldFlg);

#endif



