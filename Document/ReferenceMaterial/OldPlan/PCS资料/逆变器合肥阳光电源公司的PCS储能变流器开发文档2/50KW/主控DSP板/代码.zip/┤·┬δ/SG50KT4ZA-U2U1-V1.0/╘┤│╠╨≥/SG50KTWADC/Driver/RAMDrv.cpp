#include "RAMDrv.h"



void	Class_RAMDrv::Drv_Init(void)
{

}

void	Class_RAMDrv::Drv_RamCheck(void)
{
	volatile UINT16 *addr;
	UINT16 u16_i;
															//memery check M1[0x400,0x800]
	addr = (UINT16 *) 0x0400;
	for (u16_i = 0x0000; u16_i < 0x0400; u16_i++)
	{
		*(addr + u16_i) = 0x5555;
		if (*(addr + u16_i) != 0x5555)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0xaaaa;
		if (*(addr + u16_i) != 0xaaaa)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0x0000;
	}

															//memery check L0&L1[0x08000,0x0A000]
	addr = (UINT16 *) 0x08000;
	for (u16_i = 0x0000; u16_i < 0x02000; u16_i++)
	{
		*(addr + u16_i) = 0x5555;
		if (*(addr + u16_i) != 0x5555)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0xaaaa;
		if (*(addr + u16_i) != 0xaaaa)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0x0000;
	}

													//memery check H0[0x3FA000,0x3FC000]
	addr = (Uint16 *) 0x3FA000;
	for (u16_i = 0x0000; u16_i < 0x02000; u16_i++)
	{
		*(addr + u16_i) = 0x5555;
		if (*(addr + u16_i) != 0x5555)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0xaaaa;
		if (*(addr + u16_i) != 0xaaaa)
		{
			m_u16_RamCheckErr = 1;
		}
		*(addr + u16_i) = 0x0000;
	}
	
	if(m_u16_RamCheckErr == 1)
	{
		while(1)
		{
			asm(" nop");
		}
	}
}
//������������
void	Class_RAMDrv::Drv_MemCopy(UINT16 *SourceAddr, UINT16* SourceEndAddr, UINT16* DestAddr)
{
	while(SourceAddr < SourceEndAddr)
    {
       *DestAddr++ = *SourceAddr++;
    }
    return;
}
//============================================================
// End of file.
//============================================================
