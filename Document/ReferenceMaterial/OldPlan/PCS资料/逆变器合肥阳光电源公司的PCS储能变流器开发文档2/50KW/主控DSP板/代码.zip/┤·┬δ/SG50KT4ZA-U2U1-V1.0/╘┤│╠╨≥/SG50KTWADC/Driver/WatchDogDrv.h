/*==========================================================*/
/* Title		:	WatchDogDrv.h							*/
/* Description	: 	Class_WatchDogDrv definition			*/
/* Date			:	Oct.2007								*/
/*==========================================================*/

#ifndef DSP280x_WDDRV_H
#define DSP280x_WDDRV_H

//============================================================
//	Class_WatchDogDrv���ⲿ�Ľӿ�
//	1)����
//	2)
//============================================================
class Class_WatchDogDrv
{
	private:

	public:
		void	Drv_Init(void);								//��ʼ��
		void	Drv_DisableDog(void);						//This function disables the watchdog timer
		void	Drv_EnableDog(void);						//This function enables the watchdog timer.
		void	Drv_KickDog(void);							//This function resets the watchdog timer.
};

#endif

//============================================================
// End of file.
//============================================================
