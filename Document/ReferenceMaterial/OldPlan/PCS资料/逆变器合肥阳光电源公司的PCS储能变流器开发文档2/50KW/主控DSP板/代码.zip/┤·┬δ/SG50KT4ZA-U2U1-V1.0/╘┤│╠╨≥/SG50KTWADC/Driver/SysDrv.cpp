#include "SysDrv.h"



interrupt void EPWM1_PERIOD_INT_ISR(void);
interrupt void c_int5(void);


interrupt void PIE_RESERVED(void)
{
	;
}


//��ʼ��
void	Class_SysDrv::Drv_Init(void)							
{
	asm("	SETC 	SXM");									//Clear Sign Extension Mode bit
	asm("	SETC	OVM");									// Reset Overflow Mode bit
	
}



//This function initializes the PLLCR register.
void	Class_SysDrv::Drv_InitPLL(void)
{
	UINT32 u32_Delay1sec = 0;
	
   // Make sure the PLL is not running in limp mode
   if (SysCtrlRegs.PLLSTS.bit.MCLKSTS != 0)
   {
      	// Missing external clock has been detected
      	// Replace this line with a call to an appropriate
      	// SystemShutdown(); function.
		asm("        ESTOP0");
		while(1)
		{
			u32_Delay1sec++;
			if (u32_Delay1sec > 1800)						//Limp Mode ģʽ�£�CPU��ʱ��ֻ��1-5MHz��LED��˸
			{
				u32_Delay1sec = 0;
			}
			if (u32_Delay1sec == 900)
			{
				m_i16_ClockMissing = 1;
			}
		}
   }

   // CLKINDIV MUST be 0 before PLLCR can be changed from 0x0000. It is set to 0 by an external reset XRSn
   if (SysCtrlRegs.PLLSTS.bit.CLKINDIV != 0)
   {
       SysCtrlRegs.PLLSTS.bit.CLKINDIV = 0;
   }

   // Change the PLLCR
   if (SysCtrlRegs.PLLCR.bit.DIV != 0x0A)
   {

      EALLOW;
     
      // Before setting PLLCR turn off missing clock detect logic
      SysCtrlRegs.PLLSTS.bit.MCLKOFF = 1;					 
      SysCtrlRegs.PLLCR.bit.DIV = 0x0A;						//SYSCLKOUT=20M*10/2=100M
      EDIS;

      // Optional: Wait for PLL to lock.
      // During this time the CPU will switch to OSCCLK/2 until
      // the PLL is stable.  Once the PLL is stable the CPU will
      // switch to the new PLL value.
      //
      // This time-to-lock is monitored by a PLL lock counter.
      //
      // Code is not required to sit and wait for the PLL to lock.
      // However, if the code does anything that is timing critical,
      // and requires the correct clock be locked, then it is best to
      // wait until this switching has completed.

      // Wait for the PLL lock bit to be set.
      // Note this bit is not available on 281x devices.  For those devices
      // use a software loop to perform the required count.

      // The watchdog should be disabled before this loop, or fed within
      // the loop via ServiceDog().

	  // Uncomment to disable the watchdog
      objWatchDogDrv.Drv_DisableDog();

      while(SysCtrlRegs.PLLSTS.bit.PLLLOCKS != 1)
      {
	      // Uncomment to service the watchdog
          // ServiceDog();
      }

      EALLOW;
      SysCtrlRegs.PLLSTS.bit.MCLKOFF = 0;
      EDIS;
    }
}						


//This function initializes the clocks to the peripheral modules.
void	Class_SysDrv::Drv_InitPeripheralClocks(void)		
{
	EALLOW;
	
	// HISPCP/LOSPCP prescale register settings, normally it will be set to default values
	SysCtrlRegs.HISPCP.all = 0x00000;						//High speed clock=100M
	SysCtrlRegs.LOSPCP.all = 0x00000;						//Low  speed clock=100M
	SysCtrlRegs.XCLK.bit.XCLKOUTDIV = 2;					//XCLKOUT=SYSCLK=100M

	// Peripheral clock enables set for the selected peripherals.
   	SysCtrlRegs.PCLKCR0.bit.ADCENCLK = 1;					// ADC
   	SysCtrlRegs.PCLKCR0.bit.I2CAENCLK = 1;   				// I2C

   	SysCtrlRegs.PCLKCR0.bit.SPIAENCLK = 0;     				// SPI-A
   	SysCtrlRegs.PCLKCR0.bit.SPIBENCLK = 1;     				// SPI-B
   	SysCtrlRegs.PCLKCR0.bit.SPICENCLK = 0;     				// SPI-C
   	SysCtrlRegs.PCLKCR0.bit.SPIDENCLK = 0;     				// SPI-D

   	SysCtrlRegs.PCLKCR0.bit.SCIAENCLK = 1;     				// SCI-A
   	SysCtrlRegs.PCLKCR0.bit.SCIBENCLK = 1;     				// SCI-B

   	SysCtrlRegs.PCLKCR0.bit.ECANAENCLK = 1;    				// eCAN-A
   	SysCtrlRegs.PCLKCR0.bit.ECANBENCLK = 1;    				// eCAN-B

   	SysCtrlRegs.PCLKCR1.bit.ECAP1ENCLK = 1;  				// eCAP1
   	SysCtrlRegs.PCLKCR1.bit.ECAP2ENCLK = 0;  				// eCAP2
   	SysCtrlRegs.PCLKCR1.bit.ECAP3ENCLK = 0;  				// eCAP3
   	SysCtrlRegs.PCLKCR1.bit.ECAP4ENCLK = 0;  				// eCAP4

   	SysCtrlRegs.PCLKCR1.bit.EPWM1ENCLK = 1;  				// ePWM1
   	SysCtrlRegs.PCLKCR1.bit.EPWM2ENCLK = 1;  				// ePWM2
   	SysCtrlRegs.PCLKCR1.bit.EPWM3ENCLK = 1;  				// ePWM3
   	SysCtrlRegs.PCLKCR1.bit.EPWM4ENCLK = 1;  				// ePWM4
   	SysCtrlRegs.PCLKCR1.bit.EPWM5ENCLK = 1;  				// ePWM5
   	SysCtrlRegs.PCLKCR1.bit.EPWM6ENCLK = 1;  				// ePWM6

   	SysCtrlRegs.PCLKCR1.bit.EQEP1ENCLK = 0;  				// eQEP1
   	SysCtrlRegs.PCLKCR1.bit.EQEP2ENCLK = 0;  				// eQEP2

   	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;   				// Enable TBCLK within the ePWM

   	EDIS;
}	


//This function initializes the PIE control registers to a known state.
void	Class_SysDrv::Drv_InitPieCtrl(void)
{
	// Disable the PIE
    PieCtrlRegs.PIECTRL.bit.ENPIE = 0;

	// Clear all PIEIER registers:
	PieCtrlRegs.PIEIER1.all = 0;
	PieCtrlRegs.PIEIER2.all = 0;
	PieCtrlRegs.PIEIER3.all = 0;
	PieCtrlRegs.PIEIER4.all = 0;
	PieCtrlRegs.PIEIER5.all = 0;
	PieCtrlRegs.PIEIER6.all = 0;
	PieCtrlRegs.PIEIER7.all = 0;
	PieCtrlRegs.PIEIER8.all = 0;
	PieCtrlRegs.PIEIER9.all = 0;
	PieCtrlRegs.PIEIER10.all = 0;
	PieCtrlRegs.PIEIER11.all = 0;
	PieCtrlRegs.PIEIER12.all = 0;

	// Clear all PIEIFR registers:
	PieCtrlRegs.PIEIFR1.all = 0;
	PieCtrlRegs.PIEIFR2.all = 0;
	PieCtrlRegs.PIEIFR3.all = 0;
	PieCtrlRegs.PIEIFR4.all = 0;
	PieCtrlRegs.PIEIFR5.all = 0;
	PieCtrlRegs.PIEIFR6.all = 0;
	PieCtrlRegs.PIEIFR7.all = 0;
	PieCtrlRegs.PIEIFR8.all = 0;
	PieCtrlRegs.PIEIFR9.all = 0;
	PieCtrlRegs.PIEIFR10.all = 0;
	PieCtrlRegs.PIEIFR11.all = 0;
	PieCtrlRegs.PIEIFR12.all = 0;
}			


//This function initializes the PIE vector table to a known state.This function must be executed after boot time.
void	Class_SysDrv::Drv_InitPieVectTable(void)
{
	const struct	PIE_VECT_TABLE 	st_PieVectTableInit = {

      PIE_RESERVED, 										// 0  Reserved space                  
      PIE_RESERVED,  				                        // 1  Reserved space                  
      PIE_RESERVED, 				                        // 2  Reserved space                  
      PIE_RESERVED,  				                        // 3  Reserved space                  
      PIE_RESERVED,  				                        // 4  Reserved space                  
      PIE_RESERVED,  				                        // 5  Reserved space                  
      PIE_RESERVED,  				                        // 6  Reserved space                  
      PIE_RESERVED,  				                        // 7  Reserved space                  
      PIE_RESERVED, 				                        // 8  Reserved space                  
      PIE_RESERVED, 				                        // 9  Reserved space                  
      PIE_RESERVED,  				                        // 10 Reserved space                  
      PIE_RESERVED,  				                        // 11 Reserved space                  
      PIE_RESERVED,  				                        // 12 Reserved space                  
                                                                                                  
                                                                                                  
// Non-Peripheral Interrupts                                                                      
      PIE_RESERVED,     			                        // XINT13 or CPU-Timer 1, INT13_ISR   
      PIE_RESERVED,    				                        // CPU-Timer2, INT14_ISR              
      PIE_RESERVED,   				                        // Datalogging interrupt, DATALOG_ISR 
      PIE_RESERVED,   				                        // RTOS interrupt, RTOSINT_ISR        
      PIE_RESERVED,   				                        // Emulation interrupt, EMUINT_ISR    
      PIE_RESERVED,       			                        // Non-maskable interrupt, NMI_ISR    
      PIE_RESERVED,   				                        // Illegal operation TRAP, ILLEGAL_ISR
      PIE_RESERVED,    				                        // User Defined trap 1, USER1_ISR     
      PIE_RESERVED,     			                        // User Defined trap 2, USER2_ISR     
      PIE_RESERVED,     			                        // User Defined trap 3, USER3_ISR     
      PIE_RESERVED,     			                        // User Defined trap 4, USER4_ISR     
      PIE_RESERVED,     			                        // User Defined trap 5, USER5_ISR     
      PIE_RESERVED,     			                        // User Defined trap 6, USER6_ISR     
      PIE_RESERVED,    				                        // User Defined trap 7, USER7_ISR     
      PIE_RESERVED,    				                        // User Defined trap 8, USER8_ISR     
      PIE_RESERVED,     			                        // User Defined trap 9, USER9_ISR     
      PIE_RESERVED,    				                        // User Defined trap 10,USER10_ISR    
      PIE_RESERVED,    				                        // User Defined trap 11,USER11_ISR    
      PIE_RESERVED,   				                        // User Defined trap 12, USER12_ISR   

// Group 1 PIE Vectors
      PIE_RESERVED,     									// 1.1 ADC, SEQ1INT_ISR                  
      PIE_RESERVED,     			                        // 1.2 ADC, SEQ2INT_ISR                  
      PIE_RESERVED,        			                        // 1.3, rsvd_ISR                         
      PIE_RESERVED,       			                        // 1.4, XINT1_ISR                        
      PIE_RESERVED,       			                        // 1.5, XINT2_ISR                        
      PIE_RESERVED,      			                        // 1.6 ADC, ADCINT_ISR                   
      PIE_RESERVED,      			                        // 1.7 Timer 0, TINT0_ISR                
      PIE_RESERVED,     			                        // 1.8 WD, Low Power, WAKEINT_ISR        
                                                                                                     
// Group 2 PIE Vectors                                                                               
      PIE_RESERVED, 				                        // 2.1 EPWM-1 Trip Zone, EPWM1_TZINT_ISR 
      PIE_RESERVED, 				                        // 2.2 EPWM-2 Trip Zone, EPWM2_TZINT_ISR 
      PIE_RESERVED, 				                        // 2.3 EPWM-3 Trip Zone, EPWM3_TZINT_ISR 
      PIE_RESERVED, 				                        // 2.4 EPWM-4 Trip Zone, EPWM4_TZINT_ISR 
      PIE_RESERVED, 				                        // 2.5 EPWM-5 Trip Zone, EPWM5_TZINT_ISR 
      PIE_RESERVED, 				                        // 2.6 EPWM-6 Trip Zone, EPWM6_TZINT_ISR 
      PIE_RESERVED,       			                        // 2.7, rsvd_ISR                         
      PIE_RESERVED,        			                        // 2.8, rsvd_ISR                         
                                                                                                     
// Group 3 PIE Vectors                                                                               
      PIE_RESERVED,   				                        // 3.1 EPWM-1 Interrupt, EPWM1_INT_ISR   
      PIE_RESERVED,   				                        // 3.2 EPWM-2 Interrupt, EPWM2_INT_ISR   
      PIE_RESERVED,   				                        // 3.3 EPWM-3 Interrupt, EPWM3_INT_ISR   
      PIE_RESERVED,   				                        // 3.4 EPWM-4 Interrupt, EPWM4_INT_ISR   
      PIE_RESERVED,   				                        // 3.5 EPWM-5 Interrupt, EPWM5_INT_ISR   
      PIE_RESERVED,   				                        // 3.6 EPWM-6 Interrupt, EPWM6_INT_ISR   
      PIE_RESERVED,        			                        // 3.7, rsvd_ISR                         
      PIE_RESERVED,        			                        // 3.8, rsvd_ISR                         

// Group 4 PIE Vectors
      PIE_RESERVED,   										// 4.1 ECAP-1, ECAP1_INT_ISR
      PIE_RESERVED,   				                        // 4.2 ECAP-2, ECAP2_INT_ISR
      PIE_RESERVED,   				                        // 4.3 ECAP-3, ECAP3_INT_ISR
      PIE_RESERVED,   				                        // 4.4 ECAP-4, ECAP4_INT_ISR
      PIE_RESERVED,        			                        // 4.5, rsvd_ISR            
      PIE_RESERVED,        			                        // 4.6, rsvd_ISR            
      PIE_RESERVED,        			                        // 4.7, rsvd_ISR            
      PIE_RESERVED,        			                        // 4.8, rsvd_ISR            
                                                                                        
// Group 5 PIE Vectors                                                                  
      PIE_RESERVED,   				                        // 5.1 EQEP-1, EQEP1_INT_ISR
      PIE_RESERVED,   				                        // 5.2 EQEP-2, EQEP2_INT_ISR
      PIE_RESERVED,        			                        // 5.3, rsvd_ISR            
      PIE_RESERVED,        			                        // 5.4, rsvd_ISR            
      PIE_RESERVED,        			                        // 5.5, rsvd_ISR            
      PIE_RESERVED,        			                        // 5.6, rsvd_ISR            
      PIE_RESERVED,        			                        // 5.7, rsvd_ISR            
      PIE_RESERVED,        			                        // 5.8, rsvd_ISR            
                                                                                        
                                                                                        
// Group 6 PIE Vectors                                                                  
      PIE_RESERVED,   				                        // 6.1 SPI-A, SPIRXINTA_ISR 
      PIE_RESERVED,  				                        // 6.2 SPI-A, SPITXINTA_ISR 
      PIE_RESERVED,   				                        // 6.3 SPI-B, SPIRXINTB_ISR 
      PIE_RESERVED,   				                        // 6.4 SPI-B, SPITXINTB_ISR 
      PIE_RESERVED,   				                        // 6.5 SPI-C, SPIRXINTC_ISR 
      PIE_RESERVED,   				                        // 6.6 SPI-C, SPITXINTC_ISR 
      PIE_RESERVED,   				                        // 6.7 SPI-D, SPIRXINTD_ISR 
      PIE_RESERVED,   				                        // 6.8 SPI-D, SPITXINTD_ISR 
                                                                                        
                                                                                        
// Group 7 PIE Vectors                                                                  
      PIE_RESERVED,        			                        // 7.1, rsvd_ISR            
      PIE_RESERVED,        			                        // 7.2, rsvd_ISR            
      PIE_RESERVED,       			                        // 7.3, rsvd_ISR            
      PIE_RESERVED,        			                        // 7.4, rsvd_ISR            
      PIE_RESERVED,        									// 7.5, rsvd_ISR            
      PIE_RESERVED,        			                        // 7.6, rsvd_ISR            
      PIE_RESERVED,        			                        // 7.7, rsvd_ISR            
      PIE_RESERVED,        			                        // 7.8, rsvd_ISR            
                                                                                        
// Group 8 PIE Vectors                                                                  
      PIE_RESERVED,    				                        // 8.1, I2CINT1A_ISR        
      PIE_RESERVED,    				                        // 8.2, I2CINT2A_ISR        
      PIE_RESERVED,        			                        // 8.3, rsvd_ISR            
      PIE_RESERVED,        			                        // 8.4, rsvd_ISR            
      PIE_RESERVED,        			                        // 8.5, rsvd_ISR            
      PIE_RESERVED,        			                        // 8.6, rsvd_ISR            
      PIE_RESERVED,        			                        // 8.7, rsvd_ISR            
      PIE_RESERVED,        			                        // 8.8, rsvd_ISR            
                                                                                        
// Group 9 PIE Vectors                                                                  
      PIE_RESERVED,   				                        // 9.1 SCI-A, SCIRXINTA_ISR 
      PIE_RESERVED,   				                        // 9.2 SCI-A, SCITXINTA_ISR 
      PIE_RESERVED,   				                        // 9.3 SCI-B, SCIRXINTB_ISR 
      PIE_RESERVED,   				                        // 9.4 SCI-B, SCITXINTB_ISR 
      PIE_RESERVED,   				                        // 9.5 eCAN-A, ECAN0INTA_ISR
      PIE_RESERVED,   				                        // 9.6 eCAN-A, ECAN1INTA_ISR
      PIE_RESERVED,   				                        // 9.7 eCAN-B, ECAN0INTB_ISR
      PIE_RESERVED,   				                        // 9.8 eCAN-B, ECAN1INTB_ISR

// Group 10 PIE Vectors
      PIE_RESERVED,        									// 10.1, rsvd_ISR
      PIE_RESERVED,       			                        // 10.2, rsvd_ISR
      PIE_RESERVED,        			                        // 10.3, rsvd_ISR
      PIE_RESERVED,        			                        // 10.4, rsvd_ISR
      PIE_RESERVED,        			                        // 10.5, rsvd_ISR
      PIE_RESERVED,        			                        // 10.6, rsvd_ISR
      PIE_RESERVED,        			                        // 10.7, rsvd_ISR
      PIE_RESERVED,        			                        // 10.8, rsvd_ISR
                                                                             
// Group 11 PIE Vectors                                                      
      PIE_RESERVED,        			                        // 11.1, rsvd_ISR
      PIE_RESERVED,        			                        // 11.2, rsvd_ISR
      PIE_RESERVED,        			                        // 11.3, rsvd_ISR
      PIE_RESERVED,        			                        // 11.4, rsvd_ISR
      PIE_RESERVED,       			                        // 11.5, rsvd_ISR
      PIE_RESERVED,        			                        // 11.6, rsvd_ISR
      PIE_RESERVED,        			                        // 11.7, rsvd_ISR
      PIE_RESERVED,        			                        // 11.8, rsvd_ISR
                                                                             
// Group 12 PIE Vectors                                                      
      PIE_RESERVED,        			                        // 12.1, rsvd_ISR
      PIE_RESERVED,        			                        // 12.2, rsvd_ISR
      PIE_RESERVED,        			                        // 12.3, rsvd_ISR
      PIE_RESERVED,        			                        // 12.4, rsvd_ISR
      PIE_RESERVED,        			                        // 12.5. rsvd_ISR
      PIE_RESERVED,        			                        // 12.6, rsvd_ISR
      PIE_RESERVED,        									// 12.7, rsvd_ISR
      PIE_RESERVED,        									// 12.8, rsvd_ISR
};

	INT16	i16_iTemp;
	UINT32 *Source = (UINT32 *) &st_PieVectTableInit;
	UINT32 *Dest = (UINT32 *) &PieVectTable;
	EALLOW;
	for(i16_iTemp = 0; i16_iTemp < 128; i16_iTemp++)
		*Dest++ = *Source++;
	EDIS;

}	


//This function deal the PIE module and CPU interrupts,used in interrupt program				
void	Class_SysDrv::Drv_Int_InterruptFlagClear(void)
{
	EPwm1Regs.ETCLR.bit.INT = 1;							//���жϱ�־
   	PieCtrlRegs.PIEACK.all |= PIEACK_GROUP3;				//PIE����,��ACK��־
}
		

//This function enable the PIE module and CPU interrupts
void	Class_SysDrv::Drv_InitInterrupts(void)					
{
	EALLOW;
	PieVectTable.EPWM1_INT = &EPWM1_PERIOD_INT_ISR;
	PieVectTable.SCIRXINTA = &SCIARX_ISR;	//renqx 7��15�ո�
	//PieVectTable.SCITXINTA = &c_int5;
	//CAN
	PieVectTable.ECAN0INTA=&ECAN0INT_ISR;						//renqx 6��20�ո�
    	SysCtrlRegs.SCSR = 0x0000;  			 				// Set the WD to generate WDRST
	EDIS;

    PieCtrlRegs.PIECTRL.bit.ENPIE = 1;						// Enable the PIE

	PieCtrlRegs.PIEACK.all = 0xFFFF;						// Enables PIE to drive a pulse into the CPU

    PieCtrlRegs.PIEIER3.bit.INTx1= 1;						//Enable Time1 Period int

    PieCtrlRegs.PIEIER9.bit.INTx1 = 1;						//Enable SCIRXINTA

   // PieCtrlRegs.PIEIER9.bit.INTx2 = 1;						//Enable SCITXINTA

	PieCtrlRegs.PIEIER9.bit.INTx5 = 1;						//ENABLE eCAN A0

	IFR = 0x0000;											//clear all int
	asm( " rpt #5||nop");
	IER = 0x104;
	asm( " rpt #5||nop");
}



//���ʱ�Ӷ�ʧ��־λ
inline	INT16	Class_SysDrv::Drv_ClockMissingGet(void)	
{
	return(m_i16_ClockMissing);
}


// Enable Interrupts at the CPU level
inline	void	Class_SysDrv::Drv_InterruptEnable(void)		
{
	EINT;
}


//Disable Interrupts at the CPU level
inline	void	Class_SysDrv::Drv_InterruptDisable(void)			
{
	DINT;
}


//DSP�汾������
void	Class_SysDrv::Drv_DSPVersionSet(void)				
{
	EALLOW;
   	m_u16_DSPRevision = DevEmuRegs.REVID;				//Get the DSP Revision
   	EDIS;
}


//��ȡDSP�汾��
inline	UINT16	Class_SysDrv::Drv_GetDSPVersion(void)
{
	return(m_u16_DSPRevision);
}	
//============================================================
// End of file.
//============================================================
