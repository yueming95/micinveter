
#ifndef PRDINT_H
#define PRDINT_H


interrupt void EPWM1_PERIOD_INT_ISR(void);


#endif


