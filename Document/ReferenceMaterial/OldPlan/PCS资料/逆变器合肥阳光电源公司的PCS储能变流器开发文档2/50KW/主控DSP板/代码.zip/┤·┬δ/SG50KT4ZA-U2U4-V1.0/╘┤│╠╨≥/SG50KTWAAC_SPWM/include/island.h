#ifndef _ISLAND_H
#define _ISLAND_H
#include "IQmathLib.h"
#ifdef island_GLOBALS
#define island_GLOBALS
#else
#define island_GLOBALS extern
#endif
#define DISWG _IQ(3.14)  // 0.5hz=3.14
#define IsKi  _IQ(0.0053333333333333333333333333333333)  // (1/12000)*64
void IslandFun();
island_GLOBALS _iq IsPi;
island_GLOBALS _iq IsTheta;
island_GLOBALS _iq IsWg;
#endif

