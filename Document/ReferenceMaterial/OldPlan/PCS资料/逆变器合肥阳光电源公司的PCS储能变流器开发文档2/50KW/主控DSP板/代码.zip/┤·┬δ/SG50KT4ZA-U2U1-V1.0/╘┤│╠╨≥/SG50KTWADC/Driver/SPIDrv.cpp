#include "SPIDrv.h"


void	Class_SPIDrv::Drv_Init(void)
{
	SpibRegs.SPICCR.all = 0x000F;							// Reset on, output on rising,input on falling edge, 16-bit char bits
	SpibRegs.SPICTL.all = 0x000E;							// Enable master mode, normal phase,
															// enable talk, and SPI int disabled.
	SpibRegs.SPIBRR = 0x0009;								//	spi bitrate=100M/10=10M
    SpibRegs.SPICCR.all = 0x008F;							// Relinquish SPI from Reset
}

#pragma CODE_SECTION("Epwm1Funcs");
//SPI��������
inline	void	Class_SPIDrv::Drv_SPISendData(UINT16 u16_Send)
{
	asm(" rpt #5 ||nop");
	SpibRegs.SPITXBUF = u16_Send;
}

#pragma CODE_SECTION("Epwm1Funcs");
//SPI��������
inline	UINT16	Class_SPIDrv::Drv_SPIReceiveData(void)
{
	INT16	i16_temp_0;
	UINT16	u16_temp1_0;

  	for(i16_temp_0 = 0;((i16_temp_0 < 30) && (SpibRegs.SPISTS.bit.INT_FLAG != 1));i16_temp_0++)
  	{
  		asm(" nop");
  	}
	u16_temp1_0 = SpibRegs.SPIRXBUF;

	return(u16_temp1_0);
}

//============================================================
// End of file.
//============================================================
