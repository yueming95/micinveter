--/*=============================================================================*
-- *         Copyright(c) 2004-2007, Emerson Network Power Co., Ltd.
-- *                          ALL RIGHTS RESERVED
-- *
-- *  PRODUCT  : Paradigm NxE Rack Mount UPS
-- *           
-- *  FILENAME : 
-- *  PURPOSE  : IMC Bus Finite state machine
-- *  
-- *  HISTORY  :
-- *    DATE            VERSION        AUTHOR            NOTE
-- *                                  Wang zhihua  
-- *    2007-07-07      V1.0          XiongZhiXue        Created.    
-- *
-- *
-- *
-- *----------------------------------------------------------------------------


LIBRARY IEEE;
USE ieee.STD_LOGIC_ARITH.all;
USE ieee.std_logic_1164.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;

ENTITY FSM_operation IS
PORT(
		dis_signals_from_DSP		:in std_logic_vector (15 downto 0);-- discrete signals input from UPSC;
		MAC_addr_set				:in std_logic_vector(2 downto 0);-- according to this three pin to deciede local MAC addr
		reset						:in std_logic;
		clk_in						:in std_logic;			--clk_10M
		dis_signal_from_bus			:in std_logic;--input signal from can bus;
		dis_signal_to_bus			:out std_logic;--output to others IMC board through can bus;
	--	addr_out					:out std_logic_vector(7 downto 0);--buffers to save the address
		dis_signals_to_DSP		:out std_logic_vector (16 downto 0);-- discrete signals output to UPSC;
		BUS_err_flag_out			:out std_logic;--when BUS are fault, set this flag
        debug_led_out       :out std_logic
);
END FSM_operation;

ARCHITECTURE RTL1 OF FSM_operation IS 

	type sysstate_values is (s0,s1,s2);-- the FSM definition
    
    constant FRAME_LENGTH : integer:=48; --  36 in Previous Version
-- 36->48
	constant MAX_WAIT_TIME_IN_S0: integer:= 464;--In state S0, the maximal time(289 clocks) is spent to detect the falling edge 
-- 289 = 18 *16  ,18 ???????1?????
-- 289-> 29 *16 = 464

	constant MAX_WAIT_TIME_IN_S1: integer:= 944;--In state S1, the maximal time(736 clocks) is spent to detect syncode 
-- ??????
-- 736= (36+2??+8???)*16=736 
--  48+2+9 =59  ,59*16=944

	constant MAX_WAIT_TIME_IN_S4: integer:= 64;--In state S0, the maximal time(64 clocks) is spent to detect the falling edge 
-- 64=4*16
-- 64 ?? 

	constant MAX_WAIT_TIME_IN_S5: integer:= 32;--In state S0, the maximal time(33 clocks) is spent to detect the falling edge 
-- 33=2*16+1
-- 33 ??
	
	constant MAX_CLK_CNT_IN_BIT: integer:= 15;--In on bit time, there are 16 clocks (1/2M)
--  ??

	constant THE_THIRD_SAMPLE_POINT: integer:= 11;--For One Bit, the sampling point is the 9,10,11 Cycles/bit
--  ??	

	constant MAX_UNCHANGE_LEVEL_TIME: integer:= 29;-- In state S0, if BUS level hold unchange beyond 18 bits time(18*8us), then 
--	18 ???????1?????
--indicate Bus is error.18=(2nd_frame_8+3nd_frame_8+4nd_frame_1)+1
--  18-> 9+9+9+1+1 =29
	
	constant BIT_TRANS_POSITION_9_IN_S2: integer:= 9; -- In state S2, the position of the 9th bit transmmition
	constant BIT_TRANS_POSITION_10_IN_S2: integer:= 10; -- In state S2, the position of the 10th bit transmmition
	constant BIT_TRANS_POSITION_11_IN_S2: integer:= 11; -- In state S2, the position of the 11th bit transmmition
	constant BIT_TRANS_POSITION_16_IN_S2: integer:= 16; -- In state S2, the position of the 16th bit transmmition
	constant BIT_TRANS_POSITION_17_IN_S2: integer:= 17; -- In state S2, the position of the 17th bit transmmition
	constant BIT_TRANS_POSITION_18_IN_S2: integer:= 18; -- In state S2, the position of the 18th bit transmmition
	constant BIT_TRANS_POSITION_21_IN_S2: integer:= 21; -- In state S2, the position of the 21th bit transmmition
	constant BIT_TRANS_POSITION_25_IN_S2: integer:= 25; -- In state S2, the position of the 25th bit transmmition
	constant BIT_TRANS_POSITION_26_IN_S2: integer:= 26; -- In state S2, the position of the 26th bit transmmition
	constant BIT_TRANS_POSITION_27_IN_S2: integer:= 27; -- In state S2, the position of the 27th bit transmmition
	constant BIT_TRANS_POSITION_28_IN_S2: integer:= 28; -- In state S2, the position of the 28th bit transmmition
	constant BIT_TRANS_POSITION_30_IN_S2: integer:= 30; -- In state S2, the position of the 30th bit transmmition
	constant BIT_TRANS_POSITION_31_IN_S2: integer:= 31; -- In state S2, the position of the 31th bit transmmition
	constant BIT_TRANS_POSITION_32_IN_S2: integer:= 32; -- In state S2, the position of the 32th bit transmmition
	constant BIT_TRANS_POSITION_35_IN_S2: integer:= 35; -- In state S2, the position of the 35th bit transmmition
	constant BIT_TRANS_POSITION_36_IN_S2: integer:= 36; -- In state S2, the position of the 36th bit transmmition
		
	constant BIT_TRANS_POSITION_2_IN_S3: integer:= 2; -- In state S3, the position of the 2th bit transmmition
	constant BIT_TRANS_POSITION_3_IN_S3: integer:= 3; -- In state S3, the position of the 3th bit transmmition
	constant BIT_TRANS_POSITION_8_IN_S3: integer:= 8; -- In state S3, the position of the 8th bit transmmition
	constant BIT_TRANS_POSITION_10_IN_S3: integer:= 10; -- In state S3, the position of the 10th bit transmmition
	constant BIT_TRANS_POSITION_13_IN_S3: integer:= 13; -- In state S3, the position of the 13th bit transmmition
	constant BIT_TRANS_POSITION_17_IN_S3: integer:= 17; -- In state S3, the position of the 17th bit transmmition
	constant BIT_TRANS_POSITION_18_IN_S3: integer:= 18; -- In state S3, the position of the 18th bit transmmition
	constant BIT_TRANS_POSITION_19_IN_S3: integer:= 19; -- In state S3, the position of the 19th bit transmmition
	constant BIT_TRANS_POSITION_20_IN_S3: integer:= 20; -- In state S3, the position of the 20th bit transmmition
	constant BIT_TRANS_POSITION_22_IN_S3: integer:= 22; -- In state S3, the position of the 22th bit transmmition
	constant BIT_TRANS_POSITION_24_IN_S3: integer:= 24; -- In state S3, the position of the 24th bit transmmition
	constant BIT_TRANS_POSITION_27_IN_S3: integer:= 27; -- In state S3, the position of the 27th bit transmmition
	constant BIT_TRANS_POSITION_28_IN_S3: integer:= 28; -- In state S3, the position of the 28th bit transmmition
	

   signal debug_sig  :std_logic;
	signal sysstate					:sysstate_values;
	signal clk_cnt					:integer range 0 to MAX_CLK_CNT_IN_BIT;--2M clock counter

	signal bit_cnt 					:integer range 0 to (FRAME_LENGTH+1);-- bit counter;
--	signal bit_cnt 					:integer range 0 to (FRAME_LENGTH+1);-- bit counter;
--  FRAME_LENGTH  36 VS 48

	signal wait_clkcnt				:integer range 0 to (MAX_WAIT_TIME_IN_S1+4);-- detect the dominant signals
--	([38+8]*16=736)+4  VS  
	signal synbits					:std_logic_vector(8 downto 0);--detect the synPULS
--	signal sample_bits_fifo3			:std_logic_vector(2 downto 0);--detect the dominant signals
	signal sample_bits_fifo3			:std_logic_vector(6 downto 0);--detect the dominant signals

	signal sample_bit				:std_logic;--sampled bit value
	signal discrete_out_buff			:std_logic_vector(16 downto 0);--buffers to save the CAN BUS discrete datum
	signal discrete_out_buff1			:std_logic_vector(16 downto 0);--buffers to save the CAN BUS discrete datum
	signal discrete_out_buff2			:std_logic_vector(16 downto 0);--buffers to save the CAN BUS discrete datum
	signal discrete_out_buff3 		    :std_logic_vector(16 downto 0);--buffers to save the CAN BUS discrete datum


	signal insert_code				:std_logic_vector(1 downto 0);-- buffer to save the insert codes "01" to judge the state of the CAN BUS
	signal BUS_err_flag				:std_logic;--temp flag for BUS error 
	signal BUS_err_flag_bk1				:std_logic;--temp flag for BUS error 
	signal BUS_err_flag_bk2				:std_logic;--temp flag for BUS error 


	signal MAC_addr				:std_logic_vector(7 downto 0);--local mac addr
	--signal addr_out_buff				:std_logic_vector(7 downto 0);--save the addr get from bus


	signal BUS_err_flag1				:std_logic;--temp flag for BUS error 
	signal BUS_err_flag2				:std_logic;--temp flag for BUS error 
	signal BUS_err_flag3				:std_logic;--temp flag for BUS error 

	signal sync_not_ok				:std_logic;--temp flag for BUS error 




--------------------------------------------------	
    signal  data_sent     :std_logic;
    signal  slave_err_state     :std_logic;
    signal  slave_err_state_bk     :std_logic;
	 signal  master_err_state     :std_logic_vector(3 downto 0);
    signal  master_err_total     :std_logic;
    signal  send_enable     :std_logic;
--------------------------------------------------	
--------------------------------------------------	
--signal temp1 : std_logic_vector(2 downto 0);
 shared  variable temp1 : std_logic_vector(2 downto 0);

-- shared  variable send_enable :  std_logic;
---------------------------------------------


	COMPONENT MAC_decoder
		PORT (
				MAC_addr_set	:in std_logic_vector(2 downto 0); 
				MAC_addr		:out std_logic_vector(7 downto 0)--local mac addr
		);
	END COMPONENT;

BEGIN

	-- Instance port mappings.
	U1 : MAC_decoder
	PORT MAP (
				MAC_addr_set	=> MAC_addr_set,
				MAC_addr		=> MAC_addr
	);

	--CAN BUS error flag 
	BUS_err_flag_out<=BUS_err_flag;-- or BUS_err_flag_bk1 or BUS_err_flag_bk2 ;
--for debug------
--	BUS_err_flag_out<=BUS_err_flag or BUS_err_flag_bk1 or BUS_err_flag_bk2 or master_err_total or slave_err_state;-- or sync_not_ok ;
--for debug------

	process(clk_in,reset)
	begin
	-------------------------------initializtion------------------------------------------------
	if reset='0' then
		clk_cnt<=0;
		bit_cnt<=0;
		wait_clkcnt<=0;
		sysstate<=s0;

		BUS_err_flag<='0';
        BUS_err_flag_bk1<='0';
        BUS_err_flag_bk2<='0';

		
		sample_bits_fifo3<="1111111";
		synbits<="111111111";
	--	addr_out<="11111111";

        debug_led_out<='1';
        debug_sig<='1';

        BUS_err_flag1 <= '0';
        BUS_err_flag2 <= '0';
        BUS_err_flag3 <= '0';

        sync_not_ok <= '1';
        dis_signal_to_bus <='1';

        data_sent <= '1';
--        slave_err_state <= '0';
--       slave_err_state_bk <= '1';
--        master_err_total<= '0';


        temp1 :="000";

        send_enable <= '0';
	-----------------------------------the end----------------------------------------------------

	-----------------------sample  for bus signal with system clock(2MHz) , It means one Bits need include 16 Cycles.
	else
		if rising_edge(clk_in) then
--			sample_bits_fifo3(0)<=dis_signal_from_bus;
--			sample_bits_fifo3(1)<=sample_bits_fifo3(0);
--			sample_bits_fifo3(2)<=sample_bits_fifo3(1);

			sample_bits_fifo3(0)<=dis_signal_from_bus;
			sample_bits_fifo3(1)<=sample_bits_fifo3(0);
			sample_bits_fifo3(2)<=sample_bits_fifo3(1);
			sample_bits_fifo3(3)<=sample_bits_fifo3(2);
			sample_bits_fifo3(4)<=sample_bits_fifo3(3);
			sample_bits_fifo3(5)<=sample_bits_fifo3(4);
			sample_bits_fifo3(6)<=sample_bits_fifo3(5);

	-----------------------------the end----------------------------------------------------------------
         debug_led_out <= debug_sig;

-- debug_led_out <= send_enable;
--BUS_err_flag_out <= discrete_out_buff(1);
	------------------------------------FSM of CAN BUS -------------------------------------------
	--State machine for discrete signal transfer
	----------------------------------------------------------------------------------------------
			case sysstate is 
-----------------------------------------------------------------------------						
--1. ?????,??????-------------------------------------------------------------------------						
-----------------------------------------------------------------------------						

				when s0=>									-- 3 cycles
                            sync_not_ok <= '1';

				-----------------------------------------------------------------------------						
				--In the SLAVE mode, if  the received Bits is the (38+8) sequential same bits (all of '1'), it means the MASTER unit has lost.
				--So the SLAVE unit will return to the initial status, then try to find another MASTER unit.
						if  sample_bits_fifo3(2 downto 0)= "000" then		--If the Falling edge is deteected, the Current  UNIT will setting to be SLAVE Mode
								clk_cnt<=3;					--In fact, it need to add 2 for this variable, but another one cycle will be added for
								bit_cnt<=0; 
												--transfer delay compensating, One Cycle= 1/2MHz=0.5us, the transfer delay 
															--is arouse from the transceiver and isolator.
								wait_clkcnt<=0;
								sysstate<=s1;
						end if;
-----------------------------------------------------------------------------						
--1. ??????-------------------------------------------------------------------------						
-----------------------------------------------------------------------------						
				when s1=> 					--8*16 cycles
			            if clk_cnt=(MAX_CLK_CNT_IN_BIT-1)  then	--One bit has been received, so it will be stored into the buffer sysbits[].
							if sample_bit=synbits(0) then		--Judge whether the current recievd bit is same as the late bits 
								bit_cnt<=bit_cnt+1;				--If the signal is same, the counter will be added.
							else 
								bit_cnt<=0; --??????
--                      sync_not_ok <= '1';
--								sysstate<=s0;
							end if;
						
							--Store the current received bit,  and remain the latest eight Bits for the judgement of the SYNC Segment
							synbits(0)<=sample_bit;
							synbits(1)<=synbits(0);
							synbits(2)<=synbits(1);
			   			synbits(3)<=synbits(2);
			   			synbits(4)<=synbits(3);
					   	synbits(5)<=synbits(4);
					   	synbits(6)<=synbits(5);
	   		   		synbits(7)<=synbits(6);
	   		   		synbits(8)<=synbits(7);
		                end if;
-----------------------------------------------------------------------------						
				    	--For One Bit, the sampling point is the 9,10,11 Cycles/bit (About 10/15=66.7%)
						--			9		10		11		Bit Level	
						--			1		1		*			1
						--			1		*		1			1
						--			*		1		1			1
						--			other condition					0
						if clk_cnt=THE_THIRD_SAMPLE_POINT then
--------------------------------------------------------------------   
-- 7 ? 4
--------------------------------------------------------------------
		                    for  i  in 0 to 6 loop
		                       if(sample_bits_fifo3(i)='0')  then
												temp1:=temp1+1;
							        else
												temp1:=temp1+0;
							        end if;
							     end loop;
--------------------------------------------------------------------   
			                    if (temp1(2) = '1') then 		-- when temp1>=4  ,sample_bit=0;
												sample_bit <= '0';
			                    else   
												sample_bit <= '1';
			                    end if;
		             end if;
-----------------------------------------------------------------------------						
						--counter value maintenance 
						if clk_cnt=MAX_CLK_CNT_IN_BIT then			-- one state has 16 cycles 
                      debug_sig <= sample_bit;
						    temp1 :="000";					-- 
							 clk_cnt<=0;
  --                  debug_sig <= not debug_sig;
							-- judge if received syn code?
								if (synbits(8 downto 0)="000000000") then		--s1 will make loop before entering to next state
									sysstate<=s2;		--If receive the correct sync segement, the SLAVE unit chang the state to S3 for the data sending 
									bit_cnt<=1;		--In fact, it should be Zero, but another one cycle will be added for
													--transfer delay compensating, One Cycle= 1/2MHz=0.5us, the transfer delay 
													--is arouse from the transceiver and isolator.
									clk_cnt<=1;		--
									wait_clkcnt<=0;
									synbits<="111111111";
                           sync_not_ok <= '0';

								end if;
						else
							clk_cnt<=clk_cnt+1;
						end if;
---------------------------------------------------------------------------------						
--						if bit_cnt=MAX_UNCHANGE_LEVEL_TIME then 
--							BUS_err_flag<='1';		--Setting the flag of the BUS ERROR,,return to the initial status.
--							bit_cnt<=0;
--							sysstate<=s0;
--							wait_clkcnt<=0;
--						end if;	
-----------------------------------------------------------------------------						
--2. ????????-------------------------------------------------------------------------						
-----------------------------------------------------------------------------						
				when s2=>					--39*15 cycles
				-- send the data segement/Address segement(SLAVE Mode )
					--For One Bit, the sampling point is the 9,10,11 Cycles/bit (About 10/15=66.7%)
					if clk_cnt=THE_THIRD_SAMPLE_POINT then						
--------------------------------------------------------------------
-- 7 ? 4
--------------------------------------------------------------------
		                    for  i  in 0 to 6 loop
		                       if(sample_bits_fifo3(i)='0')  then
												temp1:=temp1+1;
							        else
												temp1:=temp1+0;
							        end if;
							     end loop;
--------------------------------------------------------------------   
			                     if (temp1(2) = '1') then 
												sample_bit <= '0';
			                     else   
												sample_bit <= '1';
			                     end if;
		            end if;
-----------------------------------------------------------------------------						
--------------------------------------------------------------------   
					
----------------------------------------------------------
					--Recieve Datas:   1. data segement form bus,  From  the 2th Bits to 13th Bit
					--			     2. Address segement,From  the 32th Bits to 35th Bit and From  the 27th Bits to 30th Bit 
					--			     3. Magic Number "10",From  the 25th Bits to 26th Bit
-----------------------------------------------------------------------
				   if clk_cnt=(MAX_CLK_CNT_IN_BIT-2) then

                	  --  if bit_cnt >=2 and bit_cnt <=34 and data_sent = '0' and sample_bit = '1' then
                      --      slave_err_state <= '1';
                      --      slave_err_state_bk <= '0';
                      --  end if;

						if bit_cnt =1 then
							if sample_bit = '0' then --sample ->0 ; dsp rece->1			??why it is "0" for receiving??
							send_enable<= '0'; --only receive
							else
							send_enable<= '1'; --only send
							end if;
						end if;


						--COPY the received data to buffer
						if bit_cnt>=2 and bit_cnt<=9 then
							discrete_out_buff(bit_cnt-2)<=sample_bit;
						end if;
						
						if bit_cnt>=11 and bit_cnt<=18 then
							discrete_out_buff(bit_cnt-3)<=sample_bit;
						end if;
						
						if bit_cnt=20 then
							discrete_out_buff(16)<=sample_bit;
						end if;
						
						--COPY the received address to buffer
--						if bit_cnt>=30 and bit_cnt<=33 then
--							addr_out_buff(bit_cnt-30)<=sample_bit;
--						end if;	
--							
--						if bit_cnt>=35 and bit_cnt<=38 then
--							addr_out_buff(bit_cnt-31)<=sample_bit;
--						end if;
--			            if bit_cnt>=24 and bit_cnt<=27 then
--							master_err_state(bit_cnt-24)<=sample_bit;
--						end if;
												--COPY the insert code "10" to buffer	
						if bit_cnt>=28 and bit_cnt<=29 then
							insert_code(bit_cnt-28)<=sample_bit;
						end if;
			     end if;	
-----------------------------------------------------------								
				 if clk_cnt=MAX_CLK_CNT_IN_BIT then
                   debug_sig <= sample_bit;
					    temp1 :="000";

------------------ debug  -----------------------
--                        debug_sig <= not debug_sig;
--------------------------------------------------
						clk_cnt<=0;
--------------------------------------------------
					   -- BUS_err_flag2 because of enable
--------------------------------------------------

						if bit_cnt=10 then					-- 0 is right 
							if sample_bit = '1' then
								BUS_err_flag2<='1';
                            else
								BUS_err_flag2<='0';
						   end if;
						end if;
--------------------------------------------------
						if bit_cnt=19 then					-- 1 is right
                      if sample_bit = '0' then
								BUS_err_flag3<='1';
                            else
								BUS_err_flag3<='0';
						    end if;
						end if;
--------------------------------------------------


						if bit_cnt=34 then
-------------------------------------------------------------------------
						--  BUS ERROR judgement:
						--  1. Using the Magic number to judge the bus error, If the recieved magic number is not "10", It means the BUS ERROR exist.
						--  2. According  to the protocol, after receiving to address segement, we will judge the open error:
						--		1. The current address is smaller than another bus address, in addition, the another bus is Ok
						--		2. The current address is equal to the MAC_ADDR
						-----------------------------------------------------------
							if (insert_code /= "01") then
								BUS_err_flag1<='1';
							--elsif ((addr_out_buff>addr_in)and(BUS_err_flag_in='0') ) or (addr_out_buff=MAC_addr) then
							--	BUS_err_flag<='1';
							else
								BUS_err_flag1<='0';
							end if;
							
                         BUS_err_flag_bk1 <= BUS_err_flag;
                         BUS_err_flag_bk2 <= BUS_err_flag_bk1;
                         -----------------------------------------
--                            if master_err_state(0) = '0' or master_err_state(1) = '0' or master_err_state(2) = '0' or master_err_state(3) = '0' then
--								master_err_total<='1';
--		                    else
--								master_err_total<='0';
--		 					end if;


						end if;
						-------------------the end of the BUS ERROR judgement:(S3) ------------------------------------
                       BUS_err_flag <= BUS_err_flag1 or BUS_err_flag2 or BUS_err_flag3 ;--or sync_not_ok;						-----------------------------------------------------------
						--  Update the output of the state machine.
						--  After One frame is received, if the error is not here, the output of the state machine will be sent to UPSC
						-----------------------------------------------------------
						if bit_cnt=39 then
							sysstate<=S0;
							bit_cnt<=0;
							
----------------------------------------------------------------------------------------				
	if  BUS_err_flag = '0' and BUS_err_flag_bk1 = '0' and BUS_err_flag_bk2 = '0' then-- and master_err_total = '0' and slave_err_state = '0' then
-- debug_led_out <= discrete_out_buff(1);
       	if send_enable = '0' then 				-- receive			?why dis_signals_to_DSP was got in two different condition?
                        dis_signals_to_DSP(3 downto 0)<=discrete_out_buff(3 downto 0);
								dis_signals_to_DSP(5)<=discrete_out_buff(5);
								dis_signals_to_DSP(6)<=discrete_out_buff(6);
								dis_signals_to_DSP(9)<=discrete_out_buff(9);
								dis_signals_to_DSP(10)<=discrete_out_buff(10);
								dis_signals_to_DSP(16)<=discrete_out_buff(16);


								discrete_out_buff1(3 downto 0)<=discrete_out_buff(3 downto 0);
								discrete_out_buff1(5)<=discrete_out_buff(5);
								discrete_out_buff1(6)<=discrete_out_buff(6);
								discrete_out_buff1(9)<=discrete_out_buff(9);
								discrete_out_buff1(10)<=discrete_out_buff(10);
								discrete_out_buff1(16)<=discrete_out_buff(16);

								discrete_out_buff2(3 downto 0)<=discrete_out_buff1(3 downto 0);
								discrete_out_buff2(5)<=discrete_out_buff1(5);
								discrete_out_buff2(6)<=discrete_out_buff1(6);
								discrete_out_buff2(9)<=discrete_out_buff1(9);
								discrete_out_buff2(10)<=discrete_out_buff1(10);
								discrete_out_buff2(16)<=discrete_out_buff1(16);

								discrete_out_buff3(3 downto 0)<=discrete_out_buff2(3 downto 0);
								discrete_out_buff3(5)<=discrete_out_buff2(5);
								discrete_out_buff3(6)<=discrete_out_buff2(6);
								discrete_out_buff3(9)<=discrete_out_buff2(9);
								discrete_out_buff3(10)<=discrete_out_buff2(10);
								discrete_out_buff3(16)<=discrete_out_buff2(16);

       else  --send enable =1		 send
								dis_signals_to_DSP(15 downto 11)<=discrete_out_buff(15 downto 11);
								dis_signals_to_DSP(8 downto 7)<=discrete_out_buff(8 downto 7);
								dis_signals_to_DSP(4)<=discrete_out_buff(4);

								discrete_out_buff1(15 downto 11)<=discrete_out_buff(15 downto 11);
								discrete_out_buff1(8 downto 7)<=discrete_out_buff(8 downto 7);
								discrete_out_buff1(4)<=discrete_out_buff(4);

								discrete_out_buff2(15 downto 11)<=discrete_out_buff1(15 downto 11);
								discrete_out_buff2(8 downto 7)<=discrete_out_buff1(8 downto 7);
								discrete_out_buff2(4)<=discrete_out_buff1(4);

								discrete_out_buff3(15 downto 11)<=discrete_out_buff2(15 downto 11);
								discrete_out_buff3(8 downto 7)<=discrete_out_buff2(8 downto 7);
								discrete_out_buff3(4)<=discrete_out_buff2(4);

        end if;--end of send enable

		--slave_err_state <= '0';
		--slave_err_state_bk <= '1';

--------------------------------------------------------------------
	else  --else error
--------------------------------------------------------------------
		         for  ii  in 0 to 16 loop
						if (discrete_out_buff1(ii)='1' and discrete_out_buff2(ii)='1') 
						   or (discrete_out_buff1(ii)='1' and discrete_out_buff3(ii)='1') 
						   or(discrete_out_buff2(ii)='1' and discrete_out_buff3(ii)='1') then
							dis_signals_to_DSP(ii)<='1';
						else
							dis_signals_to_DSP(ii)<='0';
						end if;
					end loop;
--------------------------------------------------------------------   
   end if;		
--------------------------------------------------------------------   
	else  		-- bit_cnt/=39
				bit_cnt<=bit_cnt+1;
	end if;--end if bit 39
						-------------------the end of Update the output of the state machine(S3) -----------------------
else
	clk_cnt<=clk_cnt+1;
end if;  --end if clk-max
							
					-----------------------------------------------------------
					--Send Datas For SLAVE  unit  
					--According to the Protocol, the Master will send the Sync segement, data segement, address segement
					--just like this: 1XXXXXXX 1XXXXXX 10 XXXX1XXXX 1 (28 Bits)
					-----------------------------------------------------------
					case bit_cnt is 
-----------------------------------------------------------------------
						--sending insert code to bus
						when 1=>
							dis_signal_to_bus<='1';	
							data_sent <='1';	
						--sending discrete signal(from bit2 to bit8) to bus
						when 2=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(0)and send_enable);	
   				            data_sent <=not (dis_signals_from_DSP(0)and send_enable);					
						when 3=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(1)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(1)and send_enable);						

						when 4=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(2)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(2)and send_enable);						

						when 5=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(3)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(3)and send_enable);					

						when 6=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(4)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(4)and send_enable);						

						when 7=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(5)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(5)and send_enable);						

						when 8=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(6)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(6)and send_enable);						

						when 9=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(7)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(7)and send_enable);						

-----------------------------------------------------------------------
						--sending insert code to bus
						when 10=>
							dis_signal_to_bus<='0';
   				            data_sent <= '0';						
							
						--sending discrete signal(from bit7 to bit10) to bus	
						when 11=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(8)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(8)and send_enable);					

						when 12=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(9)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(9)and send_enable);						

						when 13=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(10)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(10)and send_enable);				

						when 14=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(11)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(11)and send_enable);					

						when 15=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(12)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(12)and send_enable);						

						when 16=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(13)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(13)and send_enable);						

						when 17=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(14)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(14)and send_enable);					

						when 18=>
							dis_signal_to_bus<=not (dis_signals_from_DSP(15)and send_enable);
   				            data_sent <=not (dis_signals_from_DSP(15)and send_enable);					

-----------------------------------------------------------------------
						--sending insert code to bus
						when 19=>
							dis_signal_to_bus<='1';
   				            data_sent <= '1';						
							
						--sending discrete signal  to bus	
						when 20=>
--							dis_signal_to_bus<= slave_err_state_bk;
-- 				            data_sent <= slave_err_state_bk;						
--------------------------------------------------------------
							dis_signal_to_bus<='1';
 				            data_sent <= '1';	
--------------------------------------------------------------
--				            data_sent <=not (aux_singal_to_bus and send_enable);					



						when 21=>
--							dis_signal_to_bus<= slave_err_state_bk;
--   				            data_sent <= slave_err_state_bk;						
							dis_signal_to_bus<='1';
  				            data_sent <= '1';		

						when 22=>
--							dis_signal_to_bus<= slave_err_state_bk;
--   				            data_sent <= slave_err_state_bk;						
							dis_signal_to_bus<='1';
  				            data_sent <= '1';		

						when 23=>
--							dis_signal_to_bus<= slave_err_state_bk;
--   				            data_sent <= slave_err_state_bk;						
							dis_signal_to_bus<='1';
  				            data_sent <= '1';		
-------------------------------------------------------------
						when 24=>
							dis_signal_to_bus<='1';
  				            data_sent <= '1';						

						when 25=>
							dis_signal_to_bus<='1';
  				            data_sent <= '1';						

						when 26=>
							dis_signal_to_bus<='1';
  				            data_sent <= '1';						

						when 27=>
							dis_signal_to_bus<='1';
  				            data_sent <= '1';						

-----------------------------------------------------------------------
			
						--sending insert code to bus
						when 28=>	
							dis_signal_to_bus<='1';
  				            data_sent <= '1';						

						when 29=>
							dis_signal_to_bus<='0';
  				            data_sent <= '0';						
					
						--sending address (from addr0 to addr3) to bus
						when 30=>
							dis_signal_to_bus<=MAC_addr(0);
  				            data_sent<=MAC_addr(0);					

						when 31=>	
							dis_signal_to_bus<=MAC_addr(1);
  				            data_sent<=MAC_addr(1);					

						when 32=>
							dis_signal_to_bus<=MAC_addr(2);
  				            data_sent<=MAC_addr(2);					

						when 33=>
							dis_signal_to_bus<=MAC_addr(3);
  				            data_sent<=MAC_addr(3);					
						--sending insert code to bus
						when 34=>	
							dis_signal_to_bus<='1';
  				            data_sent<='1';					
						--sending address (from addr4 to addr7) to bus
						when 35=>
							dis_signal_to_bus<=MAC_addr(4);
  				            data_sent<=MAC_addr(4);					

						when 36=>
							dis_signal_to_bus<=MAC_addr(5);
  				            data_sent<=MAC_addr(5);					

						when 37=>	
							dis_signal_to_bus<=MAC_addr(6);
  				            data_sent<=MAC_addr(6);					

						when 38=>
							dis_signal_to_bus<=MAC_addr(7);
  				            data_sent<=MAC_addr(7);					

						when 39=>
							dis_signal_to_bus<='1';
  				            data_sent<='1';					

						when others=>
							dis_signal_to_bus<='1';
  				            data_sent<='1';					
					    end case;	
-----------------------------------------------------------------
			end case; -- end state machine
	end if; -- end if clk
		
end if;  --end if rst
	
end process;
	
end RTL1;