/*==========================================================*/
/* Title		:	RAMDrv.h								*/
/* Description	: 	Class_RAMDrv definition					*/
/* Date			:	Oct.2007								*/
/*==========================================================*/


#ifndef DSP280x_RAMDRV_H
#define DSP280x_RAMDRV_H

//============================================================
//	Class_RAMDrv���ⲿ�Ľӿ�
//	1)����
//	2)
//============================================================
class Class_RAMDrv
{
	private:
		UINT16	m_u16_RamCheckErr;		
	public:
		void	Drv_Init(void);								//��ʼ��
		void	Drv_RamCheck(void);							//�ڴ��Լ켰RAM����
		void	Drv_MemCopy(UINT16 *SourceAddr, UINT16* SourceEndAddr, UINT16* DestAddr);//������������
};

#endif

//============================================================
// End of file.
//============================================================
