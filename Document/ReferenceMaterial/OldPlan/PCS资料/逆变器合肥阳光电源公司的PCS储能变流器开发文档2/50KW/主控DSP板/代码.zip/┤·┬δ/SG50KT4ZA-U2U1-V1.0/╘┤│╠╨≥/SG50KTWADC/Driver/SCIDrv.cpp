/*==========================================================*/
/* Title		:	SCIDrv.cpp								*/
/* Description	: 	Class_ADCDrv realization 				*/
/* Date			:	Apr.2008								*/
/*==========================================================*/

#include "SCIDrv.h"
extern Uint16 ren[];
/**********************************************************************************
��������	Drv_SCIInit()			
����������	SCIģ���ʼ��
�������ã�	��
***********************************************************************************/
void	Class_SCIDrv::Drv_Init()
{
	/* <=== SCI-A Registers initialization ===> */
//    SciaRegs.SCICCR.all = 0x0007;            // 1 stop bit,  No loopback
//                                             // No parity,8 char bits,
//                                             // async mode, idle-line protocol
//    SciaRegs.SCICTL1.all = 0x0021;           // enable TX, RX, internal SCICLK,
//                                             // Disable RX ERR, SLEEP, TXWAKE
//    SciaRegs.SCIHBAUD = 0x0001;            	 // RATE IS 9600 bit/s
//    SciaRegs.SCILBAUD = 0x0044;
//
////    SciaRegs.SCICTL1.all = 0x0023;     		 // Relinquish SCI from Reset
//    SciaRegs.SCICTL2.bit.RXBKINTENA = 1;
	EALLOW;
//  Initialize SCI-A:
	SciaRegs.SCICCR.all=0x0000;		      	//����ż���,ѡ������߶ദ����ģʽ,
	SciaRegs.SCICCR.bit.SCICHAR=0x7;        //�ַ�����Ϊ8λ.no parity,idle-line,one stopbit,8 charbits
	
	SciaRegs.SCICTL1.all=0x0000;	      	/*0x0003;  SW_RESET=0,soft reset;enable TX,RX;disable  RXERR,TXWAKE,SLEEP,  */
	SciaRegs.SCICTL1.bit.RXENA=1;	      	//SCI����ʹ��
//	SciaRegs.SCICTL1.bit.TXENA=1;	      	//SCI����ʹ��

	SciaRegs.SCICTL2.all=0x0000;
	SciaRegs.SCICTL2.bit.RXBKINTENA=1;    	//ʹ�ܽ��ջ�����/����ж� enable RX INT,disable TX INT   

	SciaRegs.SCIHBAUD=0x0002;
	SciaRegs.SCILBAUD=0x008A;		      	/*  BAUD=19200bps 100MHz/(19200*8) - 1 */

	SciaRegs.SCIPRI.all=0;

	SciaRegs.SCICTL1.bit.SWRESET=1;		    /* SW_RESET=1, relinquish SCI from reset*/
          
//  PFDATDIR &= 0xffdf;    /*IOPF5=RDEN =0,enable 485 RE */    
 	EDIS;

/* <=== SCI-B Registers initialization ===> */
   ScibRegs.SCICCR.all = 0x0007;    		 // 1 stop bit,  No loopback 
                                             // No parity,8 char bits,
                                             // async mode, idle-line protocol
   ScibRegs.SCICTL1.all =0x0003;             // enable TX, RX, internal SCICLK, 
                                             // Disable RX ERR, SLEEP, TXWAKE
   ScibRegs.SCIHBAUD = 0x0001;
   ScibRegs.SCILBAUD = 0x0045;
   ScibRegs.SCICTL1.all = 0x0023;     		 // Relinquish SCI from Reset 

  	Receivecount =0;

}


//===========================================================================
// End of file.
//===========================================================================

void Class_SCIDrv::SciReceiveData(void)
{   
  Uint16 i,j;    

    if(Receivecount>0)
   {
        if(otime++>4800)     /*��ʱ����*/
        {   
  	  	otime=0;
        sciFlagReg.sciOverTime=1;     /*flagc.1=1 set over time flag*/
   		Receivecount=0;
  		sciFlagReg.sciRXok=0;     /* clear receive byte flag*/
        }
   }

  if((Receivecount>3)&&(Receivecount<=7))
  {
   for(i=0;i<2;i++)
   {	rtemp=RBUF[i];       //��O�ֽ�  /*RTEMP �Ǹ�ȫ�ֱ���*/  
    if(rtemp!=0x0fe)          		/*FEH,������ݲ���FE�Ҷ���һ������˵�����ݶ�����*/
      {
  	    Receivecount=0;
        sciFlagReg.sciRXok=0;     /* clear receive byte flag*/
        return;  
      }  
    } 

	if((RBUF[2]!=0)&&(RBUF[2]!=objDigitalIO.m_i16_ModuleID))//�ж��Ƿ�Ϊ��ģ����Ϣ
	{
  	    Receivecount=0;
        sciFlagReg.sciRXok=0;     /* clear receive byte flag*/
		return;
	}
  }  

  	
  if(Receivecount>7)	
  {	
	LenData = 0;
  	FunctionCode = RBUF[3];	
  	FunctionAddress = (RBUF[4]<<8)+(RBUF[5]&0xff);
	ren[5] = (RBUF[4]<<8)+(RBUF[5]&0xff);
  	u16RegNumORdata = (RBUF[6]<<8)+(RBUF[7]&0xff);
   if(FunctionCode==10)				//�����벻�����ò���
    {
  	 LenData=RBUF[8];
    }
  }
   
   if(Receivecount>9+LenData)   
  {
  	if(FunctionCode==10)
     { 
     	for(Pmid=0,j=LenData;j>0;j--)       		 /*��ʼ������������*/
       {
        DATABUF[Pmid]=RBUF[9+Pmid++];   
       }
  	 }
     	RxCRC=(RBUF[Receivecount-2]<<8)+RBUF[Receivecount-1];         
  
     	sciFlagReg.sciRXok=0;      			/*flagc.0=0 clear receive byte flag������*/
     	nEND = Receivecount-2;
     	Receivecount = 0;
  	  	otime=0;

     if(RxCRC==CRCcodeDelt(&(RBUF[0]),nEND)) 
     {
   		sciFlagReg.sciReceiveOver=1;    /*received code delt program(���ݽ������Ժ�Ҫ����λ��һ��Ӧ��)*/
     }
     else
     {
  		for(i=0;i<nEND;i++)	//���CRC���󽫲��ظ����������㡣
    		RBUF[i]=0;
     }
  }
}
   
/*-----------------------------------------*/
/*  read char from received buffer         */  
/*-----------------------------------------*/
Uint16 Class_SCIDrv::Readchar()  
{   
    	return(RBUF[1]);
}   

/*-----------------------------------------*/
/*  		send data buffer	          */  
/*-----------------------------------------*/
void Class_SCIDrv::SciArrayTrans(Uint16 *BUFaddress,Uint16 FunctionCodeTemp,Uint16 datanum,Uint16 AcessFlag) 
{
		Uint16 dbdatanum,i;
		dbdatanum= datanum<<1;
	if(AcessFlag)		//�����ظ���־
   {
		 AcessFlag=0;
		 	
	     TBUF[0] = 0xfe;                							
         TBUF[1] = 0xfe;                							
         TBUF[2] = objDigitalIO.m_i16_ModuleID;  
         TBUF[3] = FunctionCodeTemp;                    				
		  
		if((FunctionCodeTemp==6)||(FunctionCodeTemp==10))	// ���������ûظ�
	   {
		TBUF[4] =(FunctionAddress&0xff00)>>8;
		TBUF[5] =(FunctionAddress&0xff);
		TBUF[6] =(u16RegNumORdata&0xff00)>>8;
		TBUF[7] =(u16RegNumORdata&0xff);

		dbdatanum = 3;
	   }
		else if(FunctionCodeTemp==3)		//ģ��ģ��������������ѯ�ظ�
	   {
			TBUF[4] = dbdatanum;
		  	for(i=0;i<dbdatanum;i+=2)         					     
       	  {
         	TBUF[5+i] =((*BUFaddress)&0xff00)>>8; 
         	TBUF[6+i] =(*BUFaddress++)&0xff; 
       	  }
	   }
	    else	
	   {
	   return;
	   }

         CRCcodeDelt(TBUF,5+dbdatanum);         	
      	 TBUF[5+dbdatanum] = (CRC&0xff00)>>8;
		 TBUF[6+dbdatanum] = (CRC&0xff);
		 asm(" RPT #99 || NOP"); 

		 SciTransData(7+dbdatanum);
   }
}

  
/*-----------------------------------------*/
/*  received code delt program             */  
/*-----------------------------------------*/	
void Class_SCIDrv::SciReceiveCodeDelt(void)
{
   Uint16  i,j;
   MONITOR_APDU_T TempArray;
   if(sciFlagReg.sciReceiveOver) 
 {    
 	sciFlagReg.sciReceiveOver=0;   

	TempArray.u16ServiceCode = FunctionAddress;
	TempArray.u16DataNum =u16RegNumORdata;
	TempArray.u16XmReDirection = 0;		// ��ʼ��Ϊ����ģʽ
	TempArray.u16MsgClass = 0;

    switch(FunctionCode)
	{
	case 0x33: 
		DebugDatadelt();
	case 3:   							//��ȡģ������Ϣ
	  TempArray.u16XmReDirection = 1;		//����Ϊ�ϴ�ģʽ��	
	  if(FunctionAddress==0x71)
	  {	
		TempArray.u16MsgClass = CFG_MSG_CLASS;
	  }
	  else if(FunctionAddress==0x1001)	//DC��ģ����������
	  {	
		TempArray.u16MsgClass = ANALOG_MSG_CLASS;
	  }
        break;
	case 6:					//ϵͳ����
		TempArray.u16MsgClass = CTRL_MSG_CLASS;
		TempArray.pDataPtr[0]=u16RegNumORdata;

		break;

 	case 10:
	 	if(RBUF[2]==0)	//�㲥ϵͳ���ò���	//�㲥֡ģ�鲻�ظ� 
	  {  
		
	  }
		TempArray.u16MsgClass = CFG_MSG_CLASS;

		for(i=0,j=0;i<(u16RegNumORdata*2);i+=2,j++)
	  	{	
		 	TempArray.pDataPtr[j]=(DATABUF[i]<<8)&0xff00+DATABUF[i+1]&0xff;
	  	}  
		break;
		
 	 default:
		 break;
   }

	ObjDataExchgNEW.m_SciRecvMsgdelt(&TempArray);
	SciArrayTrans(TempArray.pDataPtr,FunctionCode,u16RegNumORdata,TempArray.u16DeltOver);
		
	for(i=0;i<nEND;i++)	//���CRC���󽫲��ظ����������㡣
  		RBUF[i]=0;
 }

}  
 
/*-----------------------------------------*/
/*  transmmit array to SCITXBUF            */  
/*-----------------------------------------*/
void Class_SCIDrv::SciTransData(Uint16 txnum)
{
   	Uint16 i;
//   GpioDataRegs.GPADAT.bit.GPIO31= 0;        /*GPIO12=RDEN =1,enable 485 DE */

   	SciaRegs.SCICTL1.bit.TXENA=1;             /*enable TXWAKE TXREN          */
 
  for(i=0;i<txnum;i++)
  {
     SciaRegs.SCITXBUF= TBUF[i];          /*send package Ӧ�������       */
     while(SciaRegs.SCICTL2.bit.TXRDY==0)    /*TXRDY=0 wait (�ȴ��������)   */
           {;}                    
     asm(" RPT #20 || NOP");                              /*TXRDY=1 empty   */
  }  
   /*ѭ�����������*/
// 	 SciaRegs.SCITXBUF= 0x00;          		 /*�����޹�����       */
//     while(SciaRegs.SCICTL2.bit.TXRDY==0)    /*TXRDY=0 wait (�ȴ��������)   */
//           {;}                   
     asm(" RPT #20 || NOP");                              /* TXRDY=1 empty   */
 	                                
   	SciaRegs.SCICTL1.bit.TXENA=0;             /*disable TXREN(��ֹ����)(ʹ�ܽ���) */
//   GpioDataRegs.GPADAT.bit.GPIO31=1;         /*GPIO12=RDEN =0,dienable 485 DE    */  
}

/*-----------------------------------------*/
/*  right received  responses  program     */  
/*-----------------------------------------*/
void Class_SCIDrv::DebugDatadelt(void)  
 {   
       TBUF[0] = 0xFE;                     
       TBUF[1] = (ren[10]&0xff00)>>8; 
       TBUF[2] = (ren[10]&0xff);
       TBUF[3] = (ren[11]&0xff00)>>8;
       TBUF[4] = (ren[11]&0xff);  
       TBUF[5] = (ren[12]&0xff00)>>8;
       TBUF[6] = (ren[12]&0xff); 
       TBUF[7] = 0x1; 
       TBUF[8] = (ren[13]&0xff00)>>8;
       TBUF[9] = (ren[13]&0xff);  
	   TBUF[10] = (ren[14]&0xff00)>>8;
       TBUF[11] = (ren[14]&0xff);
	   TBUF[12] = (ren[15]&0xff00)>>8;
       TBUF[13] = (ren[15]&0xff);
       TBUF[14] = 0x2;	   	   
       TBUF[15] = s2u(objLogicManager.m_st_LogicManagerMainFlag)&0xff; 
	   TBUF[16] = (ren[16]&0xff00)>>8;
	   TBUF[17] = (ren[16]&0xff);
	   TBUF[18] = ((s2u(objDigitalIO.m_st_IOFlag))&0xff00)>>8;
	   TBUF[19] = (s2u(objDigitalIO.m_st_IOFlag))&0xff;
       TBUF[20] = (objBattery.m_un_VBatt.half.hword&0xff00)>>8;  
	   TBUF[21] = (objBattery.m_un_VBatt.half.hword&0xff);  
       TBUF[22] = 0xEF;                                                           
	   SciTransData(23);
 }    
 
/*-----------------------------------------*/
/*  right received  responses  program     */  
/*-----------------------------------------*/
void Class_SCIDrv::rightdelt(void)  
 {   
       TBUF[0] = 0xFE;                     /*send package head 0xff  */
       TBUF[1] = 0xFE;                     /*send package head 0xff  */                                        
       TBUF[2] = 0x05;                     /*message len*/
	   TBUF[3] = 0x11;                	/*equipment  address   */
       TBUF[4] = 0x22;               	/*function  code*/ 
       TBUF[5] = 0x33;                	/*���ݳ���*/ 
       TBUF[6] = 0x44;                 	/*register H �Ĵ������ֽ�*/ 
       TBUF[7] = 0x55;                 	/*register L �Ĵ������ֽ�*/
       TBUF[8] = 0x66;            	  	/*register  address  Rn*/ 
	   CRCcodeDelt(TBUF,9);
       TBUF[9] = (CRC&0xff00)>>8;       /*���ص����ݸ��ֽ�  */ 
       TBUF[10] = (CRC&0xff);          	/*���ص����ݵ��ֽ� */
       SciTransData(11);    
 }                     
  
/*-----------------------------------------*/
/*  erro  received  responses  program     */  
/*-----------------------------------------*/
void Class_SCIDrv::errodelt(void)  
 {   
       TBUF[0] = (objDCBus.m_i16_VbusP_0&0xff00)>>8;                          /*send package head 0xff  */
       TBUF[1] = (objDCBus.m_i16_VbusP_0&0xff);                               /*send package head 0xff  */
       TBUF[2] = (objDCBus.m_i16_VbusN_0&0xff00)>>8;                          /*send package head 0xff  */
       TBUF[3] = (objDCBus.m_i16_VbusN_0&0xff);                          /*send package head 0xff  */                                        
       TBUF[4] = (objDCBus.m_i16_InBAL_0&0xff00)>>8;                               /*message len*/
       TBUF[5] = (objDCBus.m_i16_InBAL_0&0xff);                     /*function  code*/
       SciTransData(6);    
 }                     

/*-----------------------------------------*/
/*   CRC   code  calculate                 */  
/*-----------------------------------------*/
Uint16 Class_SCIDrv::CRCcodeDelt(Uint16 *BUFaddress,Uint16 CRCnum)      /*���У����*/  
{  
   int i,j;
   pr=BUFaddress;                   
   regCRC=0xFFFF;			    	/*crcУ��Ĵ���ȫ��1*/ 
   for(i=0;i<CRCnum;i++,pr++)   		/*�Ի����������ݽ���У��*/
 {   
     regCRC^=*pr;	
    for(j=0;j<8;j++)  		        /*��λ�˴�,����Ĵ����Ƴ������λLSBΪ1,��Ĵ�����ֵ��0xa001���;���LSBΪ0,��ֱ����λ*/
   {
     if(regCRC&0x0001)		    /*�ж�crcУ��Ĵ������һλ�Ƿ�Ϊ1*/
     {
       regCRC>>=1;			   	/*�ƺ��λΪ1ʱ,crcУ��Ĵ�����0xA001���*/
	   regCRC^=0xA001;	   
      }
     else   regCRC>>=1;
    }  
 }
 	CRC=regCRC;
 	return(CRC);
} 

interrupt void SCIARX_ISR(void)
{    	   
     Uint16 aa;
     objSCIDrv.sciFlagReg.sciRXok =1;     /*flagc.0=1,set have received a byte flag*/ 
     aa = SciaRegs.SCIRXBUF.all;
     aa &= 0x00ff;
     objSCIDrv.RBUF[objSCIDrv.Receivecount++] = aa;   
     objSCIDrv.Receivecount &= RLEN;
	 PieCtrlRegs.PIEACK.all=PIEACK_GROUP9;	//��Ӧ�ж�,ע��Ҫд
 	 EINT;

     //asm (" clrc  INTM ");     
}



