#ifndef _SPI_H
#define _SPI_H
#include "DSP280x_Device.h"
#include "IQmathLib.h"
#ifdef spi_GLOBALS
#define spi_GLOBALS
#else
#define spi_GLOBALS extern
#endif
		struct	structLocalSignal
		{
			Uint16	bModuleReady					:1;					//BIT00				
			Uint16	bInvKM					:1;					//BIT01		��������Ӵ���					
			Uint16	bModuleReadyOk			:1;					//BIT02				
			Uint16	bRev03					:1;					//BIT03			
			Uint16	bModelOnline			:1;					//BIT04		 ����·ģ�����ڿ���SCR����������Ȩ����		     		
			Uint16	bNormalInd				:1;					//BIT05		ָʾģ������	�̵�
			Uint16	bFaultInd				:1;					//BIT06		ָʾģ����ϻ�δ׼����	���	
			Uint16	bRev07					:1;					//BIT07		����		
			Uint16	bRev08					:2;					//BIT08
			Uint16	bDcOvp				:1;					//BIT10	�ز�ͬ��
			Uint16	bRecOff					:1;					//BIT11 Ӳ��ι��
			Uint16	bInvOffToCPLD			:1;					//BIT14	�����CPLD�Ĺػ�����
			Uint16  bInvOffToDCDC           :1;
			Uint16	bInvID					:3;					//BIT15												
		};
typedef union
{
	struct structLocalSignal bit;
	Uint16 all;
}LocalSigal;
spi_GLOBALS LocalSigal BitSignal;
				
		struct 	structSPIDataOut1
		{
 			Uint16	bRev00					:1;					//BIT00		bBPS-1		
			Uint16	bINVKM					:1;					//BIT01		bINVKM-1		
			Uint16	bREV02					:1;					//BIT02		bREV1-1���������͸���صķ��ౣ���źţ�		
			Uint16	bRev03					:1;					//BIT03		bBPS_BAK-1:		
			Uint16	bBPS_WD					:1;					//BIT04		bBPS_WD-1		
			Uint16	bNormalInd				:1;					//BIT05		bInvtFaultInd		ָʾģ����ϻ�δ׼����
			Uint16	bFaultInd				:1;					//BIT06	bInvtNormalInd	ָʾģ������		
			Uint16	bREV1107				:5;					//BIT07-11
			Uint16	bZeroStateA				:1;					//BIT12 	//20111108 renqx xiaogai
			Uint16	bZeroStateB				:1;					//BIT13 	//20111108 renqx xiaogai
			Uint16	bZeroStateC				:1;					//BIT14 	//20111108 renqx xiaogai
			Uint16	bREV15					:1;					//BIT15					
		};				
typedef union
{
	struct structSPIDataOut1 bit;
	Uint16 all;
}LocalSigalout1;
spi_GLOBALS LocalSigalout1 BitSignalout1;
				
	
		struct 	structSPIDataOut2
		{  
			Uint16	bRev00					:1;					//BIT00		bBPS-2		                               
			Uint16	bINVKM					:1;					//BIT01		bINVKM-2		                               
			Uint16	bREV1					:1;					//BIT02		bREV1-2		
			Uint16	bRev03					:1;					//BIT03		bBPS_BAK-2	
			Uint16	bREV2					:2;					//BIT04-05			                           		                   
			Uint16	bADCAdjust				:2;					//BIT07-06	bADCAdjust	
			Uint16	bInvOffToCPLD			:8;					//BIT08		bInvOffToCPLD	�����CPLD�Ĺػ�����
//			Uint16	bREV3					:7;					//BIT15-09	bREV2		
		};				
typedef union
{
	struct structSPIDataOut2 bit;
	Uint16 all;
}LocalSigalout2;
spi_GLOBALS LocalSigalout2 BitSignalout2;
				
	
		struct 	structSPIDataOut3
		{
			Uint16	bRev00					:1;					//BIT00		bBPS-3		                               
			Uint16	bINVKM					:1;					//BIT01		bINVKM-3		                               
			Uint16	bREV1					:1;					//BIT02		bREV1-3		
			Uint16	bRev03					:1;					//BIT03		bBPS_BAK-3:
			Uint16	bREV2					:2;					//BIT04-05			                           
			Uint16	bINVOnMod1				:1;					//BIT06		bINVOnMod1
			Uint16	bINVOnMod2				:1;					//BIT07		bINVOnMod2	
			Uint16	bINVOnMod3				:1;					//BIT08		bINVOnMod3	
			Uint16	bINVOnMod4				:1;					//BIT09		bINVOnMod4	
			Uint16	bINVOnMod5				:1;					//BIT10		bINVOnMod5	
			Uint16	bREV11					:1;					//BIT11					                   			
			Uint16	bDebugLED				:2;					//BIT13-12	bDebugLED	���Ե�	
			Uint16	bREV1415				:2;					//BIT15-14			
		};				
typedef union
{
	struct structSPIDataOut3 bit;
	Uint16 all;
}LocalSigalout3;
spi_GLOBALS LocalSigalout3 BitSignalout3;
		struct 	structSPIDataOut4
		{
 			Uint16	bINV_OVERLOAD			:1;					//BIT00		bINV_OVERLOAD			
			Uint16	bSYSTEM_UNLOCK			:1;					//BIT01		bSYSTEM_UNLOCK			
			Uint16	bINV_ON_STANDBY			:1;					//BIT02		bINV_ON_STANDBY			
			Uint16	bINV_BP_STATUS			:1;					//BIT03		bINV_BP_STATUS			
			Uint16	bINV_STATE				:1;					//BIT04		bINV_STATE(�͸�����)			
			Uint16	bMASTER_ONLINE			:1;					//BIT05	bMASTER_ONLINE			
			Uint16	bREV06					:1;					//BIT06					
			Uint16	bREV07					:1;					//BIT07				
			Uint16	bDSPFirmWareOK			:1;					//BIT08		bDSPFirmWareOK			
			Uint16	bModelOnline			:1;					//BIT09		bModelOnline	
			Uint16	bNetState				:1;					//BIT10		TO REC
			Uint16	bdebug					:1;					//BIT11 ������
			Uint16	LedBdebug				:1;					//BIT12 ������
			Uint16	bREV					:3;					//BIT15-13		bREV						
		};				
typedef union
{
	struct structSPIDataOut4 bit;
	Uint16 all;
}LocalSigalout4;
spi_GLOBALS LocalSigalout4 BitSignalout4;
				
	
		struct 	structSPIDataOut5
		{
 			Uint16	bVbatt					:12;			//BIT11-00	bS01(SPI DA��������1)			
			Uint16	bInvNA					:1;				//BIT11-02	bDA			
			Uint16	bREV					:3;				//BIT11-02	bDA			
		};

typedef union
{
	struct structSPIDataOut5 bit;
	Uint16 all;
}LocalSigalout5;
spi_GLOBALS LocalSigalout5 BitSignalout5;
				
	
		struct 	structSPIDataIn1
		{
 			Uint16	bREV00					:1;					//BIT00				
			Uint16	bSYSTEM_UNLOCK_F		:1;					//BIT01		bSYSTEM_UNLOCK_F			
			Uint16	bREV02					:1;					//BIT02		bINV_ON_STANDBY_F			
			Uint16	bINV_BP_STATUS_F		:1;					//BIT03		bINV_BP_STATUS_F						
			Uint16	bMASTER_ONLINE_F		:1;					//BIT04		bMASTER_ONLINE_F			
			Uint16	bRev0506				:2;					//BIT05						
			Uint16	bREV07					:1;					//BIT07					
			Uint16	bLeader_Rack			:1;					//BIT08		 bLeader_Rack					
			Uint16	bRev09					:1;					//BIT09							
			Uint16	bRev10					:1;					//BIT10		bQ5			
			Uint16	bCPLDVer				:4;					//BIT14-11	bCPLDVer
			Uint16	bREV15					:1;					//BIT15			
		};				
typedef union
{
	struct structSPIDataIn1 bit;
	Uint16 all;
}LocalSigalin1;
spi_GLOBALS LocalSigalin1 BitSignalin1;
				
	
		struct 	structSPIDataIn2
		{
			Uint16	bRev1					:1;					//BIT00-
			Uint16	bModOverTemp			:1;					//BIT01-
			Uint16	bRev2					:1;					//BIT02																									
			Uint16	bFuse					:1;					//BIT03		bFuse			
			Uint16	bModuleReady			:1;					//BIT04		bInvtModuleReady			
			Uint16	bOcp        			:1;					//BIT05		bInvtIoTestMode			
			Uint16	bInvtServiceMode		:1;					//BIT06		bInvtServiceMode			
			Uint16	bREV07					:1;					//BIT07					
			Uint16	bRevDcOvp				:1;					//BIT08		bRevDcOvp			
			Uint16	bFanFault				:1;					//BIT09		bFanFault					
			Uint16	bInvID					:3;					//BIT10-13		bInvID	
			Uint16	bInvIDRev					:1;					//BIT10-13		bInvID			
		
			Uint16	bDSPFirmWareOK			:1;					//BIT14		bDSPFirmWareOK)	��Ӧ INSET����					
			Uint16	bRev					:1;					//BIT15								
		};		
typedef union
{
	struct structSPIDataIn2 bit;
	Uint16 all;
}LocalSigalin2;
spi_GLOBALS LocalSigalin2 BitSignalin2;	
		struct 	structSPIDataIn3
		{
 			Uint16	bRecOff					:1;					//BIT00		bRecoff ֱ��û׼����ǰ�����ػ�			
			Uint16	bRecFault				:1;					//BIT01		bRecFault			
			Uint16	bPow15vFault			:1;					//BIT02		bPowOk			
			Uint16	bRevEPO					:1;					//BIT03		bInvtEPO			
			Uint16	bRev					:3;					//BIT06-04	
			Uint16  bRevPower24vFault		:1;					//BIT07		bPowerFault	
			Uint16	bRev08					:1;					//BIT08		
			Uint16	bINVOnMod1				:1;					//BIT09		bINVOnMod1
			Uint16	bINVOnMod2				:1;					//BIT10		bINVOnMod2
			Uint16	bINVOnMod3				:1;					//BIT11		bINVOnMod3
			Uint16	bINVOnMod4				:1;					//BIT12		bINVOnMod4
			Uint16	bINVOnMod5				:1;					//BIT13		bINVOnMod5			
			Uint16	bRev2					:2;					//BIT15				
		};
typedef union
{
	struct structSPIDataIn3 bit;
	Uint16 all;
}LocalSigalin3;
spi_GLOBALS LocalSigalin3 BitSignalin3;								
		struct 	structSPIDataIn4
		{
			Uint16	bREV0					:1;					//BIT00��·�����ź�
			Uint16	bRECFault				:2;					//BIT01-02�������������0:����1:һ����2:���ع���			
			Uint16	TemptureDATA			:13;				//BIT15-04	bREV		
		};	

typedef union
{
	struct structSPIDataIn4 bit;
	Uint16 all;
}LocalSigalin4;
spi_GLOBALS LocalSigalin4 BitSignalin4;
void DigitalOper();
void SPI_ACT();
#endif
