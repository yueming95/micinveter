#include "GPIODrv.h"



void	Class_GPIODrv::Drv_Init(void)
{
	EALLOW;

   	GpioCtrlRegs.GPAMUX1.all = 0x0FF555555;    				// PWM1A,PWM1B;
   															// PWM2A,PWM2B;
   															// PWM3A,PWM3B;
   															// PWM4A,PWM4B;
   									    					// PWM5A,PWM5B;
   															// PWM6A,PWM6B;
   															// SPI_B;
   	GpioCtrlRegs.GPAMUX2.all = 0x5501F000;      			
   															// GPIO16,GPIO17;
   															// GPIO18,GPIO19;
   															// GPIO20,GPIO21;
   															// SCIB;
   															// CAP1,GPIO25;
   															// GPIO26,GPIO27
   															// SCIA;
   															// GPIO30,GPIO31-CAN(0101)
   	GpioCtrlRegs.GPBMUX1.all = 0x00000005;					//GPIO32,GPIO33����ΪI2C���蹦��
   															//GPIO34
   	GpioCtrlRegs.GPBMUX2.all = 0;                 			
                                                			
                                                			
   	GpioCtrlRegs.GPADIR.all = 0x0FEFFFFFF;      			// GPIO0-GPIO23 are GP outputs,GPIO24 isinputs,GPIO25~GPIO31 are outputs
   	GpioCtrlRegs.GPBDIR.all = 0x000000005;      			// GPIO32-GPIO34 are outputs
                                                			
                                                			
   	GpioCtrlRegs.GPAPUD.all = 0x0000;      					// Pullup's enabled GPIO0-GPIO31
   	GpioCtrlRegs.GPBPUD.all = 0x0000;      					// Pullup's enabled GPIO32-GPIO34
                                                			
   	GpioCtrlRegs.GPACTRL.all = 0x0000;      				// Samping period =Tsysclkout
   	GpioCtrlRegs.GPBCTRL.all = 0x0000;      				// Samping period =Tsysclkout
   	GpioCtrlRegs.GPAQSEL1.all = 0x0FF000000;				// 1 Period,Asynchronous for SPI_B
   	GpioCtrlRegs.GPAQSEL2.all = 0x000030000;				// 1 Period,Asynchronous for CAP1
   	GpioCtrlRegs.GPBQSEL1.all = 0x00000000F;				// 1 Period,
   	GpioCtrlRegs.GPBQSEL2.all = 0x000000000;				// 1 Period,

   	EDIS;
}


//SPI��1֡Ƭѡ
inline	void	Class_GPIODrv::Drv_GPIO_SPI1(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;					//Ƭѡ0,0,0
	GpioDataRegs.GPACLEAR.bit.GPIO26 = 1;             		
	GpioDataRegs.GPACLEAR.bit.GPIO25 = 1;             		
}                                                   		
                                                    		
                                                    		
//SPI��2֡Ƭѡ                                      		
inline	void	Class_GPIODrv::Drv_GPIO_SPI2(void)  		
{                                                   		
	GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;					//Ƭѡ0,0,1
	GpioDataRegs.GPACLEAR.bit.GPIO26 = 1;
	GpioDataRegs.GPASET.bit.GPIO25 = 1;
}

//SPI��3֡Ƭѡ
inline	void	Class_GPIODrv::Drv_GPIO_SPI3(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;					//Ƭѡ0,1,0
	GpioDataRegs.GPASET.bit.GPIO26 = 1;
	GpioDataRegs.GPACLEAR.bit.GPIO25 = 1;
}

//SPI��4֡Ƭѡ				
inline	void	Class_GPIODrv::Drv_GPIO_SPI4(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO27 = 1;					//Ƭѡ0,1,1
	GpioDataRegs.GPASET.bit.GPIO26 = 1;
	GpioDataRegs.GPASET.bit.GPIO25 = 1;
}

//SPI��5֡Ƭѡ				
inline	void	Class_GPIODrv::Drv_GPIO_SPI5(void)
{
	GpioDataRegs.GPASET.bit.GPIO27 = 1;						//Ƭѡ1,#,#
}


//SPI��6֡Ƭѡ				
inline	void	Class_GPIODrv::Drv_GPIO_SPI6(void)
{
	GpioDataRegs.GPASET.bit.GPIO27 = 1;						//Ƭѡ1,#,#
}

#pragma CODE_SECTION("Epwm1Funcs");				
////AD��ʾֵ�ĵ�1�ֲ���
inline	void	Class_GPIODrv::Drv_GPIO_ADChannel1(void)
{
	GpioDataRegs.GPASET.bit.GPIO16 = 1;						//AD��һͨ��Ƭѡ
	
}


//AD��ʾֵ�ĵ�2�ֲ���
inline	void	Class_GPIODrv::Drv_GPIO_ADChannel2(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO16 = 1;						//AD�ڶ�ͨ��Ƭѡ
}


//AD��ʾֵ���л�
void		Class_GPIODrv::Drv_GPIO_ADDispSwitch(UINT16& u16_ADChannelCnt)
{
	switch(u16_ADChannelCnt)
	{
		case 0:
			GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;
			GpioDataRegs.GPACLEAR.bit.GPIO17 = 1;
			break;
		case 1:
			GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;
 			GpioDataRegs.GPASET.bit.GPIO17 = 1;
			break;
		case 2:
			GpioDataRegs.GPASET.bit.GPIO18 = 1;
 			GpioDataRegs.GPACLEAR.bit.GPIO17 = 1;
			break;
		case 3:
			GpioDataRegs.GPASET.bit.GPIO18 = 1;
			GpioDataRegs.GPASET.bit.GPIO17 = 1;
			break;
		default:
			break;
	}

}


//BP2����ʱ��CPLD�ź�
inline	void	Class_GPIODrv::Drv_GPIO_PWMBP2(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO20 = 1;
}		


//BN2����ʱ��CPLD�ź�	
inline	void	Class_GPIODrv::Drv_GPIO_PWMBN2(void)
{
	GpioDataRegs.GPASET.bit.GPIO20 = 1;
}


//CP2����ʱ��CPLD�ź�			
inline	void	Class_GPIODrv::Drv_GPIO_PWMCP2(void)
{
	GpioDataRegs.GPACLEAR.bit.GPIO21 = 1;
}


//CN2����ʱ��CPLD�ź�			
inline	void	Class_GPIODrv::Drv_GPIO_PWMCN2(void)
{
	GpioDataRegs.GPASET.bit.GPIO21 = 1;
}

inline	void	Class_GPIODrv::Drv_GPIO_TestSet(void)
{
	GpioDataRegs.GPBSET.bit.GPIO34 = 1;
}

inline	void	Class_GPIODrv::Drv_GPIO_TestClear(void)
{
	GpioDataRegs.GPBCLEAR.bit.GPIO34 = 1;
}

//============================================================
// End of file.
//============================================================
