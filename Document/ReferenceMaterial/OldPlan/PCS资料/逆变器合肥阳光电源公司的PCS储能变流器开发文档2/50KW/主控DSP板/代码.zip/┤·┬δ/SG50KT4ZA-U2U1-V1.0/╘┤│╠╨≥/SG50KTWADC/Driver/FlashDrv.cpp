#include "FlashDrv.h"




#pragma CODE_SECTION("ramfuncs");
void	Class_FlashDrv::Drv_Init(void)
{
	EALLOW;
	//Enable Flash Pipeline mode to improve performance of code executed from Flash.
	FlashRegs.FOPT.bit.ENPIPE = 1;
	
	//                CAUTION
	//Minimum waitstates required for the flash operating
	//at a given CPU rate must be characterized by TI.
	//Refer to the datasheet for the latest information.
	
	//Set the Paged Waitstate for the Flash
	FlashRegs.FBANKWAIT.bit.PAGEWAIT = 5;
	
	//Set the Random Waitstate for the Flash
	FlashRegs.FBANKWAIT.bit.RANDWAIT = 5;
	
	//Set the Waitstate for the OTP
	FlashRegs.FOTPWAIT.bit.OTPWAIT = 8;
	
	//                CAUTION
	//ONLY THE DEFAULT VALUE FOR THESE 2 REGISTERS SHOULD BE USED
	FlashRegs.FSTDBYWAIT.bit.STDBYWAIT = 0x01FF;
	FlashRegs.FACTIVEWAIT.bit.ACTIVEWAIT = 0x01FF;
	EDIS;
	
	//Force a pipeline flush to ensure that the write to
	//the last register configured occurs before returning.
	
	asm(" RPT #7 || NOP");
}


/*
//���ܺ���
void	Class_FlashDrv::Drv_Encrypt(void)
{
//	UINT16 u16_j;
	volatile INT16  	*CSMSCR = (volatile int *)0x0000AEF;//CSMSCR register	
//	volatile UINT16 	*Passaddr;




	//��ʼ��0x3F7F80��0x3F7FF5
//	Passaddr = (UINT16 *) 0x3F7F80;
//	for (u16_j = 0x0000; u16_j < 0x76; u16_j++)			
//	{
//		*(Passaddr + u16_j) = 0x0;
//	}
	
	//д���뵽PWL�Ĵ���
	// 0x9106 0x8909 0x2991 0x9952 0x3659 0x9235 0x0911 0x1901 is used.
//	asm(" .sect csmpasswds ");                       
//	asm(" .WORD 0FFFFH,0FFFFH,0FFFFH,0FFFFH,0FFFFH,0FFFFH,0FFFFH,0FFFFH ");
//	asm(" .text ");
	
	EALLOW;
	*CSMSCR = 0x8000;										//Set FORCESEC bit 
	EDIS;
}*/
//============================================================
// End of file.
//============================================================
