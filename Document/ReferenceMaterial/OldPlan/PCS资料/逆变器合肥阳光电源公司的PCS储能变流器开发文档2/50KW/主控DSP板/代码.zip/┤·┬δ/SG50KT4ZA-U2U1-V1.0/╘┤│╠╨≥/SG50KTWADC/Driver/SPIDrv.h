/*==========================================================*/
/* Title		:	SPIDrv.h								*/
/* Description	: 	Class_SPIDrv definition					*/
/* Date			:	Oct.2007								*/
/*==========================================================*/

#ifndef DSP280x_SPIDRV_H
#define DSP280x_SPIDRV_H

//============================================================
//	Class_SPIDrv���ⲿ�Ľӿ�
//	1)����
//============================================================
class Class_SPIDrv
{
	private:

	public:
		void	Drv_Init(void);								//��ʼ��

		inline	void	Drv_SPISendData(UINT16 uSend);		//SPI��������
		inline	UINT16	Drv_SPIReceiveData(void);			//SPI��������
};

#endif
//============================================================
// End of file.
//============================================================
