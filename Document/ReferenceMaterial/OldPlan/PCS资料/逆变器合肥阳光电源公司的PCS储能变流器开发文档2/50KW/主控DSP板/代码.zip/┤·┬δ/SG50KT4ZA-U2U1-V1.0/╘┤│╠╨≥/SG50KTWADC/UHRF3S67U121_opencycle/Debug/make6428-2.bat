@echo off
echo 'Building file: E:/work/SG50KT4ZA/program/SG50KTWADC/App/Classes/template.cpp'
