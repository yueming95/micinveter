@echo off
echo 'Building file: E:/work/SG50KT4ZA/program/SG50KTWAAC_SPWM/source/DSP280x_PieVect.c'
