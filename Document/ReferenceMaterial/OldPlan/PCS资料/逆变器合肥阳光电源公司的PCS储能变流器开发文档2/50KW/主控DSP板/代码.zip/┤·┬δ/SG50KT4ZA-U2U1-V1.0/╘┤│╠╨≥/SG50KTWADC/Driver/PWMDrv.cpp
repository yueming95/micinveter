#include "PWMDrv.h"

//��ʼ��EPWM
//EPwm1,EPwm2,EPwm3  for Rectifier1
//EPwm4,EPwm5,EPwm6  for Rectifier2 when battery discharge
//EPwm5 CMPA for positive and negative of main input B
//EPwm5 CMPB for Charger positive when main input
//EPwm6 CMPB for positive and negative of main input C
//EPwm6 CMPB for Charger negative when main input
void	Class_PWMDrv::Drv_Init(void)										
{
	EALLOW;
	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 0;
	EDIS;

  	EALLOW;
	EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm1Regs.TZFRC.bit.OST = 1;
	EDIS;

   	EPwm1Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
   	EPwm1Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm1Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm1Regs.TBCTL.bit.PHSEN = TB_DISABLE;    				// Disable phase loading
   	EPwm1Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm1Regs.TBCTL.bit.SYNCOSEL = TB_CTR_ZERO;
   	EPwm1Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm1Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm1Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm1Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm1Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm1Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
   	EPwm1Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

   	EPwm1Regs.AQCTLA.bit.CAD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm1Regs.AQCTLA.bit.CAU = AQ_SET;						//CNT=CMP up   ->1
   	EPwm1Regs.AQCTLB.bit.CBD = AQ_CLEAR;					//CNT=CMP up   ->0
   	EPwm1Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP down ->1

	EPwm1Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm1Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm1Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm1Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;

  	EPwm1Regs.ETSEL.bit.INTSEL = 0;     					// No INT
   	EPwm1Regs.ETSEL.bit.INTEN = 0;                			// Disable INT
   	EPwm1Regs.ETPS.bit.INTPRD = ET_1ST;           			// Generate INT on 3rd event


   	EALLOW;
	EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm2Regs.TZFRC.bit.OST = 1;
	EDIS;

   	EPwm2Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
   	EPwm2Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm2Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm2Regs.TBCTL.bit.PHSEN = TB_ENABLE;    				// Enable phase loading
   	EPwm2Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm2Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
   	EPwm2Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm2Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm2Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm2Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm2Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm2Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
   	EPwm2Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm2Regs.AQCTLA.bit.CAD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm2Regs.AQCTLA.bit.CAU = AQ_SET;						//CNT=CMP up   ->1
   	EPwm2Regs.AQCTLB.bit.CBD = AQ_CLEAR;					//CNT=CMP up   ->0	
   	EPwm2Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP down ->1

   	EPwm2Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm2Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm2Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm2Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;


	EALLOW;
	EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm3Regs.TZFRC.bit.OST = 1;
	EDIS;

   	EPwm3Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
   	EPwm3Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm3Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm3Regs.TBCTL.bit.PHSEN = TB_ENABLE;    				// Enable phase loading
   	EPwm3Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm3Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
   	EPwm3Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm3Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm3Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm3Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm3Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm3Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
   	EPwm3Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm3Regs.AQCTLA.bit.CAD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm3Regs.AQCTLA.bit.CAU = AQ_SET;						//CNT=CMP up   ->1
	EPwm3Regs.AQCTLB.bit.CBD= AQ_CLEAR;						//CNT=CMP down ->0
   	EPwm3Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP up   ->1

	EPwm3Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm3Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm3Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm3Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;


   	EALLOW;
	EPwm4Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm4Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm4Regs.TZFRC.bit.OST = 1;
	EDIS;

	EPwm4Regs.CMPA.half.CMPA = 2083;						//50%ռ�ձ�
		
//   	EPwm4Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
	EPwm4Regs.TBPRD = 4166;       				// Set timer period
	EPwm4Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm4Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm4Regs.TBCTL.bit.PHSEN = TB_DISABLE;    				// Enable phase loading
   	EPwm4Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm4Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
   	EPwm4Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm4Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm4Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm4Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm4Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm4Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;

	//EPwm4Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

	//EPwm4Regs.AQCTLA.bit.CAD = AQ_SET;						//CNT=CMP down ->1 
	//EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;					//CNT=CMP up   ->0
	// 	EPwm4Regs.AQCTLB.bit.CBD = AQ_CLEAR;					//CNT=CMP down ->0
	//  	EPwm4Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP up   ->1 
  	
  	EPwm4Regs.AQCTLA.bit.CAD = AQ_SET;							//CNT=CMP down ->0 renqx�޸� 20110720
   	EPwm4Regs.AQCTLA.bit.CAU = AQ_CLEAR;						//CNT=CMP up   ->1 renqx�޸� 20110720
   	EPwm4Regs.AQCTLB.bit.CAD = AQ_CLEAR;						//CNT=CMP down ->1 renqx�޸� 20110720
  	EPwm4Regs.AQCTLB.bit.CAU = AQ_SET;							//CNT=CMP up   ->0 renqx�޸� 20110720

 	EPwm4Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm4Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm4Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm4Regs.DBCTL.bit.IN_MODE = DBA_ALL;
  	EPwm4Regs.DBCTL.bit.OUT_MODE = DB_FULL_ENABLE;
	EPwm4Regs.DBCTL.bit.POLSEL = DB_ACTV_LOC;
	EPwm4Regs.DBRED = 300;
	EPwm4Regs.DBFED = 300;
	
   	EALLOW;
	EPwm5Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm5Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm5Regs.TZFRC.bit.OST = 1;
	EDIS;

   	EPwm5Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
   	EPwm5Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm5Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm5Regs.TBCTL.bit.PHSEN = TB_ENABLE;    				// Enable phase loading
   	EPwm5Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm5Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
   	EPwm5Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm5Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm5Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm5Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm5Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm5Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
   	EPwm5Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm5Regs.AQCTLA.bit.CAD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm5Regs.AQCTLA.bit.CAU = AQ_SET;						//CNT=CMP up   ->1
   	EPwm5Regs.AQCTLB.bit.CBD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm5Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP up   ->1

	EPwm5Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm5Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm5Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm5Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;


   	EALLOW;
	EPwm6Regs.TZCTL.bit.TZA = TZ_FORCE_HI;
	EPwm6Regs.TZCTL.bit.TZB = TZ_FORCE_HI;
	EPwm6Regs.TZFRC.bit.OST = 1;
	EDIS;


   	EPwm6Regs.TBPRD = EPWM1_TIMER_TBPRD;       				// Set timer period
   	EPwm6Regs.TBPHS.half.TBPHS = 0;							// Phase is 0

   	EPwm6Regs.TBCTL.bit.CTRMODE = TB_COUNT_UPDOWN; 			// Count up and down
   	EPwm6Regs.TBCTL.bit.PHSEN = TB_ENABLE;    				// Enable phase loading
   	EPwm6Regs.TBCTL.bit.PRDLD = TB_SHADOW;
   	EPwm6Regs.TBCTL.bit.SYNCOSEL = TB_SYNC_IN;
   	EPwm6Regs.TBCTL.bit.HSPCLKDIV = TB_DIV1;   				// Clock ratio to SYSCLKOUT
   	EPwm6Regs.TBCTL.bit.CLKDIV = TB_DIV1;

   	EPwm6Regs.TBCTR = 0x0000;                  				// Clear counter

   	EPwm6Regs.CMPCTL.bit.SHDWAMODE = CC_SHADOW;				//SHDWAMODE is selected
   	EPwm6Regs.CMPCTL.bit.SHDWBMODE = CC_SHADOW;
   	EPwm6Regs.CMPCTL.bit.LOADAMODE = CC_CTR_ZERO_PRD;
   	EPwm6Regs.CMPCTL.bit.LOADBMODE = CC_CTR_ZERO_PRD;

    EPwm6Regs.AQCTLA.bit.CAD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm6Regs.AQCTLA.bit.CAU = AQ_SET;						//CNT=CMP up   ->1
   	EPwm6Regs.AQCTLB.bit.CBD = AQ_CLEAR;					//CNT=CMP down ->0
   	EPwm6Regs.AQCTLB.bit.CBU = AQ_SET;						//CNT=CMP up   ->1

	EPwm6Regs.AQSFRC.bit.RLDCSF = 3;						// the active register load immediately
   	EPwm6Regs.AQCSFRC.bit.CSFA = AQC_NO_ACTION;
	EPwm6Regs.AQCSFRC.bit.CSFB = AQC_NO_ACTION;

	EPwm6Regs.DBCTL.bit.OUT_MODE = DB_DISABLE;


	EPwm1Regs.TBCTR = 0x0000;
	EPwm2Regs.TBCTR = 0x0000;
	EPwm3Regs.TBCTR = 0x0000;
	EPwm4Regs.TBCTR = 0x0000;
	EPwm5Regs.TBCTR = 0x0000;
	EPwm6Regs.TBCTR = 0x0000;


   	EALLOW;
   	SysCtrlRegs.PCLKCR0.bit.TBCLKSYNC = 1;
   	EDIS;
}


//������ڼĴ�����ֵ
inline	UINT16	Class_PWMDrv::Drv_GetPrd(void)
{
	return(EPWM1_TIMER_TBPRD);
}

//�������ڼĴ�����ֵ
inline	void	Class_PWMDrv::Drv_SetPrd(INT16 i16_Period)
{
	INT16 i16_PeriodTemp;
	
	i16_PeriodTemp = i16_Period;	
	UpDownLimit16(i16_PeriodTemp,CARRIER_TBPRD_UPLMT,CARRIER_TBPRD_DOWNLMT);

	EPwm1Regs.TBPRD = i16_PeriodTemp;
	EPwm2Regs.TBPRD = i16_PeriodTemp;
	EPwm3Regs.TBPRD = i16_PeriodTemp;
	EPwm4Regs.TBPRD = i16_PeriodTemp;
	EPwm5Regs.TBPRD = i16_PeriodTemp;
	EPwm6Regs.TBPRD = i16_PeriodTemp;
}

//�������ر�ʱ�ģУףʹ���
void	Class_PWMDrv::Drv_DischargerOffPWM(void)
{
	//���PWM�ȽϼĴ���
	EPwm1Regs.CMPA.half.CMPA = CMPR_LMT_VALUE_DOWN;
	EPwm1Regs.CMPB = CMPR_LMT_VALUE_DOWN;
	EPwm2Regs.CMPA.half.CMPA = CMPR_LMT_VALUE_DOWN;
	EPwm2Regs.CMPB = CMPR_LMT_VALUE_DOWN;
	EPwm3Regs.CMPA.half.CMPA = CMPR_LMT_VALUE_DOWN;
	EPwm3Regs.CMPB = CMPR_LMT_VALUE_DOWN;
	
	EPwm4Regs.CMPA.half.CMPA = 2083;
//	EPwm4Regs.CMPB = CMPR_LMT_VALUE_DOWN;
//	EPwm5Regs.CMPA.half.CMPA = CMPR_LMT_VALUE_DOWN;
//	EPwm5Regs.CMPB = CMPR_LMT_VALUE_DOWN;
//	EPwm6Regs.CMPA.half.CMPA = CMPR_LMT_VALUE_DOWN;
//	EPwm6Regs.CMPB = CMPR_LMT_VALUE_DOWN;
	
	
   	EALLOW;													//��ֹ�Уף����
	EPwm1Regs.TZCTL.bit.TZA = TZ_FORCE_HI;				//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm1Regs.TZCTL.bit.TZB = TZ_FORCE_HI;				//TZB ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm2Regs.TZCTL.bit.TZA = TZ_FORCE_HI;				//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm2Regs.TZCTL.bit.TZB = TZ_FORCE_HI;				//TZB ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm3Regs.TZCTL.bit.TZA = TZ_FORCE_HI;				//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm3Regs.TZCTL.bit.TZB = TZ_FORCE_HI;				//TZB ǿ�Ƹߣ���ֹIGBT��ͨ

	EPwm4Regs.TZCTL.bit.TZA = TZ_FORCE_HI;				//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
	EPwm4Regs.TZCTL.bit.TZB = TZ_FORCE_HI;				//TZB ǿ�Ƹߣ���ֹIGBT��ͨ
//	EPwm5Regs.TZCTL.bit.TZA = TZ_FORCE_HI;					//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
//	EPwm5Regs.TZCTL.bit.TZB = TZ_FORCE_HI;					//TZB ǿ�Ƹߣ���ֹIGBT��ͨ
//	EPwm6Regs.TZCTL.bit.TZA = TZ_FORCE_HI;					//TZA ǿ�Ƹߣ���ֹIGBT��ͨ
//	EPwm6Regs.TZCTL.bit.TZB = TZ_FORCE_HI;					//TZB ǿ�Ƹߣ���ֹIGBT��ͨ

	EPwm1Regs.TZFRC.bit.OST = 1;
	EPwm2Regs.TZFRC.bit.OST = 1;
	EPwm3Regs.TZFRC.bit.OST = 1;
	EPwm4Regs.TZFRC.bit.OST = 1;
//	EPwm5Regs.TZFRC.bit.OST = 1;
//	EPwm6Regs.TZFRC.bit.OST = 1;
	EDIS;
}


//�������������ʱ�ģУףʹ���������ģ�飱
void	Class_PWMDrv::Drv_BatPWM1_2(INT16 i16_PWMAP,INT16 i16_PWMAN,INT16 i16_PWMBP,
		INT16 i16_PWMBN,INT16 i16_PWMCP,INT16 i16_PWMCN)
{	
	INT16 i16_PWMAPTemp,i16_PWMANTemp,i16_PWMBPTemp,i16_PWMBNTemp,i16_PWMCPTemp,i16_PWMCNTemp;
	
	i16_PWMAPTemp = ((INT32)i16_PWMAP * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMAPTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	i16_PWMANTemp = ((INT32)i16_PWMAN * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMANTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	i16_PWMBPTemp = ((INT32)i16_PWMBP * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMBPTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	i16_PWMBNTemp =((INT32)i16_PWMBN * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMBNTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	i16_PWMCPTemp = ((INT32)i16_PWMCP * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMCPTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	i16_PWMCNTemp = ((INT32)i16_PWMCN * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_PWMCNTemp,CMPR_LMT_VALUE_UP,CMPR_LMT_VALUE_DOWN);
	
	EPwm1Regs.CMPA.half.CMPA = i16_PWMAPTemp;
	EPwm1Regs.CMPB = i16_PWMANTemp;
	EPwm2Regs.CMPA.half.CMPA = i16_PWMBPTemp;
	EPwm2Regs.CMPB = i16_PWMBNTemp;
	EPwm3Regs.CMPA.half.CMPA = i16_PWMCPTemp;
	EPwm3Regs.CMPB = i16_PWMCNTemp;

	//�ز����࣬���ڵ�������
	EPwm2Regs.TBCTL.bit.PHSDIR = TB_DOWN;
	EPwm2Regs.TBPHS.half.TBPHS = 1389;						//1250*1/2

	EPwm3Regs.TBCTL.bit.PHSDIR = TB_UP;
	EPwm3Regs.TBPHS.half.TBPHS = 1389;

	if(objDischarger.Dat_GetBoostDelayOK())
	{
		EALLOW;													//ʹ�ܣУף����
		EPwm1Regs.TZCLR.bit.OST = 1;
		EPwm2Regs.TZCLR.bit.OST = 1;
		EPwm3Regs.TZCLR.bit.OST = 1;
		EDIS;
	}
}


//�������������ʱ�ģУףʹ���������ģ�飲
void	Class_PWMDrv::Drv_BalanceCirtPWM(INT16 i16_BalPWMP,UINT16 BalanceAceFlag)
{	
	INT16 i16_BalPWMPTemp;
	
	i16_BalPWMPTemp = ((INT32)i16_BalPWMP * EPWM1_TIMER_TBPRD) >> 12;
	UpDownLimit16(i16_BalPWMPTemp,700,-700);		//ռ�ձ�������0.6   20110804�޸� �޸�ǰΪ350
	
	if(BalanceAceFlag==1)
	{
		//i16_NcurrentLim = i16_BalPWMPTemp-(i16_BalPWMPTemp>>2);
		i16_NcurrentLim = i16_BalPWMPTemp*4;
		i16_NcurrentLim = i16_BalPWMPTemp>>3;
		
	}
	else
 	{
		i16_NcurrentLim = 0;
	}

	EALLOW;
	EPwm4Regs.CMPA.half.CMPA = 2083 + i16_BalPWMPTemp - i16_NcurrentLim;

	EALLOW;													//ʹ�ܣУף����

	EPwm4Regs.TZCLR.bit.OST = 1;
//	EPwm6Regs.TZCLR.bit.OST = 1;
	EDIS;
}

//ʹ��PWM1�ж�
inline	void	Class_PWMDrv::Drv_PWM1InterruptEnable(void)
{
	EPwm1Regs.ETSEL.bit.INTSEL = ET_CTR_ZERO;     	// Select INT on CNTR=ZERO event
	EPwm1Regs.ETCLR.bit.INT=1;							// ���жϱ�־
	EPwm1Regs.ETSEL.bit.INTEN = 1;                	// Enable PWM ZERO INT
}

//serviceģʽ��PWM����0
inline	void Class_PWMDrv::Drv_ServicePWM0(void)
{
	EPwm5Regs.CMPA.half.CMPA = 1*EPWM1_TIMER_TBPRD/5;		//duty cycle=1/6
}

//serviceģʽ��PWM����1
inline	void Class_PWMDrv::Drv_ServicePWM1(void)
{
	EPwm5Regs.CMPA.half.CMPA=1*EPWM1_TIMER_TBPRD/5;		//duty cycle=1/3
}	


//serviceģʽ��PWM����2
inline	void Class_PWMDrv::Drv_ServicePWM2(void)
{
	EPwm6Regs.CMPA.half.CMPA=1*EPWM1_TIMER_TBPRD/5;	//duty cycle=2/3
}	

//serviceģʽ��PWM����3
inline	void Class_PWMDrv::Drv_ServicePWM3(void)
{
	EPwm6Regs.CMPA.half.CMPA=1*EPWM1_TIMER_TBPRD/5;	//duty cycle=5/6
}


//serviceģʽ��PWM����4
inline	void Class_PWMDrv::Drv_ServicePWM(void)
{
	//������PWM����
	EPwm1Regs.CMPA.half.CMPA = 1*EPWM1_TIMER_TBPRD/10;	//duty cycle=0.1
	EPwm1Regs.CMPB= 1*EPWM1_TIMER_TBPRD/10;				//duty cycle=0.2
	EPwm2Regs.CMPA.half.CMPA = 1*EPWM1_TIMER_TBPRD/10;	//duty cycle=0.3
	EPwm2Regs.CMPB = 1*EPWM1_TIMER_TBPRD/10;			//duty cycle=0.4
	EPwm3Regs.CMPA.half.CMPA = 1*EPWM1_TIMER_TBPRD/10;	//duty cycle=0.5
	EPwm3Regs.CMPB = 1*EPWM1_TIMER_TBPRD/10;				//duty cycle=0.6

	EPwm4Regs.CMPA.half.CMPA = 1*EPWM1_TIMER_TBPRD/10;	//duty cycle=0.7
	EPwm4Regs.CMPB = 1*EPWM1_TIMER_TBPRD/10;			//duty cycle=0.8

	EPwm5Regs.CMPB = EPWM1_TIMER_TBPRD/2;			//duty cycle=0.125
	EPwm6Regs.CMPB = EPWM1_TIMER_TBPRD/2;			//duty cycle=0.375   
	
	switch(m_i16_PWMDupseries)
	{
		case 0:
		{			
			objGPIODrv.Drv_GPIO_PWMBP2();
			Drv_ServicePWM0();						

			objGPIODrv.Drv_GPIO_PWMCP2();
			Drv_ServicePWM2();
			break;
		}

		case 1:
		{
			objGPIODrv.Drv_GPIO_PWMBN2();
			Drv_ServicePWM1();

			objGPIODrv.Drv_GPIO_PWMCN2();
			Drv_ServicePWM3();
			break;
		}
		
		default:
		{
			break;
		}

	}
	
	EALLOW;											//ʹ�ܣУף����
	EPwm1Regs.TZCLR.bit.OST = 1;
	EPwm2Regs.TZCLR.bit.OST = 1;
	EPwm3Regs.TZCLR.bit.OST = 1;
	EPwm4Regs.TZCLR.bit.OST = 1;
	EPwm5Regs.TZCLR.bit.OST = 1;
	EPwm6Regs.TZCLR.bit.OST = 1;
	EDIS;

	m_i16_PWMDupseries++; 						   

	if(m_i16_PWMDupseries > 1) 
	{                          
		m_i16_PWMDupseries = 0;
	}                 
    
}  
 
//============================================================
// End of file.
//============================================================
