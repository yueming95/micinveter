//********************************************************************************************
// File Name	:  	CodeStartBranch.c														**
// Description	: 	Branch for redirecting code execution after boot.						**
// Author		: 	Shu Zhou,	Xian Chengyu												**
// Date			:	Nov.2005																**
//********************************************************************************************


	asm(" .ref _c_int00");
	asm(" .sect codestart ");
	asm(" LB _MainSwitch");
	asm(" .sect normalfuncs");
	asm(" LB _c_int00");
	asm(" .sect flashflag ");                       
	asm(" .WORD 55AAH ");	
	asm(" .text ");



//==================================================================
// End of file.
//==================================================================
