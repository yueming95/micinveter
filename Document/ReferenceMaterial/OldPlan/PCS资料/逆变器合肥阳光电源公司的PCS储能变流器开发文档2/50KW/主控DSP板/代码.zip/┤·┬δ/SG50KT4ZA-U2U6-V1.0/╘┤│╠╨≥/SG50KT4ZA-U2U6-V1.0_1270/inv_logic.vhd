--/*=============================================================================*
-- *         Copyright(c) 2004-2007, Emerson Network Power Co., Ltd.
-- *                          ALL RIGHTS RESERVED
-- *
-- *  PRODUCT  : Paradigm NxE Rack Mount UPS
-- *           
-- *  FILENAME : 
-- *  PURPOSE  : Rack Mount UPS Inv cpld Firmware
-- *  
-- *  HISTORY  :
-- *    DATE            VERSION        AUTHOR            NOTE
-- *    2007-07-07      V1.0          XiongZhiXue        Created.    
-- *
-- *
-- *
-- *----------------------------------------------------------------------------

LIBRARY ieee;
USE ieee.STD_LOGIC_ARITH.all;
USE ieee.std_logic_1164.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


ENTITY inv_logic IS
PORT
(
---------------------------------------------------------------------------
   gpio_0		                : in	std_logic;--
   gpio_1		                : in	std_logic;-- 
	gpio_2_pwm2a				: in	std_logic;-- 
	gpio_3_pwm2b				: in	std_logic;-- 
	gpio_4_pwm3a				: in	std_logic;-- 
	gpio_5_pwm3b				: in	std_logic;-- 
	
    gpio_6_pwm4a                : in	std_logic;--
    gpio_7_pwm4b                : in	std_logic;--
	gpio_8					    : in	std_logic;--
	gpio_9					    : in	std_logic;-- 
	gpio_10					    : in	std_logic;-- 
	gpio_11					    : in	std_logic;-- 
	
	gpio_12_spi_b_simo			: in	std_logic;--
	gpio_13_spi_b_somi			: out	std_logic;--
	gpio_14_spi_b_clk			: in	std_logic;--
	gpio_15_spi_b_ste			: in	std_logic;--
	
	gpio_16		            	: in	std_logic;-- 
	gpio_17		              	: in	std_logic;-- A phase postive OR negative cycle symbol
	gpio_18			            : in	std_logic;-- B phase postive OR negative cycle symbol
	gpio_19			            : in	std_logic;-- C phase postive OR negative cycle symbol
	
	gpio_20_can_b_tx			: in	std_logic;-- 
	gpio_21_can_b_rx			: out	std_logic;-- 
	
	gpio_22_sci_b_txd			: in	std_logic;-- 485
	gpio_23_sci_b_rxd			: out	std_logic;-- 485
	
	gpio_24_cap1				: out	std_logic;-- 
	gpio_25_cap2				: out	std_logic;-- 
	gpio_26_cap3				: out	std_logic;-- 
	gpio_27_cap4				: out	std_logic;-- 
	
	gpio_28_sci_a_rxd			: out	std_logic;-- 232
	gpio_29_sci_a_txd			: in	std_logic;-- 232
	
	gpio_30_can_a_rx			: out	std_logic;-- 
	gpio_31_can_a_tx			: in	std_logic;-- 
	
	gpio_32			        	: inout	std_logic;-- 	I2C SDA
	gpio_33			        	: inout	std_logic;-- 	I2c SCL
	gpio_34					    : in	  std_logic;--
---------------------------------------------------------------------------
	inv_ext_io_0				: out	std_logic;--EEPROM
	inv_ext_io_1				: in	std_logic;--power ok
	inv_ext_io_2				: out	std_logic;--lbs_sync
	inv_ext_io_3				: out	std_logic;--carrier_sync
	inv_ext_io_4				: out	std_logic;--inv_snyc
	
	inv_ext_io_5				: in	std_logic;--bridge short
	inv_ext_io_6				: in	std_logic;--out cross zero hw
	inv_ext_io_7				: in	std_logic;--fuse fault
	inv_ext_io_8				: in	std_logic;--module ready
	inv_ext_io_9				: in	std_logic;--vbus ovp
	
	inv_ext_io_10				: in	std_logic;--fan fault
	inv_ext_io_11				: in	std_logic;--module type
	inv_ext_io_12				: in	std_logic;--module id1   LSB
	inv_ext_io_13				: in	std_logic;--module id2
	inv_ext_io_14				: in	std_logic;--module id3   HSB
	
	inv_ext_io_15				: out	std_logic;--    inv_ext_io_15 <= rec_inv_io_11;  --reset from rec  connect to GND
--------------------------------------------------------------------------
	inv_ext_io_16				: in	std_logic;--IL OC A---??????I_lU  over current protect symbol
	inv_ext_io_17				: in	std_logic;--IL OC B			 I_lV  over current protect symbol
	inv_ext_io_18				: in	std_logic;--IL OC C			 I_lW  over current protect symbol
--------------------------------------------------------------------------
	inv_ext_io_19				: out	std_logic;--ad cs
	
	inv_ext_io_20				: in	std_logic;--lbs_f
	inv_ext_io_21				: in	std_logic;--carrier_f
	inv_ext_io_22				: in	std_logic;--inv_f
	inv_ext_io_23				: out	std_logic;--out_realy
	inv_ext_io_24				: out	std_logic;--range cs1

	inv_ext_io_25				: out	std_logic;--range cs2
	inv_ext_io_26				: in	std_logic;--inv_boot_en
	inv_ext_io_27				: out	std_logic;--
	inv_ext_io_28				: in	std_logic;--bp_feedback
	inv_ext_io_29				: out	std_logic;--module_led1		MODULE_ALARM_LED

	inv_ext_io_30				: out	std_logic;--module_led2		MODULE_OK_LED
	inv_ext_io_31				: out	std_logic;--
---------------------------------------------------------------------------
---------------------------------------------------------------------------
	rec_inv_io_0				: in	std_logic;--rec off
	rec_inv_io_1				: in	std_logic;--rec fault					--WR
	rec_inv_io_2				: in	std_logic;--bat discharge status		--DATA
	rec_inv_io_3				: in	std_logic;--module led status lsb
	rec_inv_io_4				: in	std_logic;--module led status hsb

	rec_inv_io_5				: out	std_logic;--inv status /inv start

	rec_inv_io_6				: out	std_logic;--7line--STE--bat discharge status f
	rec_inv_io_7				: inout	std_logic;--7line--WR--carrier f
	rec_inv_io_8				: inout	std_logic;--7line--DATA--solar project//net inv status
	rec_inv_io_9				: inout	std_logic;--7line--ReceiveOK--

	rec_inv_io_10				: out	std_logic;--carrier f solar!
	rec_inv_io_11				: in	std_logic;-- module id0

	rec_inv_io_12				: out	std_logic;--			--INV ReceiveOK-
	rec_inv_io_13				: in	std_logic;--power fault in
	rec_inv_io_14				: in	std_logic;---- module over temp

---------------------------------------------------------------------------
---------------------------------------------------------------------------
	inv_et0_out				    : out	std_logic;			--Proc?LBS & SYNC
	inv_et0_in				    : in	std_logic;
	inv_et1_out				    : out	std_logic;
	inv_et1_in				    : in	std_logic;
---------------------------------------------------------------------------
	inv_pwm_gh1_u_1				: out	std_logic;
	inv_pwm_gh2_u_2				: out	std_logic;
	inv_pwm_gb1_u_3				: out	std_logic;
	inv_pwm_gb2_u_4				: out	std_logic;

	inv_pwm_gh1_v_1				: out	std_logic;
	inv_pwm_gh2_v_2				: out	std_logic;
	inv_pwm_gb1_v_3				: out	std_logic;
	inv_pwm_gb2_v_4				: out	std_logic;

	inv_pwm_gh1_w_1				: out	std_logic;
	inv_pwm_gh2_w_2				: out	std_logic;
	inv_pwm_gb1_w_3				: out	std_logic;
	inv_pwm_gb2_w_4				: out	std_logic;

---------------------------------------------------------------------------
	inv_led_a				    : out	std_logic;		--INV_DS_A  LEDa
	inv_led_b				    : out	std_logic;		--INV_DS_B	LEDb

	inv_da_clk				    : out	std_logic;
	inv_da_cs				    : out	std_logic;
	inv_da_data				    : out	std_logic;
	
	inv_ad_adj1			    	: out	std_logic;
	inv_ad_adj2			    	: out	std_logic;
 
	inv_sci_txd				    : out	std_logic;
	inv_sci_rxd				    : in	std_logic;
	
	inv_485_txd				    : out	std_logic;
	inv_485_rxd		    		: in	std_logic;
	
	inv_can1_tx			    	: out	std_logic;
	inv_can1_rx			    	: in	std_logic;
	
	inv_can2_tx				    : out	std_logic;
	inv_can2_rx				    : in	std_logic;
	 
	epo_n					    	: in	std_logic;

	cpld_ser_bus_t              : out	std_logic;
	cpld_ser_bus_r              : in	std_logic;  
	
	service_mode_in			    : in	std_logic;
	inv_set                     : in	std_logic;				--always connect 3.3v,value is 1
	inv_indictor                : out   std_logic;
	
	inv_cpld_clk		    : in	std_logic;
	inv_cpld_reset			: in	std_logic
);
END inv_logic;

ARCHITECTURE rtl OF inv_logic IS



--COMPONENT clock_driver
--	PORT (
--		clk				:in std_logic;--input 10MHz clock 
--		reset			:in std_logic;--input reset signal
--		clkout			:out std_logic--output 2MHz diver clock
--	);
--END COMPONENT;
--------------------------------------------------------------------------
-------------------------------------------------------------------
-------------------------------------------------------------------
COMPONENT FSM_operation
	PORT (
		dis_signals_from_DSP		:in std_logic_vector (15 downto 0);-- discrete signals input from UPSC;
		MAC_addr_set				:in std_logic_vector(2 downto 0);-- according to this three pin to deciede local MAC addr
		reset					    :in std_logic;
		clk_in					    :in std_logic;
		dis_signal_from_bus			:in std_logic;--input signal from can bus;
		dis_signal_to_bus			:out std_logic;--output to others IMC board through can bus;
	--	addr_out				:out std_logic_vector(7 downto 0);--buffers to save the address
		dis_signals_to_DSP			:out std_logic_vector (16 downto 0);-- discrete signals output to UPSC;
		BUS_err_flag_out			:out std_logic;--when BUS are fault, set this flag
        debug_led_out       :out std_logic
	);
END COMPONENT;
-------------------------------------------------------------------
-------------------------------------------------------------------



function vote (a, b ,c : std_logic) return std_logic is
begin
	if a = b or a = c then
		return a;
	else
		return b;
	end if;
end vote;



--------------------------------------------------------------------------
signal			ex_io_count		: std_logic_vector(3 downto 0);
shared variable		ex_io_count_v16		: integer range 0 to 15;
																							--gpio9,gpio1,gpio0
signal			ex_out_a_reg		: std_logic_vector(15 downto 0);		--0,0,0
signal			ex_out_b_reg		: std_logic_vector(15 downto 0);		--0,0,1
signal			ex_out_c_reg		: std_logic_vector(15 downto 0);		--0,1,0
signal			ex_out_d_reg		: std_logic_vector(15 downto 0);		--0,1,1
signal			ex_out_e_reg		: std_logic_vector(15 downto 0);		--1,X,X
																						--gpio1,gpio0
signal			ex_in_a			: std_logic_vector(15 downto 0);		--0,0
signal			ex_in_b			: std_logic_vector(15 downto 0);		--0,1
signal			ex_in_c			: std_logic_vector(15 downto 0);		--1,0
signal			ex_in_d			: std_logic_vector(15 downto 0);		--1,1

signal			lbs_cs1			:std_logic;		--  choose the wide of LBS
signal			lbs_cs2			:std_logic;		--  start LBS

signal			bps			    :std_logic;
signal			bps_bak			:std_logic;
signal			bps_out			:std_logic;
signal			invs			:std_logic;
signal			invs_out		:std_logic;
signal			rendebug		:std_logic;

signal			zero_permit_u		:std_logic;
signal			zero_permit_v		:std_logic;
signal			zero_permit_w		:std_logic;

signal           gpio17_fifo   : std_logic_vector(6 downto 0);
signal           gpio18_fifo   : std_logic_vector(6 downto 0);
signal           gpio19_fifo   : std_logic_vector(6 downto 0);



-------------------------------------------------------------
-- ????????--?????--
-------------------------------------------------------------
signal addr					:std_logic_vector(7 downto 0);--the addr got from main bus
signal clk_10M				:std_logic;--10M clock
signal reg_dis_signals_from_DSP  :std_logic_vector(15 downto 0);

signal reg_dis_signals_to_DSP		:std_logic_vector(16 downto 0);--discrete signals got from main bus

signal BUS_err_flag			:std_logic;--the flag for main bus fault

signal         DIS_SIGNAL_FROM_BUS     :std_logic;
signal         DIS_SIGNAL_TO_BUS     :std_logic;
-------------------------------------------------------------
-- ????????--??--
-------------------------------------------------------------
signal         signal_inv_overload_txd     :std_logic;
signal         signal_sys_unlock_txd        :std_logic;
signal         signal_inv_standby_txd       :std_logic;

signal         signal_bp_status_txd         :std_logic;
signal         signal_master_online_txd         :std_logic;
signal         signal_bat_discharging_txd         :std_logic;
-------------------------------------------------------------
signal         signal_1_inv_on_txd         :std_logic;
signal         signal_2_inv_on_txd         :std_logic;
signal         signal_3_inv_on_txd         :std_logic;
signal         signal_4_inv_on_txd         :std_logic;
signal         signal_5_inv_on_txd         :std_logic;
signal         signal_6_inv_on_txd         :std_logic;
-------------------------------------------------------------

signal         bp_scr_drv        :std_logic;




-------------------------------------------------------------
-- ????????--??--
-------------------------------------------------------------
signal         signal_inv_overload_rxd     :std_logic;
signal         signal_sys_unlock_rxd        :std_logic;
signal         signal_inv_standby_rxd       :std_logic;

signal         signal_bp_status_rxd         :std_logic;
signal         signal_master_online_rxd     :std_logic;
signal         signal_bat_discharging_rxd   :std_logic;
-------------------------------------------------------------
signal         signal_1_inv_on_rxd         :std_logic;
signal         signal_2_inv_on_rxd         :std_logic;
signal         signal_3_inv_on_rxd         :std_logic;
signal         signal_4_inv_on_rxd         :std_logic;
signal         signal_5_inv_on_rxd         :std_logic;
signal         signal_6_inv_on_rxd         :std_logic;
-------------------------------------------------------------
signal         system_start_rxd         :std_logic;
signal         system_start_txd         :std_logic;

signal         bp_stsshort_rxd         :std_logic;
signal         bp_overcurrent_rxd         :std_logic;


-------------------------------------------------------------
signal		   debug_led_status		    :std_logic;
signal         imc_test_rxd   :std_logic;
signal         imc_test_txd   :std_logic;
-------------------------------------------------------------





-------------------------------------------------------------
signal         inv_dsp_burned_ok     :std_logic;
signal         inv_cpld_burned_ok     :std_logic;
-------------------------------------------------------------



signal	       led_cnt	 : integer range 0 to 268435455;
signal	       inv_cpld_reset_cnt	 : integer range 0 to 268435455;

signal			 inv_cpld_reset_flag	 :std_logic;

--signal         led_temp_reg : integer range 0 to 7;
-------------------------------------------------------------------	


-------------------------------------------------------------------	
--signal	   epo_verify_cnt	 : integer range 0 to 63;
--signal     epo_status_older	: std_logic;
--signal     epo_status_oldest	: std_logic;
--
--signal	   epo_pwm23_cnt	 : integer range 0 to 15;

-------------------------------------------------------------------	
signal     fault_clear  : std_logic;

-------------------------------------------------------------------	

signal    tmp_inv_indictor  : std_logic;
-------------------------------------------------------------------	
-------------------------------------------------------------------	
signal           pwm_disable_in  :std_logic;-- inv off signal				"0" is off "
signal           pwm_disable_in_older  :std_logic;-- inv off signal
signal           pwm_disable_in_oldest  :std_logic;-- inv off signal
signal			  pwm_disable_vector		:std_logic_vector(7 downto 0);
signal			  pwm_disable_vector_older		:std_logic_vector(7 downto 0);
signal			  pwm_disable_vector_oldest	:std_logic_vector(7 downto 0);

signal				onoffstate1	:std_logic;
signal				onoffstate2	:std_logic;

signal				gpio_34_older	:std_logic;
signal				gpio_34_oldest	:std_logic;

signal	        pwm_disable_in_cnt	 : integer range 0 to 31;
-------------------------------------------------------------------	
--signal           pwm14_ok_signal  :std_logic;-- inv off signal
--signal           pwm23_ok_signal  :std_logic;-- inv off signal

signal           pwm2pwm3_off_epo  :std_logic;-- inv off signal
signal           pwm2pwm3_off_dsp  :std_logic;-- inv off signal

signal           pwm1pwm4_off_epo  :std_logic;-- inv off signal
signal           pwm1pwm4_off_dsp  :std_logic;-- inv off signal
-------------------------------------------------------------------	


-------------------------------------------------------------------	
-------------------??????????????---------------------- 
-------------------------------------------------------------------	
signal     signal_inv_pwm_q1_pos_u              :std_logic;--????????? pos???
signal     signal_inv_pwm_q2_pos_u              :std_logic;
signal     signal_inv_pwm_q3_pos_u              :std_logic;
signal     signal_inv_pwm_q4_pos_u               :std_logic;

signal     signal_inv_pwm_q1_pos_v               :std_logic;
signal     signal_inv_pwm_q2_pos_v              :std_logic;
signal     signal_inv_pwm_q3_pos_v              :std_logic;
signal     signal_inv_pwm_q4_pos_v              :std_logic;

signal     signal_inv_pwm_q1_pos_w              :std_logic;
signal     signal_inv_pwm_q2_pos_w              :std_logic;
signal     signal_inv_pwm_q3_pos_w             :std_logic;
signal     signal_inv_pwm_q4_pos_w             :std_logic;
-------------------------------------------------------------------	
signal     signal_inv_pwm_q1_neg_u              :std_logic;--????????? neg???
signal     signal_inv_pwm_q2_neg_u              :std_logic;
signal     signal_inv_pwm_q3_neg_u              :std_logic;
signal     signal_inv_pwm_q4_neg_u               :std_logic;

signal     signal_inv_pwm_q1_neg_v               :std_logic;
signal     signal_inv_pwm_q2_neg_v              :std_logic;
signal     signal_inv_pwm_q3_neg_v              :std_logic;
signal     signal_inv_pwm_q4_neg_v              :std_logic;

signal     signal_inv_pwm_q1_neg_w              :std_logic;
signal     signal_inv_pwm_q2_neg_w              :std_logic;
signal     signal_inv_pwm_q3_neg_w             :std_logic;
signal     signal_inv_pwm_q4_neg_w             :std_logic;
-------------------------------------------------------------------	
signal     gpio_17_older           :std_logic;--gpio_17????
signal     gpio_17_oldest            :std_logic; 

signal     gpio_18_older           :std_logic;
signal     gpio_18_oldest            :std_logic; 

signal     gpio_19_older           :std_logic;
signal     gpio_19_oldest            :std_logic; 
------------------------------------------------------------------------
signal         pos_cycle_disable_pwm_u         :std_logic;--???????????
signal         neg_cycle_disable_pwm_u         :std_logic;

signal         pos_cycle_disable_pwm_v         :std_logic;
signal         neg_cycle_disable_pwm_v         :std_logic;

signal         pos_cycle_disable_pwm_w         :std_logic;
signal         neg_cycle_disable_pwm_w         :std_logic;
------------------------------------------------------------------------
signal         pwm_woking_status_u         :std_logic; --gpio_17????
signal         pwm_woking_status_v         :std_logic;
signal         pwm_woking_status_w         :std_logic;
------------------------------------------------------------------------
signal         had_been_u       :std_logic; --???????
signal         had_been_v       :std_logic;
signal         had_been_w       :std_logic;
-------------------------------------------------------------------	
---------END----??????????????---------END------------- 
-------------------------------------------------------------------	



--------------------------------------------------------
--??????
--------------------------------------------------------
--A?
signal       force_fun_en_u2      :std_logic;			--force close pulse U2
signal       force_fun_status_u2      :std_logic;

signal       force_fun_en_u3      :std_logic;
signal       force_fun_status_u3      :std_logic;
signal       pulse_limit_status_u      :std_logic;		-- The status symbol which pulse u need to limited 

--------------------------------------------------------
--B?
signal       force_fun_en_v2      :std_logic;
signal       force_fun_status_v2      :std_logic;

signal       force_fun_en_v3      :std_logic;
signal       force_fun_status_v3      :std_logic;
signal       pulse_limit_status_v      :std_logic;


-------------------------------------------------------------------	
--C?
signal       force_fun_en_w2      :std_logic;
signal       force_fun_status_w2      :std_logic;

signal       force_fun_en_w3      :std_logic;
signal       force_fun_status_w3      :std_logic;
signal       pulse_limit_status_w      :std_logic;


-------------------------------------------------------------------	
-------------------------------------------------------------------	






-------------------------------------------------------------------	
---------------    ?????? ?????  -------------------------
-------------------------------------------------------------------	
signal     pwm_ok_14u_ocp              :std_logic;	-- Ilu over current symbol. "0" represent over current	
signal     pwm_ok_14v_ocp              :std_logic;
signal     pwm_ok_14w_ocp              :std_logic;

--signal     pwm_ok_23u              :std_logic;
--signal     pwm_ok_23v              :std_logic;
--signal     pwm_ok_23w              :std_logic;
-------------------------------------------------------------------	
signal     ocp_u_older     :std_logic;
signal     ocp_u_oldest     :std_logic;
--
signal     ocp_v_older     :std_logic;
signal     ocp_v_oldest     :std_logic;
--
signal     ocp_w_older     :std_logic;
signal     ocp_w_oldest     :std_logic;
-------------------------------------------------------------------	
signal ocpu_sample_bits_fifo20			:std_logic_vector(20 downto 0);--
signal ocpv_sample_bits_fifo20			:std_logic_vector(20 downto 0);--
signal ocpw_sample_bits_fifo20			:std_logic_vector(20 downto 0);--

--signal	   ocpu_verify_cnt	 : integer range 0 to 31;
--signal	   ocpv_verify_cnt	 : integer range 0 to 31;
--signal	   ocpw_verify_cnt	 : integer range 0 to 31;
--signal	   ocpu_14cnt	 : integer range 0 to 15;
--signal	   ocpv_14cnt	 : integer range 0 to 15;
--signal	   ocpw_14cnt	 : integer range 0 to 15;
	
signal	   ocpu_23cnt	 : integer range 0 to 31;
signal	   ocpv_23cnt	 : integer range 0 to 31;
signal	   ocpw_23cnt	 : integer range 0 to 31;

signal	   hold_u_cnt	 : integer range 0 to 127;
signal	   hold_v_cnt	 : integer range 0 to 127;
signal	   hold_w_cnt	 : integer range 0 to 127;

signal    gpio_2_pwm2a_older     :std_logic;
signal    gpio_2_pwm2a_oldest     :std_logic;

signal    gpio_4_pwm3a_older     :std_logic;
signal    gpio_4_pwm3a_oldest     :std_logic;

signal    gpio_6_pwm4a_older     :std_logic;
signal    gpio_6_pwm4a_oldest     :std_logic;


signal    pwm_ok_14u_ocp_flag     :std_logic;
signal    pwm_ok_14v_ocp_flag     :std_logic;
signal    pwm_ok_14w_ocp_flag     :std_logic;

--------------------------------------------------------
--??????
--------------------------------------------------------
------------------------------------------------------------------
signal			mex_io_count		: std_logic_vector(3 downto 0);
shared variable		mex_io_count_v16		: integer range 0 to 15;

signal			mex_io_count_2		: std_logic_vector(3 downto 0);
shared variable		mex_io_count_v16_2		: integer range 0 to 15;


signal			data_to_dsp		: std_logic_vector(15 downto 0);
signal			data_from_dsp		: std_logic_vector(15 downto 0);
signal			data_to_rec_cpld		: std_logic_vector(15 downto 0);
signal			data_from_rec_cpld		: std_logic_vector(15 downto 0);
signal	        singal_ste 	    :std_logic;
signal			singal_ste_older 	    :std_logic;
signal			singal_ste_oldest 	    :std_logic;
signal			ste_cnt	 : integer range 0 to 1023;
signal 			transfer_onging 	    :std_logic;
signal 			transfer_onging_2 	    :std_logic;

signal       aa      :std_logic;
signal       bb      :std_logic;
signal       sig_rec_inv_io_9      :std_logic;

signal delay_cnt1 	: integer range 0 to 7;
signal delay_cnt2 	: integer range 0 to 7;
------------------------------------------------------------------
------------------------------------------------------------------



BEGIN



-------------------------------------------------------------------	
--???????PORT MAP 
	-- Instance port mappings..
	FSM_MAIN: FSM_operation
		PORT MAP(
				dis_signals_from_DSP	=>reg_dis_signals_from_DSP,
		      MAC_addr_set			=>"001",
				reset					=>inv_cpld_reset,
				clk_in					=>clk_10M,--clk_10M,
				dis_signal_from_bus		=>cpld_ser_bus_r,
				dis_signal_to_bus		=>cpld_ser_bus_t,
		--		addr_out				=>addr,
				dis_signals_to_DSP	    =>reg_dis_signals_to_DSP,
				BUS_err_flag_out		=>inv_ext_io_15,
            debug_led_out		    =>inv_ext_io_27
		);

-------------------------------------------------------------------	




-------------------------------------------------------------------	
--INV???STE?????? 19.49KHz, 20us+ ????? 
-------------------------------------------------------------------	
--Process???10M?????
--????????1us??? 
-------------------------------------------------------------------	






-------------------------------------------------------------------	
--Process???SPI???? 
--???spi?clk??????spi?clk?????
-------------------------------------------------------------------
process(inv_cpld_reset,gpio_14_spi_b_clk,gpio_15_spi_b_ste)-- Proc?IO Extend
begin
	ex_io_count_v16 := conv_integer(ex_io_count);
--	ex_io_count_v8 := conv_integer(ex_io_count(2 downto 0));
		
	if inv_cpld_reset_flag = '1' then
		ex_io_count <= "1111";
		ex_out_a_reg <= "0000000000000000";
		ex_out_b_reg <= "0000000000000000";
		ex_out_c_reg <= "0000000000000000";
		ex_out_d_reg <= "0000000000000000";		
	else--inv_cpld_reset = '1' 			
		if gpio_15_spi_b_ste = '1' then
--			ex_io_count <= "0000";
			ex_io_count <= "1111";
			--inv_led_b <= '0';				--led_a close  renqixing XiaoGai 20110629
		else
--			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '1' then		-- output extend +1
			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '0' then		-- output extend +1
				ex_io_count <= ex_io_count - 1;
			end if;			
           -- inv_led_b <= '1';			--led_b close renqixing XiaoGai 20110629
--			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '0' then		-- output extend
			if gpio_14_spi_b_clk'event and gpio_14_spi_b_clk = '1' then		-- output extend
				if gpio_0 = '0' and gpio_1 = '0' and gpio_9 = '0' then 
					ex_out_a_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;
				elsif  gpio_0 = '1' and gpio_1 = '0' and gpio_9 = '0' then 
					ex_out_b_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				elsif  gpio_0 = '0' and gpio_1 = '1' and gpio_9 = '0' then 
					ex_out_c_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				elsif  gpio_0 = '1' and gpio_1 = '1' and gpio_9 = '0' then 
					ex_out_d_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				elsif   gpio_9 = '1' then 
					ex_out_e_reg(ex_io_count_v16) <= gpio_12_spi_b_simo;	
				end if;	
			end if;
	
			if gpio_0 = '0' and gpio_1 = '0' then 					-- input extend
				gpio_13_spi_b_somi <= ex_in_a(ex_io_count_v16);
			elsif  gpio_0 = '1' and gpio_1 = '0' then 
				gpio_13_spi_b_somi <= ex_in_b(ex_io_count_v16);
			elsif  gpio_0 = '0' and gpio_1 = '1' then 
				gpio_13_spi_b_somi <= ex_in_c(ex_io_count_v16);
			elsif  gpio_0 = '1' and gpio_1 = '1' then 
				gpio_13_spi_b_somi <= ex_in_d(ex_io_count_v16);
			end if;	
		end if;
	end if;--inv_cpld_reset 
end process;
-------------------------------------------------------------------






-------------------------------------------------------------------	
--Process???CPLD?????????
--???/
-------------------------------------------------------------------	
process(inv_cpld_reset,inv_cpld_clk)-- Proc?Input
begin
if inv_cpld_reset_flag = '1' then

else
   	if inv_cpld_clk'event and inv_cpld_clk = '0' then
      if inv_set = '1'  then
        inv_cpld_burned_ok <= '1';
      else
        inv_cpld_burned_ok <= '0';
      end if;
    end if;
end if;
end process;
-------------------------------------------------------------------	





-------------------------------------------------------------------	
--Process???SPI?????? 
--???/
-------------------------------------------------------------------
process(epo_n,inv_cpld_reset,gpio_9,gpio_15_spi_b_ste)--Proc?Output
begin
----------For Bypass Module ----------
--
--    vote--- ex_out_a_reg(0):  bp scr drv
--    vote---      ...    (1):  bp relay drv
--
------------- out relay drive--------??? it is not need??
--	if epo_n = '0' then
--	    inv_ext_io_23 <= '0';  
--	else
--		inv_ext_io_23 <= vote(ex_out_a_reg(1),ex_out_b_reg(1),ex_out_c_reg(1));
--	end if;
------------bp scr drive---------------
--	if epo_n = '0' then
--	inv_ext_io_23 <= '0';  
--	else
  bp_scr_drv <=  vote(ex_out_a_reg(0),ex_out_b_reg(0),ex_out_c_reg(0));--    end if;


--inv_ext_io_31 <=  vote(ex_out_a_reg(0),ex_out_b_reg(0),ex_out_c_reg(0));--    end if;
 
	if inv_cpld_reset_flag = '1' then
		   inv_ext_io_23 <= 	'0'; 		-- OUTRELAY
			----------module status led display---
			inv_ext_io_29 <=  '1'; --module status led display---			
			inv_ext_io_30 <=  '1'; --module status led display--- 
			-------------------------------------	
	else
			inv_ext_io_23 <= vote(ex_out_a_reg(1),ex_out_b_reg(1),ex_out_c_reg(1)); -- OUTRELAY 20110904XIAOGAI

			----------module status led display---
			inv_ext_io_29 <= ex_out_a_reg(6);			--MODULE_LED1
			inv_ext_io_30 <= ex_out_a_reg(5);			--MODULE_LED2
			-------------------------------------	
	end if;




-----------module capacity select------
--	inv_ext_io_24 <=  ex_out_a_reg(7);  --cs1
--	inv_ext_io_25 <=  ex_out_a_reg(8);  --cs2
--    inv_ext_io_24 <= '1';
--    inv_ext_io_25 <=  '1'; 
--------------- dsp adc adjustment-----
	inv_ad_adj1 <= ex_out_b_reg(6);			--AD_BASE_SELECT  00:original signal, 01:1V,10:2V
	inv_ad_adj2 <= ex_out_b_reg(7);
	
	
---------------------------------------------	
	if inv_cpld_reset_flag = '1' then
	
	    pwm_disable_in  <= '0';
		 pwm_disable_vector <= "00000000";
	--    inv_ext_io_27<= '0';

	else   
		pwm_disable_in  <= ex_out_b_reg(8); --pwm2,pwm3 disable from dsp   invoff to cpld
		pwm_disable_vector <= ex_out_b_reg(15 downto 8);
	--    inv_ext_io_27<= ex_out_b_reg(8);
	end if;
---------------------------------------------	



---------------debug inv_led-----------			debug use 
--	if inv_cpld_reset = '0' then
--		inv_led_a <= '0';
--    	inv_led_b <= '0';
--	else
----		inv_led_a <= ex_out_c_reg(12);
--   --     inv_led_b <= ex_out_c_reg(13);
--	end if;
--		inv_led_a <= ex_out_c_reg(14);
--       inv_led_b <= ex_out_c_reg(15);
--	end if;
---------------lbs cs--------------------
	lbs_cs2 <= ex_out_d_reg(6);					-- lbs_cs2
	lbs_cs1 <= ex_out_d_reg(7);					-- lbs_cs1
----------serial bus signal receive----
--    system_start_txd  <= ex_out_d_reg(10);
--


----------serial bus signal receive----
    signal_1_inv_on_txd  <= ex_out_c_reg(6);	
    signal_2_inv_on_txd  <= ex_out_c_reg(7);	
    signal_3_inv_on_txd  <= ex_out_c_reg(8);	
    signal_4_inv_on_txd  <= ex_out_c_reg(9);	
    signal_5_inv_on_txd  <= ex_out_c_reg(10);	
--    signal_2_inv_on_txd <= service_mode_in;
	signal_inv_overload_txd  <= ex_out_d_reg(0);
	signal_sys_unlock_txd   <= ex_out_d_reg(1);  
	signal_inv_standby_txd   <= ex_out_d_reg(2);     
	signal_bp_status_txd    <= ex_out_d_reg(3); 
	signal_master_online_txd   <= ex_out_d_reg(5);   
--	signal_bat_discharging_txd <= rec_inv_io_2;	--20111123xiaogai
	
	-----------inv state to rec----------

-----------inv state to rec----------
    rec_inv_io_5 <= ex_out_d_reg(4);  -- INV_STATE  to rec		
 --   rec_inv_io_8 <= ex_out_d_reg(10);  -- to rec  solar project// net inv status

-----------dsp ????????---------
	if ex_out_d_reg(8) = '1' then    --  DSP_FIRMWARE_OK  
	inv_dsp_burned_ok <= '1';     
	else
	inv_dsp_burned_ok <= '0';
	end if;
--------------- inv_da----------------
--	if inv_cpld_reset = '0' then
--	else
--		if  gpio_9 = '1' and gpio_15_spi_b_ste = '0' then
--			inv_da_cs <= '0';		
--			inv_da_clk <= gpio_14_spi_b_clk;
--			inv_da_data <= gpio_12_spi_b_simo;
--		else
--			inv_da_cs <= '1';		
--			inv_da_clk <= '0';
--			inv_da_data <= '0';
--		end if;
--	end if;


--*******************************************************--
----------------send to imc bus---------------------------
----------------------------------------------------------
--2008-08-22

    reg_dis_signals_from_DSP(15) <= signal_bat_discharging_txd;
--    reg_dis_signals_from_DSP(14) <= system_start_txd;
    reg_dis_signals_from_DSP(14) <= signal_1_inv_on_txd;	--	module 1 online symbol
--    reg_dis_signals_from_DSP(14) <= imc_test_txd;

    reg_dis_signals_from_DSP(13) <= signal_5_inv_on_txd; --	module 5 online symbol
    reg_dis_signals_from_DSP(12) <= signal_4_inv_on_txd; --	module 4 online symbol
    reg_dis_signals_from_DSP(11) <= signal_3_inv_on_txd; --	module 3 online symbol

--    reg_dis_signals_from_DSP(10) <= '0';--bp_module_online_internal??????
    reg_dis_signals_from_DSP(10) <= '0';--bLeader_Rack_Online 

    reg_dis_signals_from_DSP(9) <=  bp_scr_drv;		
    reg_dis_signals_from_DSP(8) <= ex_out_d_reg(9);		--	Model_Online 
    reg_dis_signals_from_DSP(7) <= signal_2_inv_on_txd; 	--	module 2 online symbol
--  reg_dis_signals_from_DSP(6) <= signal_1_inv_on_txd; 

    reg_dis_signals_from_DSP(6) <= '0'; --bp overcurrent


--    reg_dis_signals_from_DSP(5) <= signal_bat_discharging_txd;
--2008-08-22
    reg_dis_signals_from_DSP(5) <= '0';--???SPIIN4 BIT4???BpSTSShortFault????

    reg_dis_signals_from_DSP(4) <= signal_master_online_txd;	--	master_online symbol
    reg_dis_signals_from_DSP(3) <= signal_bp_status_txd;			-- inv or bp status
    reg_dis_signals_from_DSP(2) <= signal_inv_standby_txd;		-- inv get ready ok?
    reg_dis_signals_from_DSP(1) <= signal_sys_unlock_txd;
  --  reg_dis_signals_from_DSP(1) <= imc_test_txd;

    reg_dis_signals_from_DSP(0) <= signal_inv_overload_txd;		--	inv_overload symbol
--*******************************************************--
----------------send to imc bus---------------------------
----------------------------------------------------------



--*******************************************************--
----------------receive from imc bus---------------------------
----------------------------------------------------------
    signal_inv_overload_rxd <= not reg_dis_signals_to_DSP(0);
    signal_sys_unlock_rxd <=  not reg_dis_signals_to_DSP(1);
--    imc_test_rxd <=  not reg_dis_signals_to_DSP(1);

    signal_inv_standby_rxd <=  not reg_dis_signals_to_DSP(2);
    signal_bp_status_rxd <=  not reg_dis_signals_to_DSP(3);
    signal_master_online_rxd <=  not reg_dis_signals_to_DSP(4);
--    signal_bat_discharging_rxd <=  not reg_dis_signals_to_DSP(5);
--2008-08-22
    bp_stsshort_rxd <=  not reg_dis_signals_to_DSP(5);--BpSTSShortFault
--???SPIIN4 BIT4???BpSTSShortFault????

--  signal_1_inv_on_rxd  <=   not reg_dis_signals_to_DSP(6);
    bp_overcurrent_rxd  <=   not reg_dis_signals_to_DSP(6);
--2008-08-29

--    signal_2_inv_on_rxd  <=   not reg_dis_signals_to_DSP(7);
--    imc_test_rxd  <=   not reg_dis_signals_to_DSP(8);
 --   ex_in_d(5) <= not  reg_dis_signals_to_DSP(9);-- bp scr drv receive		20111123xiaogai

    ex_in_a(8) <= not  reg_dis_signals_to_DSP(10);-- bLeader_Rack_Online

--ex_in_a(8) <= '1'; --?? ??????


--   signal_3_inv_on_rxd  <=   not reg_dis_signals_to_DSP(11);
--   signal_4_inv_on_rxd  <=   not reg_dis_signals_to_DSP(12);
--    signal_5_inv_on_rxd  <=   not reg_dis_signals_to_DSP(13);
--    system_start_rxd    <=   not reg_dis_signals_to_DSP(14);
--    signal_1_inv_on_rxd    <=   not reg_dis_signals_to_DSP(14);
--2008-08-29
--imc_test_rxd   <=   not reg_dis_signals_to_DSP(14);

    signal_bat_discharging_rxd   <=  not reg_dis_signals_to_DSP(15);
--2008-08-22
 --  ex_in_d(6)   <=  not reg_dis_signals_to_DSP(16);						20111123xiaogai


inv_ext_io_31 <= (not reg_dis_signals_to_DSP(5)) or (not reg_dis_signals_to_DSP(0));

--*******************************************************--
----------------receive from imc bus---------------------------
----------------------------------------------------------

     imc_test_txd <=  service_mode_in;

   tmp_inv_indictor<=   not reg_dis_signals_to_DSP(16);---inv_indictor CHANGE TO tmp_inv_indictor

--   inv_led_b <= signal_inv_standby_rxd;


end process;
-------------------------------------------------------------------








-------------------------------------------------------------------	
--Process??????????
--???/   invoff deal 
-------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- invoff deal 
begin
if inv_cpld_reset_flag = '1' then 
	    --------------------------------------
		gpio_34_older <= '0';
		gpio_34_oldest <= '0';
		
		onoffstate1 <= '0';
		onoffstate2 <= '0';		
		 
      pwm_disable_in_cnt <= 31;	
		pwm_disable_in_older <= '0';			
		pwm_disable_in_oldest <= '0';
		
		pwm_disable_vector_older <= "00000000";
		pwm_disable_vector_oldest <= "00000000";

		pwm1pwm4_off_dsp  <= '0'; --???????  ??????
--		pwm23_ok_signal <= '0';
        pwm2pwm3_off_dsp  <= '0';        --??????? ??????
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
----------------------------------------------------------------	
			gpio_34_older <=  gpio_34;
			gpio_34_oldest <= gpio_34_older;

		if pwm_disable_vector = "11100111" or pwm_disable_vector = "00000000" then
				
--         pwm_disable_in_older  <= service_mode_in;
           pwm_disable_vector_older  <=  pwm_disable_vector;
      --   pwm_disable_in_older  <= rec_inv_io_3; --for simu
           pwm_disable_vector_oldest  <= pwm_disable_vector_older;					-- signal value is gived in the end of process .
       -- inv_ext_io_24 <= pwm_disable_in;
		end if;	

		if gpio_34_older = '1' and gpio_34_oldest = '0' then
			onoffstate1 <= '1';
		end if;
		if gpio_34_older = '0' and gpio_34_oldest = '1' then
			onoffstate1 <= '0';
		end if;
		
		if  pwm_disable_vector_older = "11100111" and pwm_disable_vector_oldest = "00000000" then
			onoffstate2 <= '1';
		end if;	
		if  pwm_disable_vector_older = "00000000" and pwm_disable_vector_oldest = "11100111" then
			onoffstate2 <= '0';
		end if;			
		
----------------------------------------------------------------		
--	        inv_indictor <= tmp_inv_indictor;
----------------------------------------------------------------		
--        inv_indictor <= pwm_disable_in_oldest;
----------------------------------------------------------------		
--??? ????
	 if  onoffstate1 = '1' and onoffstate2 = '1' then		-- ON   normal run   
	
			pwm1pwm4_off_dsp  <= '1';  --?? ???
 --      pwm23_ok_signal <= '1';
         pwm2pwm3_off_dsp  <= '1';  --?? ???
	
    end if;
----------------------------------------------------------------		
--??? ??1,4??? 
	 if  onoffstate1 = '0' and onoffstate2 = '0' then		-- OFF  off pulse 
        	  
			  pwm1pwm4_off_dsp  <= '0';   --?? ?????
           pwm_disable_in_cnt <= 1;
			
    end if;
----------------------------------------------------------------		
    if pwm_disable_in_cnt = 30 and pwm_disable_vector_oldest = "00000000" then 
       --    pwm23_ok_signal <= '0';
            pwm2pwm3_off_dsp  <= '0';   --?? ?????
    end if;

     if pwm_disable_in_cnt > 0 and  pwm_disable_in_cnt < 31 then
           pwm_disable_in_cnt <= pwm_disable_in_cnt + 1;
     end if;
----------------------------------------------------------------		
  end if;-- // end of clk
end if;-- // end of reset
end process;
----------------------------------------------------------------		
----------------------------------------------------------------	







-------------------------------------------------------------------	
--Process???EPO????
--???/
-------------------------------------------------------------------
----------------------------------------------------------------		












---------------------------------------------------------------------------	
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--                   A???????
-- ??????->??????->????14?->????23?->??????
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

-------------------------------------------------------------------------------	
-------------------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ A???
-------------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?			Phase A postive cycle
begin
-----------------phase a--------------------------------------------------
if inv_cpld_reset_flag = '1'   then 
			signal_inv_pwm_q1_pos_u <= '0';
			signal_inv_pwm_q2_pos_u <= '0'; 
			signal_inv_pwm_q3_pos_u <= '0'; 
			signal_inv_pwm_q4_pos_u <= '0';  	
						
			gpio_17_older <= '0';
			gpio_17_oldest <= '0';

            pos_cycle_disable_pwm_u <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
---------------------------------------------------------------------------
		if	zero_permit_u = '1' then
			 gpio_17_older <= gpio_17;					--
		end if;
			 gpio_17_oldest <= gpio_17_older;

		--	 inv_ext_io_27 <= gpio_17;
---------------------------------------------------------------------------
--************************************************************************
--************************************************************************
---------------------------------------------------------------------------
        if  gpio_17_oldest = '1' and gpio_17_older = '0' then -- rising edge
------------------------------------------------------------------------
--????????,??????
-- from + cycle to - cycle
--              neg_to_pos_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '0';--????????
-------------------------------------------------------------------------
-- ??Q2,??Q4
		     signal_inv_pwm_q4_pos_u <= '0'; 
--------------------------------------------------------------------------
-- 3?1?
		     if  gpio_3_pwm2b ='0'  then					-- ???Have a question???		
		          --q3=1,pwm=0
		        pos_cycle_disable_pwm_u<= '1';   --????
		     else --q3=0,pwm=1
		        pos_cycle_disable_pwm_u<= '0';   -- q3,q1=0 ???????,??q3????
		     end if;
         end if;
------------------------------------------------------------------------
 --        if q3 = '1',pwm=0  and  ???????
         if gpio_3_pwm2b = '0'  and pos_cycle_disable_pwm_u = '0' then		-- alter is needed? alter for "if gpio_3_pwm2b = '0'  and pwm_woking_status_u  = '0'"
		        pos_cycle_disable_pwm_u<= '1';   --????
--          ????????,????
         end if;
----------------------------------------------
         if pos_cycle_disable_pwm_u = '0' then     
                   -- ?? 0
		       signal_inv_pwm_q2_pos_u <= '0'; 
               signal_inv_pwm_q1_pos_u <= '0'; 
				--	signal_inv_pwm_q3_pos_u <= '0'; 			--20111020gai
					signal_inv_pwm_q3_pos_u <= '1'; 
	
         else   -- ?? 1
		       signal_inv_pwm_q2_pos_u <= '1'; 
               signal_inv_pwm_q1_pos_u <= not gpio_2_pwm2a; 
               signal_inv_pwm_q3_pos_u <= not gpio_3_pwm2b; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
---------------------------------------------------------------------------
--************************************************************************
-------------------------------------------------------------------	
--Process???END OF  ???   ???        ??????????
--???/ A???
-------------------------------------------------------------------



-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ A???
-------------------------------------------------------------------
--************************************************************************
---------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?				Phase A negative cycle
begin
-----------------phase a--------------------------
if inv_cpld_reset_flag = '1'   then 

			signal_inv_pwm_q1_neg_u <= '0';
			signal_inv_pwm_q2_neg_u <= '0'; 
			signal_inv_pwm_q3_neg_u <= '0'; 
			signal_inv_pwm_q4_neg_u <= '0';  
         neg_cycle_disable_pwm_u <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
       if  gpio_17_oldest = '0' and gpio_17_older = '1' then -- falling edge
--????????,??????
-- from + cycle to - cycle
--             pos_to_neg_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '1';--????????
-------------------------------------------------------------------------
-- ??Q3,??Q1
             signal_inv_pwm_q1_neg_u <= '0'; 
--------------------------------------------------------------------------
-- 2?4?

		     if  gpio_3_pwm2b ='0'  then
		          --q2=1
		        neg_cycle_disable_pwm_u <= '1';   --????
		     else --q2=0
		        neg_cycle_disable_pwm_u <= '0';   -- q2,q4=0 ???????,??q2????
		     end if;
       end if;

------------------------------------------------------------------------
 --        if q2 = '1'  and  ???????
         if gpio_3_pwm2b = '0'  and neg_cycle_disable_pwm_u = '0' then
		        neg_cycle_disable_pwm_u <= '1';   --????
--          ????????,????
         end if;
----------------------------------------------------------------------------
         if neg_cycle_disable_pwm_u = '0' then     
--                   -- ?? 
               signal_inv_pwm_q3_neg_u <= '0'; 

				--signal_inv_pwm_q2_neg_u <= '0'; 		--20111020gai
					signal_inv_pwm_q2_neg_u <= '1';
               signal_inv_pwm_q4_neg_u <= '0'; 

         else   -- ?? 
               signal_inv_pwm_q3_neg_u <= '1'; 

               signal_inv_pwm_q2_neg_u <= not gpio_3_pwm2b; 
               signal_inv_pwm_q4_neg_u <= not gpio_2_pwm2a; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
-------------------------------------------------------------------	
--Process??: END OF ???   ???        ??????????
--???/ A???
-------------------------------------------------------------------







--------------------------------------------------------------------         
---*******************A? ??????*****************************
---------------------------------------------------------------------
-----------------------------------------------------------------------------	
--Process???A?1,4?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'  then 

			inv_pwm_gh1_u_1  <= '0';  
			inv_pwm_gb2_u_4  <= '0';  
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
                        
-- ??????
--          if  pwm_ok_14u_ocp = '0'  or pwm1pwm4_off_epo = '0'  or pwm1pwm4_off_dsp = '0'  then
          if  pwm_ok_14u_ocp = '0'  or  pwm1pwm4_off_dsp = '0'  then

      			inv_pwm_gh1_u_1  <= '0';
		     	inv_pwm_gb2_u_4  <= '0';
          else
	           if pwm_woking_status_u = '0' then
				inv_pwm_gh1_u_1  <= signal_inv_pwm_q1_pos_u;
				rendebug <= signal_inv_pwm_q1_pos_u;
				inv_pwm_gb2_u_4  <=  '0';  	
	          else
				inv_pwm_gh1_u_1  <=  '0';
				rendebug <= signal_inv_pwm_q4_neg_u;
				inv_pwm_gb2_u_4  <= signal_inv_pwm_q4_neg_u;
		      end if;
          end if;

	
	end if;  --clk
end if; -- reset
end process;
---------------------------------------------------------------------
-----------------------------------------------------------------------------	

-----------------------------------------------------------------------------	
-----------------------------------------------------------------------------	
--Process???A?2,3?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'   then 
			inv_pwm_gh2_u_2 <= '0'; 
			inv_pwm_gb1_u_3 <= '0'; 
		
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
-----------------------------------------------------------------------------
-- ??????
-- ??2???

--           if  pwm2pwm3_off_dsp = '0' or pwm2pwm3_off_epo = '0'  then
           if  pwm2pwm3_off_dsp = '0'  then

                -----------------------------------------------
	 			inv_pwm_gh2_u_2 <=  '0';
           else
                -----------------------------------------------
                if force_fun_en_u2 = '1'  then
                     if force_fun_status_u2 = '1' then
	        			   inv_pwm_gh2_u_2 <=  '1';
                     else 
	        			   inv_pwm_gh2_u_2 <=  '0';
                     end if;
                else
               -----------------------------------------------
			         if pwm_woking_status_u = '0' then
		 				inv_pwm_gh2_u_2 <= signal_inv_pwm_q2_pos_u; 
		             else
						inv_pwm_gh2_u_2 <= signal_inv_pwm_q2_neg_u; 
				     end if;
                end if;
               ------------------------------------------------
		   end if;
----------------------------------------------------
----------------------------------------------------
-- ??????
-- ??3???
--           if  pwm2pwm3_off_dsp = '0'  or pwm2pwm3_off_epo = '0' then
           if  pwm2pwm3_off_dsp = '0'   then

                -----------------------------------------------
		 			inv_pwm_gb1_u_3 <=  '0';
    	   else
                -----------------------------------------------
                if force_fun_en_u3 = '1'  then
                       if force_fun_status_u3 = '1' then
	        			   inv_pwm_gb1_u_3 <=  '1';
                       else 
	        			   inv_pwm_gb1_u_3 <=  '0';
                       end if;
                else
               -----------------------------------------------
			           if pwm_woking_status_u = '0' then
						inv_pwm_gb1_u_3 <= signal_inv_pwm_q3_pos_u; 

		               else
						inv_pwm_gb1_u_3 <= signal_inv_pwm_q3_neg_u; 
				       end if;
				end if;
            end if;
------------------------------------------------
	end if;  --clk
end if; -- reset
end process;
--------------------------------------------------------------------         
---************END********A? ??????********END***************
---------------------------------------------------------------------



---------------------------------------------------------------
--Process???A???????
--???/
-------------------------------------------------------------------	
process(inv_cpld_reset,inv_cpld_clk)
begin
-----------------phase a----------------------------------------
if  inv_cpld_reset_flag = '1' then
 --   pwm_ok_23u <= '1';
    pwm_ok_14u_ocp <= '1';

	
--    ocpu_verify_cnt <= 31;	

	ocp_u_older <= '1';
	ocp_u_oldest <= '1';
	
	ocpu_23cnt <= 20;
--    inv_indictor <= '0';

    hold_u_cnt <= 82;	
---------------------------------------
    force_fun_en_u2 <= '0'; 
    force_fun_status_u2 <= '0'; 
	force_fun_en_u3 <= '0'; 
	force_fun_status_u3  <= '0';   
	
	pulse_limit_status_u  <= '0';  
---------------------------------------
    ocpu_sample_bits_fifo20 <= "111111111111111111111";
---------------------------------------
    gpio_2_pwm2a_older <= '0';	
    gpio_2_pwm2a_oldest <= '0';	

    pwm_ok_14u_ocp_flag <= '0';   
---------------------------------------

    had_been_u <= '0'; 


else
   if inv_cpld_clk'event and inv_cpld_clk = '1' then 
	-------------------------------------------------------------------	

     gpio_2_pwm2a_older <= gpio_2_pwm2a;	
     gpio_2_pwm2a_oldest <= gpio_2_pwm2a_older;	

     --    ocp_u_older <= service_mode_in;
        ocp_u_older <= inv_ext_io_16;					-- I_lU  over current protect 
        ocp_u_oldest <= ocp_u_older;

    -- inv_ext_io_17 <= inv_ext_io_12;

	 --ocpu_sample_bits_fifo20(0) <= inv_ext_io_16;
    --ocpu_sample_bits_fifo20(1) <= ocpu_sample_bits_fifo20(0);
    --ocpu_sample_bits_fifo20(2) <= ocpu_sample_bits_fifo20(1);
    --ocpu_sample_bits_fifo20(3) <= ocpu_sample_bits_fifo20(2);
    --ocpu_sample_bits_fifo20(4) <= ocpu_sample_bits_fifo20(3);
    --ocpu_sample_bits_fifo20(5) <= ocpu_sample_bits_fifo20(4);
    --ocpu_sample_bits_fifo20(6) <= ocpu_sample_bits_fifo20(5);
    --ocpu_sample_bits_fifo20(7) <= ocpu_sample_bits_fifo20(6);
    --ocpu_sample_bits_fifo20(8) <= ocpu_sample_bits_fifo20(7);
    --ocpu_sample_bits_fifo20(9) <= ocpu_sample_bits_fifo20(8);
    --ocpu_sample_bits_fifo20(10) <= ocpu_sample_bits_fifo20(9);
    --ocpu_sample_bits_fifo20(11) <= ocpu_sample_bits_fifo20(10);
    --ocpu_sample_bits_fifo20(12) <= ocpu_sample_bits_fifo20(11);
    --ocpu_sample_bits_fifo20(13) <= ocpu_sample_bits_fifo20(12);
    --ocpu_sample_bits_fifo20(14) <= ocpu_sample_bits_fifo20(13);
    --ocpu_sample_bits_fifo20(15) <= ocpu_sample_bits_fifo20(14);
    --ocpu_sample_bits_fifo20(16) <= ocpu_sample_bits_fifo20(15);
    --ocpu_sample_bits_fifo20(17) <= ocpu_sample_bits_fifo20(16);
    --ocpu_sample_bits_fifo20(18) <= ocpu_sample_bits_fifo20(17);
    --ocpu_sample_bits_fifo20(19) <= ocpu_sample_bits_fifo20(18);
    --ocpu_sample_bits_fifo20(20) <= ocpu_sample_bits_fifo20(19);
-------------------------------------------------------------------	
--       if ocp_u_older = '0' and ocp_u_oldest = '1' then
--         if  ocpu_sample_bits_fifo20 = "100000000000000000000" and  pulse_limit_on2off_u = '0' and pulse_limit_off2on_u = '0' then
--         if  ocpu_sample_bits_fifo20 = "000000000000000000000" and  pulse_limit_status_u = '0' and  hold_u_cnt = 42  then
         if  ocpu_sample_bits_fifo20(10 downto 0) = "00000000000" and  pulse_limit_status_u = '0' and  hold_u_cnt = 82  then
 -- o      if ocp_u_older = '1' and ocp_u_oldest = '0' then
 --           ocpu_verify_cnt <= 1;
    --    end if;
-------------------------------------------------------------------	
  --      if ocpu_verify_cnt > 0 and  ocpu_verify_cnt < 30 then
  --          ocpu_verify_cnt <= ocpu_verify_cnt + 1;
  --      end if;
-------------------------------------------------------------------	
--?????oc???----
--		if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '0') ) then
--	o	if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '1') ) then
               pulse_limit_status_u <= '1';

		       pwm_ok_14u_ocp <= '0';   --?????,??????			have over current.
               ocpu_23cnt <= 1;     --?????????
--		       inv_led_b <= '1';
--		       inv_indictor <= '1';
        end if;
-------------------------------------------------------------------	
        if ocpu_23cnt > 0 and  ocpu_23cnt < 20 then
            ocpu_23cnt <= ocpu_23cnt + 1;
        end if;
-------------------------------------------------------------------	
		if  ocpu_23cnt = 19 then
--		if ((ocpu_23cnt = 9) and (ocp_u_oldest = '1') ) then
--		       pwm_ok_23u <= '0';   --????
--			   force_fun_en_u2 <= '1'; 
               force_fun_status_u2 <= '0'; 
			   force_fun_en_u3 <= '1'; 
               force_fun_status_u3 <= '0'; 		
-------------------------------------------------------------------
        end if;
-------------------------------------------------------------------	
--?? ?????????????
	    if  pulse_limit_status_u = '1' and  ocpu_sample_bits_fifo20(0) = '1' and  ocpu_sample_bits_fifo20(1) = '1'  and   ocpu_23cnt = 20 and had_been_u = '0' then
--	    if  pulse_limit_status_u = '1' and  ocp_u_older = '1' and  ocp_u_oldest = '0'   then
            hold_u_cnt <= 1;     --it is got "1" during normal time ?????????
            had_been_u <= '1';
--------------------------------------------
--1us?Q2,Q3?????
		    force_fun_en_u2 <= '1'; 
            force_fun_status_u2 <= '1'; 
		    force_fun_en_u3 <= '1'; 
            force_fun_status_u3 <= '1'; 
--------------------------------------------
        end if;
-------------------------------------------------------------------	
        if hold_u_cnt > 0 and  hold_u_cnt < 82 then
             hold_u_cnt <= hold_u_cnt + 1;
        end if;
-------------------------------------------------------------------	
        if hold_u_cnt > 58 and   hold_u_cnt < 80 then
            if pwm_woking_status_u = '0' then        -- + cycle
--A?
               force_fun_status_u3 <= '0'; 
            else                         -- - cycle
               force_fun_status_u2 <= '0'; 
            end if;
        end if;
-------------------------------------------------------------------	
		if hold_u_cnt = 80 then 				--it can run normally when hold_u_cnt was 80
			   force_fun_en_u2 <= '0'; 
			   force_fun_en_u3 <= '0';   --
--			   pwm_ok_14u_ocp_flag <= '1';        --????
--		end if;
-------------------------------------------------------------------	
--       if pwm_ok_14u_ocp_flag = '1' and   gpio_2_pwm2a_older = '0' and gpio_2_pwm2a_oldest = '1'  then
--		       pwm_ok_14u_ocp_flag <= '0';        --
		       pwm_ok_14u_ocp <= '1';        --nomal time symbol ????
               pulse_limit_status_u <= '0';
               had_been_u <= '0';

		end if;
-------------------------------------------------------------------	
-------------------------------????----------------------------
--????????
--		if hold_u_cnt = 42 and  ocpu_sample_bits_fifo20(0) = '1' and  ocpu_sample_bits_fifo20(1) = '1' and ocpu_sample_bits_fifo20(2) = '1'  then
--		       pwm_ok_14u_ocp <= '1';        --????
--               pulse_limit_off2on_u <= '0';
--        end if;
-------------------------------????----------------------------
      --  if pulse_limit_status_u = '1' then
	--	       inv_led_b <= '0';
      --  else
	--	       inv_led_b <= '1';
	--	end if;
		
		--inv_ext_io_24 <= pwm_ok_14u_ocp;
		--inv_ext_io_25 <= pwm_ok_23u;
		--inv_ext_io_27 <= inv_ext_io_12;
		
        --if pwm_ok_14u_ocp = '1' then
		--       inv_indictor <= '0';
        --else
		--       inv_indictor <= '1';
		--end if;
  end if; -- end clk
	
end if;  -- end reset
end process;
--Process???A???????END
-------------------------------------------------------------------
-------------------------------------------------------------------













---------------------------------------------------------------------------	
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--                    B???????
-- ??????->??????->????14?->????23?->??????
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ B???
---------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-----------------phase a--------------------------------------------------
if inv_cpld_reset_flag = '1'  then 
			signal_inv_pwm_q1_pos_v <= '0';
			signal_inv_pwm_q2_pos_v <= '0'; 
			signal_inv_pwm_q3_pos_v <= '0'; 
			signal_inv_pwm_q4_pos_v <= '0';  	
						
			gpio_18_older <= '0';
			gpio_18_oldest <= '0';

            pos_cycle_disable_pwm_v <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
---------------------------------------------------------------------------
		if	zero_permit_v = '1' then
			 gpio_18_older <= gpio_18;
		end if;	 	 
			 gpio_18_oldest <= gpio_18_older;

			 --inv_ext_io_27 <= gpio_18;
---------------------------------------------------------------------------
--************************************************************************
--************************************************************************
---------------------------------------------------------------------------
        if  gpio_18_oldest = '1' and gpio_18_older = '0' then -- rising edge
------------------------------------------------------------------------
--????????,??????
-- from + cycle to - cycle
--              neg_to_pos_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '0';--????????
-------------------------------------------------------------------------
-- ??Q2,??Q4
		     signal_inv_pwm_q4_pos_v <= '0'; 
--------------------------------------------------------------------------
-- 3?1?
		     if  gpio_5_pwm3b ='0'  then
		          --q3=1,pwm=0
		        pos_cycle_disable_pwm_v<= '1';   --????
		     else --q3=0,pwm=1
		        pos_cycle_disable_pwm_v<= '0';   -- q3,q1=0 ???????,??q3????
		     end if;
         end if;
------------------------------------------------------------------------
 --        if q3 = '1',pwm=0  and  ???????
         if gpio_5_pwm3b = '0'  and pos_cycle_disable_pwm_v = '0' then
		        pos_cycle_disable_pwm_v<= '1';   --????
--          ????????,????
         end if;
----------------------------------------------
         if pos_cycle_disable_pwm_v = '0' then     
                   -- ?? 0
		       signal_inv_pwm_q2_pos_v <= '0'; 
               signal_inv_pwm_q1_pos_v <= '0'; 
				--	signal_inv_pwm_q3_pos_v <= '0'; --20111020gai
					signal_inv_pwm_q3_pos_v <= '1';
         else   -- ?? 1
		       signal_inv_pwm_q2_pos_v <= '1'; 
               signal_inv_pwm_q1_pos_v <= not gpio_4_pwm3a; 
               signal_inv_pwm_q3_pos_v <= not gpio_5_pwm3b; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
---------------------------------------------------------------------------
--************************************************************************
-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ B???
-------------------------------------------------------------------



-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ B???
-------------------------------------------------------------------
--************************************************************************
---------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-----------------phase a--------------------------
if inv_cpld_reset_flag = '1'  then 

			signal_inv_pwm_q1_neg_v <= '0';
			signal_inv_pwm_q2_neg_v <= '0'; 
			signal_inv_pwm_q3_neg_v <= '0'; 
			signal_inv_pwm_q4_neg_v <= '0';  
            neg_cycle_disable_pwm_v <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
       if  gpio_18_oldest = '0' and gpio_18_older = '1' then -- falling edge
--????????,??????
-- from + cycle to - cycle
--             pos_to_neg_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '1';--????????
-------------------------------------------------------------------------
-- ??Q3,??Q1
             signal_inv_pwm_q1_neg_v <= '0'; 
--------------------------------------------------------------------------
-- 2?4?

		     if  gpio_5_pwm3b ='0'  then
		          --q2=1
		        neg_cycle_disable_pwm_v <= '1';   --????
		     else --q2=0
		        neg_cycle_disable_pwm_v <= '0';   -- q2,q4=0 ???????,??q2????
		     end if;
       end if;

------------------------------------------------------------------------
 --        if q2 = '1'  and  ???????
         if gpio_5_pwm3b = '0'  and neg_cycle_disable_pwm_v = '0' then
		        neg_cycle_disable_pwm_v <= '1';   --????
--          ????????,????
         end if;
----------------------------------------------------------------------------
         if neg_cycle_disable_pwm_v = '0' then     
                   -- ?? 
               signal_inv_pwm_q3_neg_v <= '0'; 

				--	signal_inv_pwm_q2_neg_v <= '0'; --20111020gai
					signal_inv_pwm_q2_neg_v <= '1';
               signal_inv_pwm_q4_neg_v <= '0'; 

         else   -- ?? 
               signal_inv_pwm_q3_neg_v <= '1'; 

               signal_inv_pwm_q2_neg_v <= not gpio_5_pwm3b; 
               signal_inv_pwm_q4_neg_v <= not gpio_4_pwm3a; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ B???
-------------------------------------------------------------------












--------------------------------------------------------------------         
---*******************B? ??????*****************************
---------------------------------------------------------------------
-----------------------------------------------------------------------------	
--Process???B?1,4?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'  then 
-------------------------------------------------------------------------
			inv_pwm_gh1_v_1  <= '0';  
			inv_pwm_gb2_v_4  <= '0';  
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
                        
-- ??????
--          if  pwm_ok_14v_ocp = '0'  or pwm1pwm4_off_epo = '0'  or pwm1pwm4_off_dsp = '0'  then      		
          if  pwm_ok_14v_ocp = '0'  or pwm1pwm4_off_dsp = '0'  then      		

		     	inv_pwm_gh1_v_1  <= '0';
		     	inv_pwm_gb2_v_4  <= '0';
          else
	           if pwm_woking_status_v = '0' then
				inv_pwm_gh1_v_1  <= signal_inv_pwm_q1_pos_v;
				inv_pwm_gb2_v_4  <=  '0';  	
	          else
				inv_pwm_gh1_v_1  <=  '0';
				inv_pwm_gb2_v_4  <= signal_inv_pwm_q4_neg_v;
		      end if;
          end if;

	
	end if;  --clk
end if; -- reset
end process;
---------------------------------------------------------------------
-----------------------------------------------------------------------------	









-----------------------------------------------------------------------------	
-----------------------------------------------------------------------------	
--Process???B?2,3?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'  then 
			inv_pwm_gh2_v_2 <= '0'; 
			inv_pwm_gb1_v_3 <= '0'; 
			
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
-----------------------------------------------------------------------------
-- ??????
-- ??2???

--           if  pwm2pwm3_off_dsp = '0' or pwm2pwm3_off_epo = '0'  then
           if  pwm2pwm3_off_dsp = '0'  then

                -----------------------------------------------
	 			inv_pwm_gh2_v_2 <=  '0';
           else
                -----------------------------------------------
                if force_fun_en_v2 = '1'  then
                     if force_fun_status_v2 = '1' then
	        			   inv_pwm_gh2_v_2 <=  '1';
                     else 
	        			   inv_pwm_gh2_v_2 <=  '0';
                     end if;
                else
               -----------------------------------------------
			         if pwm_woking_status_v = '0' then
		 				inv_pwm_gh2_v_2 <= signal_inv_pwm_q2_pos_v; 
		             else
						inv_pwm_gh2_v_2 <= signal_inv_pwm_q2_neg_v; 
				     end if;
                end if;
               ------------------------------------------------
		   end if;
----------------------------------------------------
----------------------------------------------------
-- ??????
-- ??3???
--           if  pwm2pwm3_off_dsp = '0'  or pwm2pwm3_off_epo = '0' then
           if  pwm2pwm3_off_dsp = '0'   then

                -----------------------------------------------
		 			inv_pwm_gb1_v_3 <=  '0';
    	   else
                -----------------------------------------------
                if force_fun_en_v3 = '1'  then
                       if force_fun_status_v3 = '1' then
	        			   inv_pwm_gb1_v_3 <=  '1';
                       else 
	        			   inv_pwm_gb1_v_3 <=  '0';
                       end if;
                else
               -----------------------------------------------
			           if pwm_woking_status_v = '0' then
						inv_pwm_gb1_v_3 <= signal_inv_pwm_q3_pos_v; 
		               else
						inv_pwm_gb1_v_3 <= signal_inv_pwm_q3_neg_v; 
				       end if;
				end if;
            end if;
------------------------------------------------
	end if;  --clk
end if; -- reset
end process;
--------------------------------------------------------------------         
---************END********B? ??????********END***************
---------------------------------------------------------------------



-------------------------------------------------------------------
---------------------------------------------------------------
--Process???B???????
--???/
-------------------------------------------------------------------	
process(inv_cpld_reset,inv_cpld_clk)
begin
-----------------phase a----------------------------------------
if  inv_cpld_reset_flag = '1' then
--    pwm_ok_23v <= '1';
    pwm_ok_14v_ocp <= '1';

	ocpv_23cnt <= 20;
    hold_v_cnt <= 82;	
---------------------------------------
    force_fun_en_v2 <= '0'; 
    force_fun_status_v2 <= '0'; 
	force_fun_en_v3 <= '0'; 
	force_fun_status_v3  <= '0';   
	
	pulse_limit_status_v  <= '0';  
---------------------------------------
    ocpv_sample_bits_fifo20 <= "111111111111111111111";
---------------------------------------
  gpio_4_pwm3a_older  <= '0';   
  gpio_4_pwm3a_oldest  <= '0';   
---------------------------------------
  pwm_ok_14v_ocp_flag <= '0';   
---------------------------------------
  had_been_v <= '0'; 

else
   if inv_cpld_clk'event and inv_cpld_clk = '1' then 
-------------------------------------------------------------------	
    gpio_4_pwm3a_older <= gpio_4_pwm3a;	
    gpio_4_pwm3a_oldest <= gpio_4_pwm3a_older;	

--         ocp_u_older <= service_mode_in;
--     B?
           ocp_v_older <= inv_ext_io_17;
          -- ocp_v_older <= service_mode_in;
           ocp_v_oldest <= ocp_v_older;


  --  ocpv_sample_bits_fifo20(0) <= inv_ext_io_17;
   --- ocpv_sample_bits_fifo20(1) <= ocpv_sample_bits_fifo20(0);
    --ocpv_sample_bits_fifo20(2) <= ocpv_sample_bits_fifo20(1);
    --ocpv_sample_bits_fifo20(3) <= ocpv_sample_bits_fifo20(2);
    --ocpv_sample_bits_fifo20(4) <= ocpv_sample_bits_fifo20(3);
    --ocpv_sample_bits_fifo20(5) <= ocpv_sample_bits_fifo20(4);
    --ocpv_sample_bits_fifo20(6) <= ocpv_sample_bits_fifo20(5);
    --ocpv_sample_bits_fifo20(7) <= ocpv_sample_bits_fifo20(6);
    --ocpv_sample_bits_fifo20(8) <= ocpv_sample_bits_fifo20(7);
    --ocpv_sample_bits_fifo20(9) <= ocpv_sample_bits_fifo20(8);
    --ocpv_sample_bits_fifo20(10) <= ocpv_sample_bits_fifo20(9);
    --ocpv_sample_bits_fifo20(11) <= ocpv_sample_bits_fifo20(10);
    --ocpv_sample_bits_fifo20(12) <= ocpv_sample_bits_fifo20(11);
    --ocpv_sample_bits_fifo20(13) <= ocpv_sample_bits_fifo20(12);
    --ocpv_sample_bits_fifo20(14) <= ocpv_sample_bits_fifo20(13);
    --ocpv_sample_bits_fifo20(15) <= ocpv_sample_bits_fifo20(14);
    --ocpv_sample_bits_fifo20(16) <= ocpv_sample_bits_fifo20(15);
    --ocpv_sample_bits_fifo20(17) <= ocpv_sample_bits_fifo20(16);
    --ocpv_sample_bits_fifo20(18) <= ocpv_sample_bits_fifo20(17);
    --ocpv_sample_bits_fifo20(19) <= ocpv_sample_bits_fifo20(18);
    --ocpv_sample_bits_fifo20(20) <= ocpv_sample_bits_fifo20(19);
-------------------------------------------------------------------	
--       if ocp_u_older = '0' and ocp_u_oldest = '1' then
--         if  ocpv_sample_bits_fifo20 = "000000000000000000000" and  pulse_limit_status_v = '0' and  hold_v_cnt = 42  then
         if  ocpv_sample_bits_fifo20(10 downto 0) = "00000000000" and  pulse_limit_status_v = '0' and  hold_v_cnt = 82  then

 -- o      if ocp_u_older = '1' and ocp_u_oldest = '0' then
 --           ocpu_verify_cnt <= 1;
    --    end if;
-------------------------------------------------------------------	
  --      if ocpu_verify_cnt > 0 and  ocpu_verify_cnt < 30 then
  --          ocpu_verify_cnt <= ocpu_verify_cnt + 1;
  --      end if;
-------------------------------------------------------------------	
--?????oc???----
--		if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '0') ) then
--	o	if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '1') ) then
               pulse_limit_status_v <= '1';--???????
		       pwm_ok_14v_ocp <= '0';   --?????,??????
               ocpv_23cnt <= 1;     --?????????
--		       inv_led_b <= '1';
--		       inv_indictor <= '1';
        end if;
-------------------------------------------------------------------	
        if ocpv_23cnt > 0 and  ocpv_23cnt < 20 then
            ocpv_23cnt <= ocpv_23cnt + 1;
        end if;
-------------------------------------------------------------------	
		if ocpv_23cnt = 19 then
--		if ((ocpu_23cnt = 9) and (ocp_u_oldest = '1') ) then
--		       pwm_ok_23u <= '0';   --????
			   force_fun_en_v2 <= '1'; 
               force_fun_status_v2 <= '0'; 
			   force_fun_en_v3 <= '1'; 
               force_fun_status_v3 <= '0'; 		
        end if;
-------------------------------------------------------------------	
--?? ?????????????
	    if  pulse_limit_status_v = '1' and  ocpv_sample_bits_fifo20(0) = '1' and  ocpv_sample_bits_fifo20(1) = '1'  and   ocpv_23cnt = 20 and had_been_v = '0' then
--	    if  pulse_limit_status_v = '1' and  ocp_v_older = '1' and  ocp_v_oldest = '0'   then
            hold_v_cnt <= 1;     --?????????
            had_been_v <= '1';
--------------------------------------------
--1us?Q2,Q3?????
		    force_fun_en_v2 <= '1'; 
            force_fun_status_v2 <= '1'; 
		    force_fun_en_v3 <= '1'; 
            force_fun_status_v3 <= '1'; 
--------------------------------------------
        end if;
-------------------------------------------------------------------	
        if hold_v_cnt > 0 and  hold_v_cnt < 82 then
             hold_v_cnt <= hold_v_cnt + 1;
        end if;
-------------------------------------------------------------------	
        if hold_v_cnt > 58 and   hold_v_cnt < 80 then
            if pwm_woking_status_v = '0' then        -- + cycle
--B?
               force_fun_status_v3 <= '0'; 
            else                         -- - cycle
               force_fun_status_v2 <= '0'; 
            end if;
        end if;
-------------------------------------------------------------------	
		if hold_v_cnt = 80 then 
			   force_fun_en_v2 <= '0'; 
			   force_fun_en_v3 <= '0';   --??????
--			   pwm_ok_14v_ocp_flag <= '1';        --????
--		end if;
-------------------------------------------------------------------	
--       if pwm_ok_14v_ocp_flag = '1' and  gpio_4_pwm3a_older = '0' and gpio_4_pwm3a_oldest = '1'  then
--		       pwm_ok_14v_ocp_flag <= '0';        --
		       pwm_ok_14v_ocp <= '1';        --????
               pulse_limit_status_v <= '0';
               had_been_v <= '0';

		end if;
-------------------------------------------------------------------	
--       if pulse_limit_status_u = '1' then
--		       inv_led_b <= '0';
--        else
--		       inv_led_b <= '1';
--		end if;
		
		--inv_ext_io_24 <= pwm_ok_14u_ocp;
		--inv_ext_io_25 <= pwm_ok_23u;
		--inv_ext_io_27 <= inv_ext_io_12;
		
--        if pwm_ok_14u_ocp = '1' then
--		       inv_indictor <= '0';
--        else
--		       inv_indictor <= '1';
--		end if;
  end if; -- end clk
	
end if;  -- end reset
end process;
--Process???B???????END
-------------------------------------------------------------------
-------------------------------------------------------------------




























---------------------------------------------------------------------------	
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
--                    C???????
-- ??????->??????->????14?->????23?->??????
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

---------------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ C???
---------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-----------------phase a--------------------------------------------------
if inv_cpld_reset_flag = '1'   then 
			signal_inv_pwm_q1_pos_w <= '0';
			signal_inv_pwm_q2_pos_w <= '0'; 
			signal_inv_pwm_q3_pos_w <= '0'; 
			signal_inv_pwm_q4_pos_w <= '0';  	
						
			gpio_19_older <= '0';
			gpio_19_oldest <= '0';

            pos_cycle_disable_pwm_w <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
---------------------------------------------------------------------------
		if	zero_permit_w = '1' then	
			gpio_19_older <= gpio_19;
		end if;

			gpio_19_oldest <= gpio_19_older;
		
		--	 inv_ext_io_27 <= gpio_19;
---------------------------------------------------------------------------
--************************************************************************
--************************************************************************
---------------------------------------------------------------------------
        if  gpio_19_oldest = '1' and gpio_19_older = '0' then -- rising edge
------------------------------------------------------------------------
--????????,??????
-- from + cycle to - cycle
--              neg_to_pos_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '0';--????????
-------------------------------------------------------------------------
-- ??Q2,??Q4
		     signal_inv_pwm_q4_pos_w <= '0'; 
--------------------------------------------------------------------------
-- 3?1?
		     if  gpio_7_pwm4b ='0'  then
		          --q3=1,pwm=0
		        pos_cycle_disable_pwm_w<= '1';   --????
		     else --q3=0,pwm=1
		        pos_cycle_disable_pwm_w<= '0';   -- q3,q1=0 ???????,??q3????
		     end if;
         end if;
------------------------------------------------------------------------
 --        if q3 = '1',pwm=0  and  ???????
         if gpio_7_pwm4b = '0'  and pos_cycle_disable_pwm_w = '0' then
		        pos_cycle_disable_pwm_w<= '1';   --????
--          ????????,????
         end if;
----------------------------------------------
         if pos_cycle_disable_pwm_w = '0' then     
                   -- ?? 0
		       signal_inv_pwm_q2_pos_w <= '0'; 
               signal_inv_pwm_q1_pos_w <= '0'; 
				--	signal_inv_pwm_q3_pos_w <= '0'; --20111020gai
					signal_inv_pwm_q3_pos_w <= '1';
         else   -- ?? 1
		       signal_inv_pwm_q2_pos_w <= '1'; 
               signal_inv_pwm_q1_pos_w <= not gpio_6_pwm4a; 
               signal_inv_pwm_q3_pos_w <= not gpio_7_pwm4b; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
---------------------------------------------------------------------------
--************************************************************************
-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ C???
-------------------------------------------------------------------



-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ C???
-------------------------------------------------------------------
--************************************************************************
---------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-----------------phase a--------------------------
if inv_cpld_reset_flag = '1'   then 

			signal_inv_pwm_q1_neg_w <= '0';
			signal_inv_pwm_q2_neg_w <= '0'; 
			signal_inv_pwm_q3_neg_w <= '0'; 
			signal_inv_pwm_q4_neg_w <= '0';  
            neg_cycle_disable_pwm_w <= '0';
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
       if  gpio_19_oldest = '0' and gpio_19_older = '1' then -- falling edge
--????????,??????
-- from + cycle to - cycle
--             pos_to_neg_zerocross_cnt_u <= 1; --????
--             pwm_woking_status_u <= '1';--????????
-------------------------------------------------------------------------
-- ??Q3,??Q1
             signal_inv_pwm_q1_neg_w <= '0'; 
--------------------------------------------------------------------------
-- 2?4?

		     if  gpio_7_pwm4b ='0'  then
		          --q2=1
		        neg_cycle_disable_pwm_w <= '1';   --????
		     else --q2=0
		        neg_cycle_disable_pwm_w <= '0';   -- q2,q4=0 ???????,??q2????
		     end if;
       end if;

------------------------------------------------------------------------
 --        if q2 = '1'  and  ???????
         if gpio_7_pwm4b = '0'  and neg_cycle_disable_pwm_w = '0' then
		        neg_cycle_disable_pwm_w <= '1';   --????
--          ????????,????
         end if;
----------------------------------------------------------------------------
         if neg_cycle_disable_pwm_w = '0' then     
                   -- ?? 
               signal_inv_pwm_q3_neg_w <= '0'; 

				--	signal_inv_pwm_q2_neg_w <= '0'; 	--20111020gai
					signal_inv_pwm_q2_neg_w <= '1';
               signal_inv_pwm_q4_neg_w <= '0'; 

         else   -- ?? 
               signal_inv_pwm_q3_neg_w <= '1'; 

               signal_inv_pwm_q2_neg_w <= not gpio_7_pwm4b; 
               signal_inv_pwm_q4_neg_w <= not gpio_6_pwm4a; 
         end if;
------------------------------------------------------------------------
	end if;--//end if clk
end if; --// end if reset

end process;
-------------------------------------------------------------------	
--Process??????   ???        ??????????
--???/ C???
-------------------------------------------------------------------












--------------------------------------------------------------------         
---*******************C? ??????*****************************
---------------------------------------------------------------------
-----------------------------------------------------------------------------	
--Process???C?1,4?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'  then 
-------------------------------------------------------------------------
			inv_pwm_gh1_w_1  <= '0';  
			inv_pwm_gb2_w_4  <= '0';  
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
                        
-- ??????
--          if  pwm_ok_14w_ocp = '0'  or pwm1pwm4_off_epo = '0'  or pwm1pwm4_off_dsp = '0'  then      		
          if  pwm_ok_14w_ocp = '0'  or pwm1pwm4_off_dsp = '0'  then      		

		     	inv_pwm_gh1_w_1  <= '0';
		     	inv_pwm_gb2_w_4  <= '0';
          else
	           if pwm_woking_status_w = '0' then
				inv_pwm_gh1_w_1  <= signal_inv_pwm_q1_pos_w;
				inv_pwm_gb2_w_4  <=  '0';  	
	          else
				inv_pwm_gh1_w_1  <=  '0';
				inv_pwm_gb2_w_4  <= signal_inv_pwm_q4_neg_w;
		      end if;
          end if;

	
	end if;  --clk
end if; -- reset
end process;
---------------------------------------------------------------------
-----------------------------------------------------------------------------	









-----------------------------------------------------------------------------	
-----------------------------------------------------------------------------	
--Process???C?2,3?MOS????
--???/
-----------------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)-- Proc?
begin
-------------------------------------------------------------------------
if inv_cpld_reset_flag = '1'  then 
			inv_pwm_gh2_w_2 <= '0'; 
			inv_pwm_gb1_w_3 <= '0'; 
			
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
-----------------------------------------------------------------------------
-- ??????
-- ??2???

--           if  pwm2pwm3_off_dsp = '0' or pwm2pwm3_off_epo = '0'  then
           if  pwm2pwm3_off_dsp = '0'   then

                -----------------------------------------------
	 			inv_pwm_gh2_w_2 <=  '0';
           else
                -----------------------------------------------
                if force_fun_en_w2 = '1'  then
                     if force_fun_status_w2 = '1' then
	        			   inv_pwm_gh2_w_2 <=  '1';
                     else 
	        			   inv_pwm_gh2_w_2 <=  '0';
                     end if;
                else
               -----------------------------------------------
			         if pwm_woking_status_w = '0' then
		 				inv_pwm_gh2_w_2 <= signal_inv_pwm_q2_pos_w; 
		             else
						inv_pwm_gh2_w_2 <= signal_inv_pwm_q2_neg_w; 
				     end if;
                end if;
               ------------------------------------------------
		   end if;
----------------------------------------------------
----------------------------------------------------
-- ??????
-- ??3???
--           if  pwm2pwm3_off_dsp = '0'  or pwm2pwm3_off_epo = '0' then
           if  pwm2pwm3_off_dsp = '0'   then

                -----------------------------------------------
		 			inv_pwm_gb1_w_3 <=  '0';
    	   else
                -----------------------------------------------
                if force_fun_en_w3 = '1'  then
                       if force_fun_status_w3 = '1' then
	        			   inv_pwm_gb1_w_3 <=  '1';
                       else 
	        			   inv_pwm_gb1_w_3 <=  '0';
                       end if;
                else
               -----------------------------------------------
			           if pwm_woking_status_w = '0' then
						inv_pwm_gb1_w_3 <= signal_inv_pwm_q3_pos_w; 
		               else
						inv_pwm_gb1_w_3 <= signal_inv_pwm_q3_neg_w; 
				       end if;
				end if;
            end if;
------------------------------------------------
	end if;  --clk
end if; -- reset
end process;
--------------------------------------------------------------------         
---************END********C? ??????********END***************
---------------------------------------------------------------------










-------------------------------------------------------------------
---------------------------------------------------------------
--Process???C???????
--???/
-------------------------------------------------------------------	
process(inv_cpld_reset,inv_cpld_clk)
begin
-----------------phase a----------------------------------------
if  inv_cpld_reset_flag = '1' then
--    pwm_ok_23w <= '1';
    pwm_ok_14w_ocp <= '1';

	ocpw_23cnt <= 20;
    hold_w_cnt <= 82;	
---------------------------------------
    force_fun_en_w2 <= '0'; 
    force_fun_status_w2 <= '0'; 
	force_fun_en_w3 <= '0'; 
	force_fun_status_w3  <= '0';   
	
	pulse_limit_status_w  <= '0';  
---------------------------------------
   ocpw_sample_bits_fifo20 <= "111111111111111111111";
---------------------------------------
	gpio_6_pwm4a_older <= '0';   
	gpio_6_pwm4a_oldest <= '0';   
	
    pwm_ok_14w_ocp_flag <= '0';   
---------------------------------------

       had_been_w <= '0'; 
else
   if inv_cpld_clk'event and inv_cpld_clk = '1' then 
-------------------------------------------------------------------	
--
--         ocp_u_older <= service_mode_in;
--     c?
           ocp_w_older <= inv_ext_io_18;
 --          ocp_w_older <= service_mode_in;
           ocp_w_oldest <= ocp_w_older;

	 --ocpw_sample_bits_fifo20(0) <= inv_ext_io_18;			
    --ocpw_sample_bits_fifo20(1) <= ocpw_sample_bits_fifo20(0);
    --ocpw_sample_bits_fifo20(2) <= ocpw_sample_bits_fifo20(1);
    --ocpw_sample_bits_fifo20(3) <= ocpw_sample_bits_fifo20(2);
    --ocpw_sample_bits_fifo20(4) <= ocpw_sample_bits_fifo20(3);
    --ocpw_sample_bits_fifo20(5) <= ocpw_sample_bits_fifo20(4);
    --ocpw_sample_bits_fifo20(6) <= ocpw_sample_bits_fifo20(5);
    --ocpw_sample_bits_fifo20(7) <= ocpw_sample_bits_fifo20(6);
    --ocpw_sample_bits_fifo20(8) <= ocpw_sample_bits_fifo20(7);
    --ocpw_sample_bits_fifo20(9) <= ocpw_sample_bits_fifo20(8);
    --ocpw_sample_bits_fifo20(10) <= ocpw_sample_bits_fifo20(9);
    --ocpw_sample_bits_fifo20(11) <= ocpw_sample_bits_fifo20(10);
    --ocpw_sample_bits_fifo20(12) <= ocpw_sample_bits_fifo20(11);
    --ocpw_sample_bits_fifo20(13) <= ocpw_sample_bits_fifo20(12);
    --ocpw_sample_bits_fifo20(14) <= ocpw_sample_bits_fifo20(13);
    --ocpw_sample_bits_fifo20(15) <= ocpw_sample_bits_fifo20(14);
    --ocpw_sample_bits_fifo20(16) <= ocpw_sample_bits_fifo20(15);
    --ocpw_sample_bits_fifo20(17) <= ocpw_sample_bits_fifo20(16);
    --ocpw_sample_bits_fifo20(18) <= ocpw_sample_bits_fifo20(17);
    --ocpw_sample_bits_fifo20(19) <= ocpw_sample_bits_fifo20(18);
    --ocpw_sample_bits_fifo20(20) <= ocpw_sample_bits_fifo20(19);
-------------------------------------------------------------------	
--       if ocp_u_older = '0' and ocp_u_oldest = '1' then
--         if  ocpw_sample_bits_fifo20 = "000000000000000000000" and  pulse_limit_status_w = '0' and  hold_w_cnt = 42  then
         if  ocpw_sample_bits_fifo20(10 downto 0) = "00000000000" and  pulse_limit_status_w = '0' and  hold_w_cnt = 82  then

 -- o      if ocp_u_older = '1' and ocp_u_oldest = '0' then
 --           ocpu_verify_cnt <= 1;
    --    end if;
-------------------------------------------------------------------	
  --      if ocpu_verify_cnt > 0 and  ocpu_verify_cnt < 30 then
  --          ocpu_verify_cnt <= ocpu_verify_cnt + 1;
  --      end if;
-------------------------------------------------------------------	
--?????oc???----
--		if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '0') ) then
--	o	if ((ocpu_verify_cnt = 29) and (ocp_u_oldest = '1') ) then
               pulse_limit_status_w <= '1';--???????
					pwm_ok_14w_ocp <= '0';   --?????,??????
               ocpw_23cnt <= 1;     --?????????
--		       inv_led_b <= '1';
--		       inv_indictor <= '1';
        end if;
-------------------------------------------------------------------	
        if ocpw_23cnt > 0 and  ocpw_23cnt < 20 then
            ocpw_23cnt <= ocpw_23cnt + 1;
        end if;
-------------------------------------------------------------------	
		if ocpw_23cnt = 19 then
--		if ((ocpu_23cnt = 9) and (ocp_u_oldest = '1') ) then
--		       pwm_ok_23u <= '0';   --????
			   force_fun_en_w2 <= '1'; 
               force_fun_status_w2 <= '0'; 
			   force_fun_en_w3 <= '1'; 
               force_fun_status_w3 <= '0'; 		
        end if;
-------------------------------------------------------------------	
--?? ?????????????
	    if  pulse_limit_status_w = '1' and  ocpw_sample_bits_fifo20(0) = '1' and  ocpw_sample_bits_fifo20(1) = '1'  and   ocpw_23cnt = 20 and had_been_w = '0' then
            hold_w_cnt <= 1;     --?????????
            had_been_w <= '1';
--------------------------------------------
--1us?Q2,Q3?????
		    force_fun_en_w2 <= '1'; 
            force_fun_status_w2 <= '1'; 
		    force_fun_en_w3 <= '1'; 
            force_fun_status_w3 <= '1'; 
--------------------------------------------
        end if;
-------------------------------------------------------------------	
        if hold_w_cnt > 0 and  hold_w_cnt < 82 then
             hold_w_cnt <= hold_w_cnt + 1;
        end if;
-------------------------------------------------------------------	
        if hold_w_cnt > 58 and   hold_w_cnt < 80 then
-------------------------------------------------------------------
--C?
            if pwm_woking_status_w = '0' then        -- + cycle
               force_fun_status_w3 <= '0'; 
            else                         -- - cycle
               force_fun_status_w2 <= '0'; 
            end if;
        end if;
-------------------------------------------------------------------	
--????????
		if hold_w_cnt = 80 then
			   force_fun_en_w2 <= '0'; 
			   force_fun_en_w3 <= '0';   --??????
--			   pwm_ok_14w_ocp_flag <= '1';        --????
--        end if;
-------------------------------------------------------------------	
--       if pwm_ok_14w_ocp_flag = '1' and   gpio_6_pwm4a_older = '0' and gpio_6_pwm4a_oldest = '1'  then
--		       pwm_ok_14w_ocp_flag <= '0';        --
		       pwm_ok_14w_ocp <= '1';        --????
               pulse_limit_status_w <= '0';
               had_been_w <= '0';

		end if;
-------------------------------------------------------------------	
--       if pulse_limit_status_u = '1' then
--		       inv_led_b <= '0';
--        else
--		       inv_led_b <= '1';
--		end if;
		
		--inv_ext_io_24 <= pwm_ok_14u_ocp;
		--inv_ext_io_25 <= pwm_ok_23u;
		--inv_ext_io_27 <= inv_ext_io_12;
		
--        if pwm_ok_14u_ocp = '1' then
--		       inv_indictor <= '0';
--        else
--		       inv_indictor <= '1';
--		end if;
  end if; -- end clk
	
end if;  -- end reset
end process;
--Process???C???????END
-------------------------------------------------------------------
-------------------------------------------------------------------






















-------------------------------------------------------------------	
--Process???
----------------------------------------------------------------------------
--------------------------------------------------------------------------
process(inv_cpld_clk)-- Proc -right shift reg
begin
if inv_cpld_reset_flag = '1'  then 
			pwm_woking_status_u <= '0'; 
			pwm_woking_status_v <= '0'; 
			pwm_woking_status_w <= '0'; 

			gpio17_fifo <= "0000000";
			gpio18_fifo <= "0000000";
			gpio19_fifo <= "0000000";
			
			zero_permit_u <= '1'; 
			zero_permit_v <= '1'; 		
			zero_permit_w <= '1'; 

else

   if  inv_cpld_clk'event and inv_cpld_clk ='1' then			--pwm_woking_status_u was changed after right shift 6 bit which time gpio17 had changed in
-- 2 bit right shift

		
		gpio17_fifo<= gpio_17 & gpio17_fifo(6 downto 1) ;	
		
		if zero_permit_u = '1' then
			pwm_woking_status_u<=gpio17_fifo(0);  -- output signal
		end if;	

		gpio18_fifo<= gpio_18 & gpio18_fifo(6 downto 1) ;		
		
		if zero_permit_v = '1' then
			pwm_woking_status_v<=gpio18_fifo(0);  -- output signal
		end if;

		gpio19_fifo<= gpio_19 & gpio19_fifo(6 downto 1) ;
		
		if zero_permit_w = '1' then
			pwm_woking_status_w<=gpio19_fifo(0);  -- output signal
		end if;		
		
		zero_permit_u <= ex_out_a_reg(12);
		zero_permit_v <= ex_out_a_reg(13);		
		zero_permit_w <= ex_out_a_reg(14);
		
   end if;
end if;
--  rec_ext_io_5 <= late_pwm_u;
end process;
-------------------------------------------------------------------	


-----------------------------------























-------------------------------------------------------------------	
--Process???LBS????
--???/
-------------------------------------------------------------------
process(inv_cpld_clk)-- Proc?LBS & SYNC
begin
if  inv_cpld_reset_flag = '1' then
    inv_ext_io_2 <= '1';
else

if inv_cpld_clk'event and inv_cpld_clk = '1' then

	if lbs_cs2 = '0' then
		inv_ext_io_2 <= '1';--				: OUT	std_logic;-- LBS_SYNC
	else
		if lbs_cs1 = '0' then
			inv_ext_io_2 <=not inv_et0_in;--		: OUT	std_logic;--LBS_SYNC = narrow
		else
			inv_ext_io_2 <=not  inv_ext_io_6;--	: OUT	std_logic;-- LBS_SYNC = wide
		end if;
	end if;--

  end if;
end if;--

end process;
-------------------------------------------------------------------







-------------------------------------------------------------------	
--Process????????????
--???/
-------------------------------------------------------------------
--process(inv_et1_in)-- Proc- DSP error switch to bypass
--begin
-- dsp????????Nxb+????,?dsp??????-0920-------
--	inv_ext_io_40 <= bps_out;--: OUT	std_logic;--INV: BPS
--	inv_ext_io_48 <= invs_out;--: OUT	std_logic;--INV: INVS
--	
--	-- external timer 1	13.1ms
--	inv_et1_out <= ex_out_a_reg(7);
--	
--	if inv_et1_in = '0' then-
--		bps_out <= bps_bak;
--		invs_out <= '0';
--	else
--		bps_out <= bps;
--		invs_out <= invs;
--	end if;
--
--end process;
-------------------------------------------------------------------






-------------------------------------------------------------------	
--Process???SPI?????? 
--???/
-------------------------------------------------------------------
--*****************************************************************-	
--process(epo_n)-- Proc?Input			Why is epo_n here ?
process(inv_cpld_clk,inv_cpld_reset)-- Proc?Input
begin
--------*****************************************-------
if inv_cpld_reset_flag = '1'   then 
			
else
	if inv_cpld_clk'event and inv_cpld_clk = '1' then
	ex_in_a(0) <= signal_inv_overload_rxd;--reserved
	ex_in_a(1) <= signal_sys_unlock_rxd;--reserved
	ex_in_a(2) <= signal_inv_standby_rxd;--reserved
	ex_in_a(3) <= signal_bp_status_rxd ;--reserved
	ex_in_a(4) <= signal_master_online_rxd ;--reserved	
--	rec_inv_io_6 <=  signal_bat_discharging_rxd;	

	ex_in_c(9) <= '0';-- signal_1_inv_on_rxd ;
	ex_in_c(10) <= '0';--signal_2_inv_on_rxd ;
	ex_in_c(11) <= '0';--signal_3_inv_on_rxd ;
	ex_in_c(12) <= '0';--signal_4_inv_on_rxd ;
	ex_in_c(13) <= '0';--signal_5_inv_on_rxd ;


--------*****************************************-------
	ex_in_c(14) <= '0' ; -- 6th bit of inv_on_rxd ;
--------*****************************************-------
--	ex_in_a(0) <= signal_inv_overload_rxd;--				: in	std_logic;--parallel: INV_OVERLOAD_F
--	ex_in_a(1) <= signal_sys_unlock_rxd;--				: in	std_logic;--parallel: SYSTEM_UNLOCK_F
--	ex_in_a(2) <= signal_inv_standby_rxd;--				: in	std_logic;--parallel: INV_ON_STANDBY_F
--	ex_in_a(3) <= signal_bp_status_rxd;--				: in	std_logic;--parallel: INV_BP_STATUS_F
--	ex_in_a(4) <= signal_master_online_rxd ;--

--	ex_in_a(8) <= '0';--reserved		
	ex_in_a(9) <= '0';--reserved		
	ex_in_a(10)<= '0';--reserved			
		
	ex_in_a(11) <= '0';--version display bit to dsp
	ex_in_a(12) <= '0';--version display bit to dsp
	ex_in_a(13) <= '0';--version display bit to dsp
	ex_in_a(14) <= '0';--version display bit to dsp
------------------------------------------------------------
	--????????4????16???????????
	--0000  --->  V100(?????????????)
	--0001  --->  V110(??????2007.05.16)
	--0010  --->  V120
    --...
	--???????VxxxBxxxDxxx???Dxxx?CPLD?????V??

-----------------------------------------	
	ex_in_b(0) <= inv_ext_io_5; --	bridge short   --be connected to GND---
	ex_in_b(1) <= rec_inv_io_14;--   module over-temperature	 inv_otp  --only connect to REC_CPLD--
	ex_in_b(2) <= inv_ext_io_11;--	module type
	ex_in_b(3) <= inv_ext_io_7; --	fuse fault
	ex_in_b(4) <= inv_ext_io_8; --	module ready
----------------- laoa add 20131216---------------------------------------
	if inv_ext_io_16 ='0' or inv_ext_io_17='0' or inv_ext_io_18='0' then
	ex_in_b(5) <= '1';--reserved	
	else
	ex_in_b(5) <= '0';
	end if;
---------------------------------------------------------------------------
	ex_in_b(6) <= service_mode_in;	--	service mode
	ex_in_b(7) <= '0';--reserved	

	ex_in_b(8)  <= inv_ext_io_9;--  	bus ovp   bus over voltage protect
	ex_in_b(9)  <= not inv_ext_io_10;--	fan fault ????

-----------------------------------------------------------------
--	ex_in_b(10) <= inv_ext_io_12;--
--	ex_in_b(11) <= inv_ext_io_13;--
--	ex_in_b(12) <= inv_ext_io_14;--
-----------------------------------------------------------------
---------------------------CHANGE---------------------------------
--****************************************************************
-------------------------module id to dsp-------------------------	
	ex_in_b(10) <= inv_ext_io_12;--  LSB		module id1
	ex_in_b(11) <= inv_ext_io_13;--				module id2
	ex_in_b(12) <= inv_ext_io_14;--  			module id3
	ex_in_b(13) <= rec_inv_io_11;--  HSB		module id0
--	ex_in_b(10) <= '1';--  LSB
--	ex_in_b(11) <= '0';--
--	ex_in_b(12) <= '0';--  
--	ex_in_b(13) <= '0';--  HSB

-------------------------module id to dsp-------------------------
--****************************************************************
---------------------------CHANGE---------------------------------


	ex_in_b(14) <= inv_set;		-- bDSPFirmWareOK
-----------------------------------------	
	ex_in_c(0) <= rec_inv_io_0;--	--reserved			rec off
--	ex_in_c(1) <= rec_inv_io_1;--	--reserved			rec fault		20111123xiaogai
	ex_in_c(2) <= inv_ext_io_1;--	--power ok
	ex_in_c(3) <= epo_n;		
--	inv_ext_io_27 <= epo_n;		
	
--------------------------------------------------------------
--------------------------------------------------------------
	ex_in_c(7) <=  rec_inv_io_13;--power fault in 
------------------------------------------------------------
--	ex_in_c(8) <= '0';--reserved			
------------------------------------------------------------
--	ex_in_c(9) <= '0';--reserved			

--	ex_in_c(10) <= '1';--reserved			
    ex_in_d(1) <= rec_inv_io_3;			--module led status lsb
    ex_in_d(2) <= rec_inv_io_4;			--module led status hsb
 --   ex_in_d(3) <= bp_stsshort_rxd;
 --   ex_in_d(4) <= bp_overcurrent_rxd;			20111123xiaogai
	end if;
 end if;
end process;
-------------------------------------------------------------------











-------------------------------------------------------------------	
--Process?????GPIO??
--???/
-------------------------------------------------------------------
process(inv_cpld_clk,inv_cpld_reset)--Proc?Special_en_dir
begin

if  inv_cpld_reset_flag = '1' then

    inv_ext_io_4 <= '1';		--inv_sync
--    inv_ext_io_4 <= '0';--2009.01.19

    inv_ext_io_3 <= '1';		--carrier_sync
    inv_can1_tx  <= '1';
    inv_can2_tx  <= '1';

else


   -- 
	 inv_ext_io_0 <= '0';
    inv_ext_io_19 <=  gpio_8;    --ad cs
    inv_ext_io_4 <= not gpio_11;    --inv sync
--    inv_ext_io_4 <=  gpio_11;    --inv sync --2009.01.19

    inv_ext_io_3 <= not gpio_16;     --carrier sync
--    inv_ext_io_15 <= rec_inv_io_11;  --reset from rec
--    fault_clear <=  rec_inv_io_11;

	gpio_24_cap1 <= pulse_limit_status_u;	
	gpio_25_cap2 <= pulse_limit_status_v;
--	gpio_24_cap1 <= not inv_ext_io_21;-- CARRIER_SYN_F
--	gpio_25_cap2 <= not inv_ext_io_20;-- LBS_SYNC_F
--	rec_inv_io_7 <= not inv_ext_io_21;-- CARRIER_SYN_F
	rec_inv_io_10 <= not inv_ext_io_21;-- CARRIER_SYN_F


	inv_et0_out <= inv_ext_io_6;--out cross zero hw
	gpio_26_cap3 <= inv_et0_in;--ICAP_CROSS_N	

--	gpio_27_cap4 <= not inv_ext_io_22;-- inv_SYNC_F
	gpio_27_cap4 <= pulse_limit_status_w;
--	gpio_27_cap4 <=  inv_ext_io_22;-- inv_SYNC_F --2009.01.19


	-- 485
	inv_485_txd <= not gpio_29_sci_a_txd;
--	rendebug1 <= not gpio_29_sci_a_txd;
--	inv_indictor<= not gpio_29_sci_a_txd;
	gpio_28_sci_a_rxd <= inv_485_rxd;
	
	-- 232
	inv_sci_txd <=  not gpio_22_sci_b_txd;		-- software oscilloscope
	gpio_23_sci_b_rxd <= not  inv_sci_rxd;

	-- can_a
	inv_can1_tx <= gpio_31_can_a_tx;		-- CAN_Monitor
	gpio_30_can_a_rx <= inv_can1_rx;
	
	-- can_b
	inv_can2_tx <= gpio_20_can_b_tx;		-- CAN_module
	gpio_21_can_b_rx <= inv_can2_rx;

--	if inv_ext_io_26 = '0' then 
--	 gpio_34 <='0';
--	else 
--	 inv_ext_io_15 <= gpio_34; 
--	 gpio_34 <= 'Z';
--	end if;
end if;	
	
	
end process;





-------------------------------------------------------------------	
--Process???10M?????
--????????1us??? 
-------------------------------------------------------------------	
--process(inv_cpld_clk)-- soft switch
--begin
--	if inv_cpld_clk'event and inv_cpld_clk = '0' then
--		clk_10M <= not clk_10M;--
--	end if;

----inv_indictor <= clk_10M;

--end process;





-------------------------------------------------------------------	
-------------------------------------------------------------------
process(inv_cpld_reset,inv_cpld_clk)--
begin
if  inv_cpld_reset = '0' then

	if inv_cpld_clk'event and inv_cpld_clk = '1' then 
		inv_cpld_reset_cnt <= inv_cpld_reset_cnt + 1;

		if  inv_cpld_reset_cnt = 30000   then  --1.5ms
		
				inv_cpld_reset_cnt <= 29900;	
	        inv_cpld_reset_flag <=  '1';
		end if;

	end if; 
else
			inv_cpld_reset_cnt <= 3;	
	      inv_cpld_reset_flag <=  '0';
end if;

			  
if  inv_cpld_reset_flag = '1' then
--    led_temp_reg <= 0; 
    led_cnt <= 0;
	 inv_led_b <= '1';
else
	 inv_led_b <= '0';
--  if gpio_2_pwm2a'event and gpio_2_pwm2a = '1' then
--	if inv_cpld_clk'event and inv_cpld_clk = '1' then 
   if rendebug'event and rendebug = '1' then
      led_cnt <= led_cnt + 1;

--     if led_temp_reg = 6 then
--       led_temp_reg <= 0;
--      end if;

	  if  led_cnt = 8000   then  --20000000
	        led_cnt <=  1;

--		   if led_temp_reg < 6  then
--		      led_temp_reg <= led_temp_reg + 1;
--		   end if;
	 end if;

  end if;

  if  led_cnt < 4000   then  --10000000
    inv_led_a <= '0';
--     inv_led_b <= '1';
--    inv_indictor <= '1';
--inv_ext_io_27 <= '1';

 else
    inv_led_a <= '1';
--      inv_led_b <= '0';
--    inv_indictor <= '0';
--inv_ext_io_27 <= '0';
 end if;



end if;

end process;



process(inv_cpld_clk)-- Proc?		--SPISTE FOR REC_CPLD
begin
if inv_cpld_reset_flag = '1' then
      ste_cnt <= 1;
      rec_inv_io_6 <= '0'; --STE--bat discharge status f
else
    if inv_cpld_clk'event and inv_cpld_clk = '1' then
         if  ste_cnt < 1023  then
              ste_cnt <= ste_cnt + 1;	
         else
              ste_cnt <= 0;   --"000000000";
         end if;    

         if    ste_cnt < 600  then
               singal_ste <= '1';   ----
         else
               singal_ste <= '0';   ---- 
         end if;

       rec_inv_io_6 <= singal_ste;   --out-- --STE--bat discharge status f
       singal_ste_older <= singal_ste;
       singal_ste_oldest <= singal_ste_older;
	end if;--clk 
end if;--rec_cpld_reset 
end process;


-------------------------------------------------------------------	
--Process???SPI???? 
--???spi?clk??????spi?clk?????
-------------------------------------------------------------------	
-------------------------------------------------------------------	
process(inv_cpld_clk,inv_cpld_reset)-- Proc?IO Extend		SPI INV_CPLD-REC_CPLD
begin
	mex_io_count_v16 := conv_integer(mex_io_count);
	mex_io_count_v16_2 := conv_integer(mex_io_count_2);	
if inv_cpld_reset_flag = '1' then
		  mex_io_count <= "1111";
        rec_inv_io_7 <= '1';         --out--  --WR--carrier f
		  rec_inv_io_8 <= '0'; 	    --out--  --DATA--solar project//net inv status
        transfer_onging <= '0';
	--    delay_cnt <= 7;

			mex_io_count_2 <= "1111";
		  data_from_rec_cpld <= "1111111111111111";
        rec_inv_io_12 <= '0';  -- spi receive OK - 0
        transfer_onging_2 <= '0';
        delay_cnt1 <= 7;
        delay_cnt2 <= 7;

else--rec_cpld_reset = '1' 			
-------------------------------------------------------------------	
    if inv_cpld_clk'event and inv_cpld_clk = '1' then		-- output extend
	-------------------------------------------------------------------	
               sig_rec_inv_io_9 <= rec_inv_io_9;      --in -- ReceiveOK--
	-------------------------------------------------------------------	
	--	if rec_inv_io_10 = '1' then
		if singal_ste_oldest = '1' then			
	
	-- ??????
				 mex_io_count <= "1111";
	-- WR??1
			    rec_inv_io_7 <= '1'; 
	-- ????0
			    rec_inv_io_8 <= '0'; 
	          transfer_onging <= '0';

------------------------------------------------------------------------------	
            if 	mex_io_count_2 = "1111"   then 
	            if  rec_inv_io_1 = '0' and transfer_onging_2 = '0' then 
                data_from_rec_cpld(mex_io_count_v16) <= rec_inv_io_2;
	            rec_inv_io_12 <= '1';				
	            transfer_onging_2 <= '1';	--transfer is going on
	            delay_cnt1 <=1;
                end if;
       ----------------------------------------------------------------------
                if delay_cnt1 < 3 then 
                delay_cnt1 <=  delay_cnt1 + 1;
                end if; 
       ----------------------------------------------------------------------
	            if  rec_inv_io_1 = '1' and delay_cnt1 = 3 then 
	            rec_inv_io_12 <= '0';			--RECEIVE OK
	            transfer_onging_2 <= '0';
					mex_io_count_2 <= mex_io_count_2 - 1;
					delay_cnt2 <= 1;
               delay_cnt1 <= 7; 

	            end if;
	        end if;
------------------------------------------------------------------------------	
            if ( mex_io_count_2 > 1 or mex_io_count_2 = 1 ) and mex_io_count_2 < "1111"   then
                   if transfer_onging_2 = '0' and   rec_inv_io_1 = '0' and delay_cnt2 = 3 then 
                     data_from_rec_cpld(mex_io_count_v16_2) <= rec_inv_io_2;
			            rec_inv_io_12 <= '1';
			            transfer_onging_2 <= '1';
			            delay_cnt1 <= 1; 
                   end if;
----------------------------------------------------------------------------
	                if delay_cnt1 < 3 then 
	                delay_cnt1 <=  delay_cnt1 + 1;
	                end if; 
----------------------------------------------------------------------------
		            if delay_cnt2 < 3 then 
	                delay_cnt2 <=  delay_cnt2 + 1;
	                end if; 
                ------------------------------------------------------------------
		            if  rec_inv_io_1 = '1' and delay_cnt1 = 3 then 
		                rec_inv_io_12 <= '0';
		                transfer_onging_2 <= '0';
							 mex_io_count_2 <= mex_io_count_2 - 1;
								delay_cnt2 <= 1;
                        delay_cnt1 <= 7; 
		            end if;
            end if;-- end mex_io_count_2
----------------------------------------------------------------------------

		else			
				mex_io_count_2 <= "1111";
            rec_inv_io_12 <= '0';  -- OK - 0
            transfer_onging_2 <= '0';
            delay_cnt1 <= 7;
            delay_cnt2 <= 7;
				
	----------------------------------------------------------------------
	----------------------------------------------------------------------
            if  mex_io_count_v16 > 0 then
                   if transfer_onging = '0' and   sig_rec_inv_io_9 = '0' then 	--receive is ok
					    rec_inv_io_8 <= data_to_rec_cpld(mex_io_count_v16);
			            rec_inv_io_7 <= '0';
			            transfer_onging <= '1';		  -- ready to next data
 			            mex_io_count <= mex_io_count - 1;
--                      delay_cnt <= delay_cnt -1;
--		                delay_cnt <=1;
				    end if;
	----------------------------------------------------------------------
  	               if  sig_rec_inv_io_9 = '1' then --and delay_cnt = 6  then   --receive is not ok
		                rec_inv_io_7 <= '1';
		                transfer_onging <= '0';		-- it cannot transfer next data
		           end if;
            end if;-- end mex_io_count
----------------------------------------------------------------------------
   		end if; -- end if ste

--		if delay_cnt = 5  then 
--		inv_ext_io_17  <= '1'; 
--		end if;
		
 	end if; -- end if clk
 end if;--rec_cpld_reset 
end process;
-------------------------------------------------------------------	
-------------------------------------------------------------------	

-------------------------------------------------------------------	
process(inv_cpld_clk,inv_cpld_reset)
begin

--data_to_rec_cpld(15)<= service_mode_in;
--data_to_rec_cpld(15)<= service_mode_in;-- test bit
data_to_rec_cpld(15)<= signal_bat_discharging_rxd;	 --	rec_inv_io_6 <=  signal_bat_discharging_rxd;	

data_to_rec_cpld(14)<= ex_out_d_reg(10); --   rec_inv_io_8 <= ex_out_d_reg(10);  -- to rec  solar project// net inv status
inv_indictor <= ex_out_d_reg(11);

--inv_led_b <= ex_out_d_reg(12);		--renqx 20111109xiaogai
--inv_led_b <=pwm1pwm4_off_dsp;
--inv_led_b <=pwm_ok_14u_ocp;
--inv_led_b <=inv_ext_io_16;

ex_in_d(15 downto 3) <= data_from_rec_cpld(15 downto 3);

data_to_rec_cpld(13 downto 1)<= ex_out_e_reg(12 downto 0);
--data_to_rec_cpld(0)<= '1';
data_to_rec_cpld(0) <= gpio_8;

--data_from_dsp(8 downto 3)<= "111111";
--inv_indictor <=  data_to_dsp(14);

--data_from_dsp(15)<= service_mode_in;
--data_from_dsp(15)<= '1';
--data_from_dsp(14)<= '1';
--data_from_dsp(13)<= '0';
--data_from_dsp(12)<= '0';
--data_from_dsp(11)<= '0';
--data_from_dsp(10)<= '1';
--ex_in_d(15 downto 0) <= data_to_dsp(15 downto 0); 
 
end process;
---------------------------------------------------------------
-------------------------------------------------------------------	
--process()
--begin
--end process;
END rtl;