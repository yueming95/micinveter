/*==========================================================*/
/* Title		:	SCIDrv.h								*/
/* Description	: 	Class_SCIDrv definition					*/
/* Date			:	Apr.2008								*/
/*==========================================================*/

#ifndef    SCIDRV_H
       
#define	   SCIDRV_H



#define RLEN 	0xFF	  /*���ݵĳ���Ϊ255*/

#define IN
 struct	SCITRANS_BITS
 {				
			Uint16 sciRXok:1;
			Uint16 sciTXok:1;
			Uint16 sciOverTime:1;
			Uint16 sciReceiveOver:1;
			Uint16 rsvd:12;

                  }; 

class Class_SCIDrv
	{
	
	public:
		volatile struct  SCITRANS_BITS sciFlagReg;
		Uint16 rtemp;              /*recvdelt()�н�������֡����ʱ�洢��Ԫ*/
	    Uint16 Receivecount;  
		Uint16 LenData;            /*������03���ӻ���Ӧ������*/
        
        Uint16 *pr; 
		Uint16 CRC; 
        Uint16 nEND;               /*��Ϣ������8λ�ֽڵ�ǰ�Ĵ�������*/
        Uint16 regCRC;             /*CRC�Ĵ���*/
	    
	    Uint16 Pmid;               /*MBUF[]�±�*/
	    Uint16 otime;              /*Readchar()���ز���*/

		Uint16 FunctionCode;				//������
		Uint16 FunctionAddress;
		Uint16 u16RegNumORdata;				//���յ���16λ�Ĵ������ݻ�����
		Uint16 RxCRC;


	    Uint16 RBUF[32];
	    Uint16 TBUF[32];           /*16λ�õ�8λ*/
        Uint16 DATABUF[32];

	
//		volatile struct SCITRANS scitrans;
		void 	Drv_Init(void);
		void 	SciTransData(Uint16 txnum);    
		void 	SciReceiveCodeDelt(void); 
		void 	SciArrayTrans(Uint16 *BUFaddress,Uint16 FunctionCodeTemp,Uint16 datanum,Uint16 AcessFlag);  
		void 	SciReceiveData(void);
		Uint16 	CRCcodeDelt(Uint16 *BUFaddress,Uint16 CRCnum);
		void 	rightdelt(void);
		void 	errodelt(void);
		void	DebugDatadelt(void);

private:		
		Uint16 	Readchar(void);
		
	};

interrupt void SCIARX_ISR(void);
#endif

//===========================================================================
// End of file.
//===========================================================================
