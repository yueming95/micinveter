/***************************************************************************************
* 
* Filename: 		SysCanHal.h
* Contributor:
* Author: 		Wang Zhihua	
* Date: 			1/21/2008
* Copyright 		2008 ENPC Corporation, All Rights Reserved
*
* Description: 	
* 
* 
* Version
* Last rev by:		Wang Zhihua
* Last rev date:	1/21/2008
* Last rev desc:	
****************************************************************************************/

#ifndef TEMPLATE_LIST_H
#define TEMPLATE_LIST_H

//---------------------------------------------------------------
//Include header

//-----------------------------------------------------------------------------
//Macro definition and enum

//------------------------------------------------------------------------------
//Public variable definition

//-------------------------------------------------------------------------------
//func prototype definiton

//-------------------------------------------------------------------------
//Class prototype
#endif

