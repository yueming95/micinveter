@echo off
echo 'Building target: E:/work/SG50KT4WA/program/SG50KTWADC/UHRF3S67U121_opencycle/../UHRF3S67U121.out'
