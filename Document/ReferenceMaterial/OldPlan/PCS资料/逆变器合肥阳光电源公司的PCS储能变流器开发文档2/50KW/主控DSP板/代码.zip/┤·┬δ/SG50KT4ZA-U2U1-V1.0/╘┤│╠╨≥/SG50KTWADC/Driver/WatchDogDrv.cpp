#include "WatchDogDrv.h"


void	Class_WatchDogDrv::Drv_Init(void)
{
	
}

// This function resets the watchdog timer.
void Class_WatchDogDrv::Drv_KickDog(void)
{
	EALLOW;

	SysCtrlRegs.WDKEY = 0x0055;
	SysCtrlRegs.WDKEY = 0x00AA; 							// This will clear the watchdog counter

	EDIS;
}


// This function disables the watchdog timer.
void Class_WatchDogDrv::Drv_DisableDog(void)
{
    EALLOW;
    SysCtrlRegs.WDCR= 0x0068;
    EDIS;
}

// This function enables the watchdog timer.
void Class_WatchDogDrv::Drv_EnableDog(void)
{
    EALLOW;
    SysCtrlRegs.WDCR = 0x002B;								//it take 13ms that the watchdog overflow
    EDIS;
}


//============================================================
// End of file.
//============================================================
