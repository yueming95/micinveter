#ifndef _CAN_H
#define _CAN_H
#include "DSP280x_Device.h" 
#include "IQmathLib.h"
#ifdef can_GLOBALS
#define can_GLOBALS
#else
#define can_GLOBALS extern
#endif
typedef union
{	
	struct
	{
		Uint16 Lbit         : 16;  
		Uint16 Hbit         : 16;  
	}bit;
	Uint32 all;
}CANDAT;
struct INTERFACE
{
	CANDAT SendL;
	CANDAT SendH;
	CANDAT SendL1;
	CANDAT SendH1;
	CANDAT RdatL;
    CANDAT RdatH;
	CANDAT RdatL1;
    CANDAT RdatH1;

};
can_GLOBALS		struct INTERFACE InterfaceCan;
	can_GLOBALS	Uint16 CanSendTime;
		void CPMsgSend(void);
		void CanDataPack(void);
#endif
