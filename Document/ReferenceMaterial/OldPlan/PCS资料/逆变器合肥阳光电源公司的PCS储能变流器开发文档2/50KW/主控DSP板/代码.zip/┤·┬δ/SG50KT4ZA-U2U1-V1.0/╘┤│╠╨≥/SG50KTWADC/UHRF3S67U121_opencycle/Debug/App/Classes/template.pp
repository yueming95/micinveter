# FIXED

App/Classes/template.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Classes/template.cpp

E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Classes/template.cpp: 
