/*=====================================================================================
 File name:        SVGENQ.C  (IQ version)                  
                    
 Originator:

 Description:  Space-vector PWM generation based on ABC components                    

=====================================================================================
 History:
-------------------------------------------------------------------------------------
2008-08-22 Version 0.1   create
 2009-5-1 Version 1.0 
-------------------------------------------------------------------------------------*/

#include "IQmathLib.h"         // Include header for IQmath library 
// Don't forget to set a proper GLOBAL_Q in "IQmathLib.h" file
#include "SVGen.h"
#include "Spi.h"
#include "corecontrol.h"
unsigned char pwmcpcnt,pwmcncnt,pwmapcnt,pwmancnt,pwmbpcnt,pwmbncnt;
_iq vat,vbt,vct,vat2,vbt2,vct2,va2,vb2,vc2;
#pragma CODE_SECTION(svgen_calc, "ramfuncs");

void svgen_calc(SVGEN *v) //park�任����
{	
	_iq Va,Vb,Vc,va1,vb1,vc1;
#if DEBUGMODE == 0
	InputSignal.UdcP=_IQ(1);
	InputSignal.UdcN=_IQ(1);
#endif
																	
// Inverse clarke transformation

	v->Ta = v->Ualpha;
	v->Tb = _IQmpy(_IQ(-0.5),v->Ualpha) + _IQmpy(_IQ(0.86602540378443864676372317075294),v->Ubeta);  // 0.8660254 = sqrt(3)/2
	v->Tc = _IQmpy(_IQ(-0.5),v->Ualpha) - _IQmpy(_IQ(0.86602540378443864676372317075294),v->Ubeta);  // 0.8660254 = sqrt(3)/2

	vat=v->Ta;
	vbt=v->Tb;
	vct=v->Tc;

	Va=_IQabs(v->Ta);
	Vb=_IQabs(v->Tb);
	Vc=_IQabs(v->Tc);


	if(v->Ta > 0)
		{
			pwmancnt=0;
			pwmapcnt++;
			if(pwmapcnt>=2)
			{
	//			objPWMDrv.Force_HIpwm2 =0;
				GpioDataRegs.GPACLEAR.bit.GPIO17 = 1;				//A��������
				va2=_IQdiv(Va,InputSignal.UdcP);
				//va2=_IQdiv(Va,_IQ(1.0));
			}
		}
		else
		{
			pwmapcnt=0;
			pwmancnt++;
			if(pwmancnt>=2)
			{
		//		objPWMDrv.Force_HIpwm2 =0;
				GpioDataRegs.GPASET.bit.GPIO17 = 1;					//A�ฺ����
				va2=_IQdiv(Va,InputSignal.UdcN);
			//	va2=_IQdiv(Va,_IQ(1.0));
			}
		}
	//---------------------------------------------------------------------------	//B�෢��
		if(v->Tb > 0)
		{
			pwmbncnt=0;
			pwmbpcnt++;
			if(pwmbpcnt>=2)
			{
			//	objPWMDrv.Force_HIpwm3 =0;
				GpioDataRegs.GPACLEAR.bit.GPIO18 = 1;				//B��������
				vb2=_IQdiv(Vb,InputSignal.UdcP);
			//	vb2=_IQdiv(Vb,_IQ(1.0));
			}
		}
		else
		{
			pwmbpcnt=0;
			pwmbncnt++;
			if(pwmbncnt>=2)
			{
			//	objPWMDrv.Force_HIpwm3 =0;
				GpioDataRegs.GPASET.bit.GPIO18 = 1;					//B�ฺ����
				vb2=_IQdiv(Vb,InputSignal.UdcN);
			//	vb2=_IQdiv(Vb,_IQ(1.0));
			}
		}
	//---------------------------------------------------------------------------	//C�෢��
		if(v->Tc > 0)
		{
			pwmcncnt=0;
			pwmcpcnt++;
			if(pwmcpcnt>=2)
			{
		//		objPWMDrv.Force_HIpwm4 =0;
				GpioDataRegs.GPACLEAR.bit.GPIO19 = 1;				//C��������

				vc2=_IQdiv(Vc,InputSignal.UdcP);
			//	vc2=_IQdiv(Vc,_IQ(1.0));
			}
		}
		else
		{
			pwmcpcnt=0;
			pwmcncnt++;
			if(pwmcncnt>=2)
			{
			//	objPWMDrv.Force_HIpwm4 =0;
				GpioDataRegs.GPASET.bit.GPIO19 = 1;					//C�ฺ����

				vc2=_IQdiv(Vc,InputSignal.UdcN);
			//	vc2=_IQdiv(Vc,_IQ(1.0));
			}
		}
	//	vat2=va2;
	//	vbt2=vb2;
		//vct2=vc2;
		va1=_IQ18mpy((va2>>3),_IQ18(4167));
		vb1=_IQ18mpy((vb2>>3),_IQ18(4167));
		vc1=_IQ18mpy((vc2>>3),_IQ18(4167));

		va1=va1>>18;
		vb1=vb1>>18;
		vc1=vc1>>18;
		if(va1>4067) va1=4067;
		else if(va1<20) va1=20;
		if(vb1>4067) vb1=4067;
		else if(vb1<20) vb1=20;
		if(vc1>4067) vc1=4067;
		else if(vc1<20) vc1=20;


		EPwm2Regs.CMPA.half.CMPA = va1;				//A��S1������
		EPwm3Regs.CMPA.half.CMPA = vb1;				//B��S1������
		EPwm4Regs.CMPA.half.CMPA = vc1;				//C��S1������
		/*BitSignalout1.bit.bZeroStateA=0;
		BitSignalout1.bit.bZeroStateB=0;
	    BitSignalout1.bit.bZeroStateC=0;
		if(va1<150)
		{
			BitSignalout1.bit.bZeroStateA = 1;
		}

		if(vb1<150)
		{
			BitSignalout1.bit.bZeroStateB = 1;
		}

		if(vc1<150)
		{
			BitSignalout1.bit.bZeroStateC= 1;
		}*/
		BitSignalout1.bit.bZeroStateA=1;
		BitSignalout1.bit.bZeroStateB=1;
		BitSignalout1.bit.bZeroStateC=1;


}

