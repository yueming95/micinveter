-- Header Begin
--
-- Generate 2M clock
--
-- Wang zhihua
-- Last Updated 01/27/2007
--
-- Header End

LIBRARY IEEE;
USE ieee.STD_LOGIC_ARITH.all;
USE ieee.std_logic_1164.all;
use IEEE.STD_LOGIC_UNSIGNED.ALL;


ENTITY clock_driver IS
PORT(
		clk			:in std_logic;--input 10MHz clock 
		reset			:in std_logic;--input reset signal
		clkout		:out std_logic--output 2MHz diver clock
);
END clock_driver;

ARCHITECTURE RTL1 OF clock_driver IS 

	signal clk_temp :std_logic;

BEGIN

	clkout<=clk_temp;

	process(clk,reset)
	variable count0: integer range 0 to 6;
	begin
		if reset='0' then
			count0:=0;
			clk_temp<='0';
		elsif rising_edge(clk) then
			count0:=count0+1;
			if count0=5 then
				count0:=0;
			end if;
			
			if count0=3 then
				clk_temp<='1';
			end if;
			
			if count0=0 then
				clk_temp<='0';
			end if;
			
		end if;
	end process;

END RTL1;