################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
App/Classes/template.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWADC/App/Classes/template.cpp $(GEN_OPTS) $(GEN_HDRS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -O3 --include_path="C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" --include_path="C:/ti/xdais_7_21_01_07/packages/ti/xdais" -g --define="_DEBUG" --define="LARGE_MODEL" --quiet --display_error_number --diag_wrap=off --preproc_with_compile --preproc_dependency="App/Classes/template.pp" --obj_directory="App/Classes" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: $<'
	@echo ' '


