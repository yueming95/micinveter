@echo off
echo 'Building file: E:/work/SG50KT4WA/program/SG50KTWAAC_two/source/DSP280x_SysCtrl.c'
