/*############################################################
//
// FILE:	F2808.cmd
//
// TITLE:	Linker Command File For F2808 Device
//
//############################################################
// Running on TMS320LF2808A
// External clock is 50MHz, PLL * 4/2 , CPU-Clock 100 MHz
// Date:  Nov 1, 2005
//###########################################################*/

/* ======================================================
// For Code Composer Studio V2.2 and later
// ---------------------------------------
// In addition to this memory linker cmd file, add the header linker cmd file directly to the pjt.
// The header linker command file is required to link the peripheral structures to the proper
// locations within the memory map.
//
// The header linker files are found in <base>\DSP280x_Headers\cmd
//
// For BIOS applications add:      DSP280x_Headers_BIOS.cmd
// For nonBIOS applications add:   DSP280x_Headers_nonBIOS.cmd
========================================================= */


/* Define the memory block start/length for the F2808
   PAGE 0 will be used to organize program sections
   PAGE 1 will be used to organize data sections

   Notes:
         Memory blocks on F2808 are uniform (ie same physical memory) in both PAGE 0 and PAGE 1.
         That is the same memory region should not be defined for both PAGE 0 and PAGE 1.
         Doing so will result in corruption of program and/or data.

         L0/L1 and H0 memory blocks are mirrored - can be accessed in high memory or low memory.
         For simplicity only one instance is used in this linker file.

         Contiguous SARAM memory blocks or flash sectors can be be combined if required to create
         a larger memory block.
*/

MEMORY
{
PAGE 0:    /* Program Memory */
           /* Memory (RAM/FLASH/OTP) blocks can be moved to PAGE1 for data allocation */

   RAML0		: origin = 0x008000, length = 0x001BE0     /* on-chip RAM block L0 7K */
   RAML1		: origin = 0x009BE0, length = 0x000020     /* on-chip RAM block L0 32words */
   OTP         	: origin = 0x3D7800, length = 0x000800     /* on-chip OTP 		  1k */
   FLASHBCD	: origin = 0x3E8000, length = 0x00BFFC     /* on-chip FLASH        48K-2-1*/
   FLASHNORMAL	: origin = 0x3F3FFC, length = 0x000002    /* on-chip FLASH        2, sepical for normal main boot*/
   FLASHFLAG	: origin = 0x3F3FFF, length = 0x000001    /* on-chip FLASH        1, sepical for flashupdate flag*/  
   FLASHA	: origin = 0x3F4000, length = 0x003F80     /* on-chip FLASH        16K-118, sepical for flashupdate*/   
   CSM_RSVD	: origin = 0x3F7F80, length = 0x000076     /* Part of FLASHA.  Program with all 0x0000 when CSM is in use. */
   BEGIN		: origin = 0x3F7FF6, length = 0x000002     /* Part of FLASHA.  Used for "boot to Flash" bootloader mode. */
   CSM_PWL	: origin = 0x3F7FF8, length = 0x000008     /* Part of FLASHA.  CSM password locations in FLASHA */

   ROM		: origin = 0x3FF000, length = 0x000FC0     /* Boot ROM */
   RESET		: origin = 0x3FFFC0, length = 0x000002     /* part of boot ROM  */
   VECTORS	: origin = 0x3FFFC2, length = 0x00003E     /* part of boot ROM  */

PAGE 1 :   /* Data Memory */
           /* Memory (RAM/FLASH/OTP) blocks can be moved to PAGE0 for program allocation */
           /* Registers remain on PAGE1                                                  */
/*USER*/
   RAMM0       : origin = 0x000000, length = 0x000400     /* on-chip RAM block M0 1K*/
   RAMM1       : origin = 0x000400, length = 0x000400     /* on-chip RAM block M1 1K*/
   RAMH0       : origin = 0x009C00, length = 0x001BF8    /* on-chip RAM block H0 7K-8*/
   RAMH1       : origin = 0x00B7F8, length = 0x000002     /* on-chip RAM block H1 8word*/
   RAMH2       : origin = 0x00B7FA, length = 0x000002 
   RAMH3       : origin = 0x00B7FC, length = 0x000002 
   RAMH4       : origin = 0x00B7FE, length = 0x000002 
   RAMFLASH	   : origin = 0x00B800, length = 0x000800 	/* on-chip RAM block 2K, sepical for flashupdate*/
 
/*REGISTER*/
   DEV_EMU     : origin = 0x000880, length = 0x000180     /* device emulation registers */
   FLASH_REGS  : origin = 0x000A80, length = 0x000060     /* FLASH registers */
   CSM         : origin = 0x000AE0, length = 0x000010     /* code security module registers */

   ADC_MIRROR  : origin = 0x000B00, length = 0x000010     /* ADC Results register mirror */

   CPU_TIMER0  : origin = 0x000C00, length = 0x000008     /* CPU Timer0 registers */
   CPU_TIMER1  : origin = 0x000C08, length = 0x000008     /* CPU Timer0 registers (CPU Timer1 & Timer2 reserved TI use)*/
   CPU_TIMER2  : origin = 0x000C10, length = 0x000008     /* CPU Timer0 registers (CPU Timer1 & Timer2 reserved TI use)*/

   PIE_CTRL    : origin = 0x000CE0, length = 0x000020     /* PIE control registers */
   PIE_VECT    : origin = 0x000D00, length = 0x000100     /* PIE Vector Table */

   ECANA       : origin = 0x006000, length = 0x000040     /* eCAN-A control and status registers */
   ECANA_LAM   : origin = 0x006040, length = 0x000040     /* eCAN-A local acceptance masks */
   ECANA_MOTS  : origin = 0x006080, length = 0x000040     /* eCAN-A message object time stamps */
   ECANA_MOTO  : origin = 0x0060C0, length = 0x000040     /* eCAN-A object time-out registers */
   ECANA_MBOX  : origin = 0x006100, length = 0x000100     /* eCAN-A mailboxes */

   ECANB       : origin = 0x006200, length = 0x000040     /* eCAN-B control and status registers */
   ECANB_LAM   : origin = 0x006240, length = 0x000040     /* eCAN-B local acceptance masks */
   ECANB_MOTS  : origin = 0x006280, length = 0x000040     /* eCAN-B message object time stamps */
   ECANB_MOTO  : origin = 0x0062C0, length = 0x000040     /* eCAN-B object time-out registers */
   ECANB_MBOX  : origin = 0x006300, length = 0x000100     /* eCAN-B mailboxes */

   EPWM1       : origin = 0x006800, length = 0x000022     /* Enhanced PWM 1 registers */
   EPWM2       : origin = 0x006840, length = 0x000022     /* Enhanced PWM 2 registers */
   EPWM3       : origin = 0x006880, length = 0x000022     /* Enhanced PWM 3 registers */
   EPWM4       : origin = 0x0068C0, length = 0x000022     /* Enhanced PWM 4 registers */
   EPWM5       : origin = 0x006900, length = 0x000022     /* Enhanced PWM 5 registers */
   EPWM6       : origin = 0x006940, length = 0x000022     /* Enhanced PWM 6 registers */

   ECAP1       : origin = 0x006A00, length = 0x000020     /* Enhanced Capture 1 registers */
   ECAP2       : origin = 0x006A20, length = 0x000020     /* Enhanced Capture 2 registers */
   ECAP3       : origin = 0x006A40, length = 0x000020     /* Enhanced Capture 3 registers */
   ECAP4       : origin = 0x006A60, length = 0x000020     /* Enhanced Capture 4 registers */

   EQEP1       : origin = 0x006B00, length = 0x000040     /* Enhanced QEP 1 registers */
   EQEP2       : origin = 0x006B40, length = 0x000040     /* Enhanced QEP 2 registers */

   GPIOCTRL    : origin = 0x006F80, length = 0x000040     /* GPIO control registers */
   GPIODAT     : origin = 0x006FC0, length = 0x000020     /* GPIO data registers */
   GPIOINT     : origin = 0x006FE0, length = 0x000020     /* GPIO interrupt/LPM registers */

   SYSTEM      : origin = 0x007010, length = 0x000020     /* System control registers */
   SPIA        : origin = 0x007040, length = 0x000010     /* SPI-A registers */
   SCIA        : origin = 0x007050, length = 0x000010     /* SCI-A registers */
   XINTRUPT    : origin = 0x007070, length = 0x000010     /* external interrupt registers */

   ADC         : origin = 0x007100, length = 0x000020     /* ADC registers */
   SPIB        : origin = 0x007740, length = 0x000010     /* SPI-B registers */

   SCIB        : origin = 0x007750, length = 0x000010     /* SCI-B registers */
   SPIC        : origin = 0x007760, length = 0x000010     /* SPI-C registers */

   SPID        : origin = 0x007780, length = 0x000010     /* SPI-D registers */

   I2CA        : origin = 0x007900, length = 0x000040     /* I2C-A registers */

 /*  CSM_PWL     : origin = 0x3F7FF8, length = 0x000008      Part of FLASHA.  CSM password locations. */
}

/* Allocate sections to memory blocks.
   Note:
         codestart user defined section in DSP28_CodeStartBranch.asm used to redirect code
                   execution when booting to flash
         ramfuncs  user defined section to store functions that will be copied from Flash into RAM
*/

SECTIONS
{

   /* Allocate program areas: */
   .cinit              : > FLASHBCD      PAGE = 0
   .pinit              : > FLASHBCD,     PAGE = 0
   .text               : > FLASHBCD      PAGE = 0
   codestart           : > BEGIN       PAGE = 0  
   Flash28Funcs	: > FLASHA	 PAGE = 0 
   normalfuncs		: > FLASHNORMAL	PAGE = 0 
   
   ramfuncs            : LOAD = FLASHBCD,
                         RUN = RAML1,
                         LOAD_START(_RamfuncsLoadStart),
                         LOAD_END(_RamfuncsLoadEnd),
                         RUN_START(_RamfuncsRunStart),
                         PAGE = 0
         
  UNION:  RUN = RAML0 
  {
       Epwm1Funcs         :  LOAD = FLASHBCD,                            
                             LOAD_START(_Epwm1FuncsLoadStart),
                             LOAD_END(_Epwm1FuncsLoadEnd),
                             RUN_START(_Epwm1FuncsRunStart),
                             PAGE = 0
                             
	Flash28_API:
	{
	-lFlash2808_API_V300.lib(.econst) 
	-lFlash2808_API_V300.lib(.text)
	} LOAD = FLASHA,  	
	LOAD_START(_Flash28_API_LoadStart),
	LOAD_END(_Flash28_API_LoadEnd),
	RUN_START(_Flash28_API_RunStart),
	PAGE = 0
  }

   csmpasswds          : > CSM_PWL,     PAGE = 0
   csm_rsvd            : > CSM_RSVD    PAGE = 0

   CsmPwlFile         : > CSM_PWL,     PAGE = 0

   /* Allocate uninitalized data sections: */
   .stack              : > RAMM0       PAGE = 1
   .ebss               : > RAMH0       PAGE = 1
   .esysmem            : > RAMH0       PAGE = 1
   .datafixed1          : > RAMH1       PAGE = 1
   .datafixed2          : > RAMH2       PAGE = 1
   .datafixed3          : > RAMH3       PAGE = 1
   .datafixed4          : > RAMH4       PAGE = 1
     
  /*allocate two sections in the same address*/
  UNION: > RAMFLASH       PAGE = 1
 {
	.laoadata 
	.flashdata
 }
   /* Initalized sections go in Flash */
   /* For SDFlash to program these, they must be allocated to page 0 */
   .econst             : > FLASHBCD      PAGE = 0
   .switch             : > FLASHBCD      PAGE = 0

   /* .reset is a standard section used by the compiler.  It contains the */
   /* the address of the start of _c_int00 for C Code.   /*
   /* When using the boot ROM this section and the CPU vector */
   /* table is not needed.  Thus the default type is set here to  */
   /* DSECT  */
   .reset              : > RESET,      PAGE = 0, TYPE = DSECT
   vectors             : > VECTORS     PAGE = 0, TYPE = DSECT

  /*this code line must be the last line refer to flash in all sections definition*/
   flashflag		: > FLASHFLAG      PAGE = 0

/*REGISTER*/
   PieVectTableFile : > PIE_VECT,   PAGE = 1

/*** Peripheral Frame 0 Register Structures ***/
   DevEmuRegsFile    : > DEV_EMU,     PAGE = 1
   FlashRegsFile     : > FLASH_REGS,  PAGE = 1
   CsmRegsFile       : > CSM,         PAGE = 1
   AdcMirrorFile     : > ADC_MIRROR,  PAGE = 1
   CpuTimer0RegsFile : > CPU_TIMER0,  PAGE = 1
   CpuTimer1RegsFile : > CPU_TIMER1,  PAGE = 1
   CpuTimer2RegsFile : > CPU_TIMER2,  PAGE = 1
   PieCtrlRegsFile   : > PIE_CTRL,    PAGE = 1

/*** Peripheral Frame 1 Register Structures ***/
   SysCtrlRegsFile   : > SYSTEM,      PAGE = 1
   SpiaRegsFile      : > SPIA,        PAGE = 1
   SciaRegsFile      : > SCIA,        PAGE = 1
   XIntruptRegsFile  : > XINTRUPT,    PAGE = 1
   AdcRegsFile       : > ADC,         PAGE = 1
   SpibRegsFile      : > SPIB,        PAGE = 1
   ScibRegsFile      : > SCIB,        PAGE = 1
   SpicRegsFile      : > SPIC,        PAGE = 1
   SpidRegsFile      : > SPID,        PAGE = 1
   I2caRegsFile      : > I2CA,        PAGE = 1

/*** Peripheral Frame 2 Register Structures ***/
   ECanaRegsFile     : > ECANA,       PAGE = 1
   ECanaLAMRegsFile  : > ECANA_LAM    PAGE = 1
   ECanaMboxesFile   : > ECANA_MBOX   PAGE = 1
   ECanaMOTSRegsFile : > ECANA_MOTS   PAGE = 1
   ECanaMOTORegsFile : > ECANA_MOTO   PAGE = 1

   ECanbRegsFile     : > ECANB,       PAGE = 1
   ECanbLAMRegsFile  : > ECANB_LAM    PAGE = 1
   ECanbMboxesFile   : > ECANB_MBOX   PAGE = 1
   ECanbMOTSRegsFile : > ECANB_MOTS   PAGE = 1
   ECanbMOTORegsFile : > ECANB_MOTO   PAGE = 1

   EPwm1RegsFile     : > EPWM1        PAGE = 1
   EPwm2RegsFile     : > EPWM2        PAGE = 1
   EPwm3RegsFile     : > EPWM3        PAGE = 1
   EPwm4RegsFile     : > EPWM4        PAGE = 1
   EPwm5RegsFile     : > EPWM5        PAGE = 1
   EPwm6RegsFile     : > EPWM6        PAGE = 1

   ECap1RegsFile     : > ECAP1        PAGE = 1
   ECap2RegsFile     : > ECAP2        PAGE = 1
   ECap3RegsFile     : > ECAP3        PAGE = 1
   ECap4RegsFile     : > ECAP4        PAGE = 1

   EQep1RegsFile     : > EQEP1        PAGE = 1
   EQep2RegsFile     : > EQEP2        PAGE = 1

   GpioCtrlRegsFile  : > GPIOCTRL     PAGE = 1
   GpioDataRegsFile  : > GPIODAT      PAGE = 1
   GpioIntRegsFile   : > GPIOINT      PAGE = 1


/*** Code Security Module Register Structures ***/
/*   CsmPwlFile        : > CSM_PWL,     PAGE = 1*/
}

/*
//===========================================================================
// End of file.
//===========================================================================
*/

