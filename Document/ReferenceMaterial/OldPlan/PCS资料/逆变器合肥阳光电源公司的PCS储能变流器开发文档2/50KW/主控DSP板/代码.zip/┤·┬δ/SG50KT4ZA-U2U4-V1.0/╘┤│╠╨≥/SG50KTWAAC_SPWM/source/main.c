#include "DSP280x_Device.h"     // Headerfile Include File
#include "DSP280x_Examples.h"   // Examples Include File
#include "IQmathLib.h"
#include "corecontrol.h"
#include "can.h"
#include "SVGen.h"
#include "Spi.h"
#include "Pid.h"
extern SVGEN svgen;
extern _iq vat,vbt,vct,vat2,vbt2,vct2;
#pragma CODE_SECTION(EPWM1_INT_ISR, "ramfuncs");
void Initial();
void main()
{
	DINT;
	InitSysCtrl();
	MemCopy(&RamfuncsLoadStart,&RamfuncsLoadEnd,&RamfuncsRunStart);//���Ƶ�RAM
    MemCopy(&IQmathLoadStart, &IQmathLoadEnd, &IQmathRunStart);			//����IQmath�⵽RAM
    InitFlash();
	InitPieCtrl();
	InitPieVectTable();
	InitGpio();
	IER = 0x0000;
    IFR = 0x0000;
	EnableInterrupts();
	Drv_ADInit();
//	InitEPwmGpio();
	InitEPwm();
	InitSpi();
	InitECan();
	Drv_ADAdjust();
    EINT;   // ʹ��ȫ���ж�INTM
    ERTM;   // ʹ��ȫ��ʵʱ�ж�
	Initial();
	while(1)
	{
		SPI_ACT();
		DigitalOper();
	}
}

interrupt void EPWM1_INT_ISR(void)
{
	Drv_Int_Sampling1Data();
	ProtectFun();
	CPMsgSend();
	#if DEBUGMODE == 0
	Drv_PWMActive();
//	BitSignal.bit.bInvKM=1;
	#else
	StateFun();
	#endif
	Alg_Int_AgingRptReg();
	Drv_Int_Sampling2Data();
	GridControl();
	Debugcode();
	EPwm1Regs.ETCLR.bit.INT = 1;                    		// Clear INT flag for this timer
	PieCtrlRegs.PIEACK.all = PIEACK_GROUP3;         		// Acknowledge this interrupt to receive more interrupts from group 3
}
void Initial()
{
	ProtectRegs.all=0;
	ProtectIn.all=0;
	StateRegs.all=0;
	ProtectCnt.UdcL=0; ProtectCnt.UdcH=0; ProtectCnt.UgH=0; ProtectCnt.UgL=0; 
	ProtectCnt.IGBT=0; ProtectCnt.Udcbalance=0;  ProtectCnt.IgHH=0;
	ProtectCnt.FreqH=ProtectCnt.FreqL=0;										//hf add
	Krpt=_IQ(0.06103515625);//_IQ(0.06103515625);
	BitSignal.bit.bInvKM=0;
	SysCnt.InvOff=TM3S;

	InputSignal.UoutDF=0;
	InputSignal.IgDF=0;
	PllRegs.Pwgfilter=0;
//+++++++++Pll+++++++++++++++++++++++++++++++++++++++//
	PllRegs.Kp=_IQ(0.3);
	PllRegs.PKi1=_IQ(0.0000833333);
	PllRegs.PKi2=_IQ(0.010666666666666666666666666666667);
//+++++++++PID++++++++++++++++++++++++++++++++++++++++++++++//
    DPid.Kp = _IQ(1.5);//_IQ21(2.0);
    DPid.Kc = _IQ(0.0015);//_IQ21(0.0015);
    DPid.Ki = _IQ(0.0015);
	DPid.OutMax = _IQ(300);
	DPid.OutMin = _IQ(-300);
    QPid.Kp = _IQ(1.5);//_IQ21(3.5);
    QPid.Kc = _IQ(0.0015);
    QPid.Ki = _IQ(0.0015);//_IQ21(0.1);
	QPid.OutMax = _IQ(300);
	QPid.OutMin = _IQ(-300);
	RptUd = 0;
	RptUq = 0;	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++//
	SysCnt.StartCheck=0;
	SysCnt.Binv3cnt=0;
	SysCnt.StartCnt=0;
}
unsigned char laoaindex;
unsigned char Display=1;
_iq buf1[60],buf2[60],buf3[60];
extern _iq Ubus,Ubusf;
void Debugcode()  //���Դ���
{
	SysCnt.CycleCnt++;
	if(SysCnt.CycleCnt>=240) SysCnt.CycleCnt=0;
	if(SysCnt.CycleCnt%4==0) 
	{
		laoaindex++;
		if(laoaindex>=60) laoaindex=0;
		if(Display==1)
		{
			buf1[laoaindex] =InputSignal.Uinva;		//InputSignal.Uouta;//InputSignal.Iga;//
			buf2[laoaindex] =InputSignal.Uinvb;		//InputSignal.Uoutb;//InputSignal.Igb;//InputSignal.Ig3;
			buf3[laoaindex] =InputSignal.Uinvc ;//InputSignal.Ig3;
		}else if(Display==2)
		{
			buf1[laoaindex] =vat2;//objInverter.m_i16Ila_0;//
			buf2[laoaindex] =vbt2;//InputSignal.Ig3;
			buf3[laoaindex] =vct2;//InputSignal.Ig3;
		}else
		{
			buf1[laoaindex] =EPwm2Regs.CMPA.half.CMPA;//	AI.Uoutab;	 //EPwm1Regs.CMPA.half.CMPA;//InputSignal.Uinva;//
			buf2[laoaindex] =EPwm3Regs.CMPA.half.CMPA;	//	EPwm2Regs.CMPA.half.CMPA;// InputSignal.UdcN;//InputSignal.Ig3;
			buf3[laoaindex] =EPwm4Regs.CMPA.half.CMPA;//=InputSignal.Uoutc;	//		EPwm3Regs.CMPA.half.CMPA;// InputSignal.UdcP;//InputSignal.Ig3;
		}
	}
}

