#define can_GLOBALS
#include "can.h"
#include "corecontrol.h"
#pragma CODE_SECTION(CanDataPack, "ramfuncs");
#pragma CODE_SECTION(CPMsgSend, "ramfuncs");
//============================================================================================
//��������:  CP_UserInit()
//��           ��:  
//��   	      ��:  
//��           ��:  CP�û������ĳ�ʼ������
//ע           ��:  
//============================================================================================
//extern unsigned char abcde,abcdefg;
//unsigned char abcd001;
//=============================================================================================
//��������:  void CPMsgSend(Uint16 index)
//��           ��:  sort:�������ͣ�index:����������
//��           ��:  void
//��           ��:  ��������Ա��Ķ���
//ע           ��:  
//=============================================================================================
void CanDataPack()
{
	Uint16 temp;	
	InterfaceCan.SendL.all=ProtectRegs.all;
	temp=StateRegs.all;
	InterfaceCan.SendH.bit.Lbit=temp;
	temp=_IQmpy(InputSignal.UoutDF,_IQ(0.7072135785))>>21;
	InterfaceCan.SendL1.bit.Lbit=temp;
	temp=_IQmpy(InputSignal.IgDF,_IQ(7.072135785))>>21;
	InterfaceCan.SendL1.bit.Hbit=temp;
}
void CPMsgSend()
{
	struct ECAN_REGS ECanaShadow;
	struct ECAN_REGS ECanbShadow;
	CanSendTime++;
	if(CanSendTime>=120)   // 10 ms
	{
	    CanSendTime=0;
		CanDataPack();
	//============������Ϣ===========================
		ECanaShadow.CANRMP.all = ECanaRegs.CANRMP.all;
		if (ECanaShadow.CANRMP.bit.RMP2 == 1)			//���յ���Ϣ
		{
			InterfaceCan.RdatL.all = ECanaMboxes.MBOX2.MDL.all;      
			InterfaceCan.RdatH.all = ECanaMboxes.MBOX2.MDH.all;
			ECanaShadow.CANRMP.bit.RMP2 = 1;
			ECanaRegs.CANRMP.all = ECanaShadow.CANRMP.all;
		}
//================������Ϣ����---------------------------
		if((InterfaceCan.RdatL.bit.Hbit & 0x0001)>0)
		{
			SysFlag.bit.Open=0;
		}else
		{
			SysFlag.bit.Open=1;
		}
		if((InterfaceCan.RdatL.bit.Hbit & 0x0002)>0)
		{
			SysFlag.bit.Reset=1;
		}else
		{
			SysFlag.bit.Reset=0;
		}
	//=============������Ϣ=============================
		ECanaMboxes.MBOX1.MDL.all = InterfaceCan.SendL.all;// & 0xffffff00)|CANHEAD; //CANHEAD���ڽ��շ�У���Ƿ��ܵ�������ȷ����
		ECanaMboxes.MBOX1.MDH.all=InterfaceCan.SendH.all;
		ECanaMboxes.MBOX3.MDL.all = InterfaceCan.SendL1.all;// & 0xffffff00)|CANHEAD; //CANHEAD���ڽ��շ�У���Ƿ��ܵ�������ȷ����
		ECanaMboxes.MBOX3.MDH.all=InterfaceCan.SendH1.all;
		ECanaShadow.CANTRS.all = ECanaRegs.CANTRS.all;
		ECanaShadow.CANTRS.bit.TRS1=1;
		ECanaShadow.CANTRS.bit.TRS3=1;
		ECanaRegs.CANTRS.all = ECanaShadow.CANTRS.all;
		if (ECanaShadow.CANTA.bit.TA1 == 1)	//���ͳɹ�
		{		
			ECanaShadow.CANTA.bit.TA1 = 1;
			ECanaRegs.CANTA.all = ECanaShadow.CANTA.all;
		}
		if (ECanaShadow.CANTA.bit.TA3 == 1)	//���ͳɹ�
		{		
			ECanaShadow.CANTA.bit.TA3 = 1;
			ECanaRegs.CANTA.all = ECanaShadow.CANTA.all;
		}
	}
//===================canb powercan================================
	if ( ECanbRegs.CANES.bit.BO != 0 ) 
	{
		EALLOW;
		ECanbRegs.CANMC.bit.ABO = 1;
		EDIS;
	}
	ECanbShadow.CANRMP.all = ECanbRegs.CANRMP.all;
	if (ECanbShadow.CANRMP.bit.RMP9 == 1)			//���յ���Ϣ
	{
		InterfaceCan.RdatL1.all = ECanbMboxes.MBOX9.MDL.all;
		InterfaceCan.RdatH1.all = ECanbMboxes.MBOX9.MDH.all;
		ECanbShadow.CANRMP.bit.RMP9 = 1;
		ECanbRegs.CANRMP.all = ECanbShadow.CANRMP.all;
	}
//================================================================
}

