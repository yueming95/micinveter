/***************************************************************************************
* 
* Filename: 		SysCanHal.cpp
* Contributor:
* Author: 		Wang Zhihua	
* Date: 			1/21/2008
* Copyright 		2008 ENPC Corporation, All Rights Reserved
*
* Description: 	This module definite HAL(hardware abstraction layer) between CAN controller and 
*			CAN protocol Layer.
*				HAL provide methods to receive CAN message and transmit CAN message. These 
*			is achieved by interrupt mode
*
* 
* Version			0
* Last rev by:		Wang Zhihua
* Last rev date:	1/21/2008
* Last rev desc:	
****************************************************************************************/

//---------------------------------------------------------------
//Include header


//--------------------------------------------------------------------------------
//Private Enumerated and macro Definitions
	
//-------------------------------------------------------------------------------
//Private Structure and Const variable defintion

//--------------------------------------------------------------------------------
//public variable

//--------------------------------------------------------------------------------
//private  function

//--------------------------------------------------------------------------------
//function definiton
