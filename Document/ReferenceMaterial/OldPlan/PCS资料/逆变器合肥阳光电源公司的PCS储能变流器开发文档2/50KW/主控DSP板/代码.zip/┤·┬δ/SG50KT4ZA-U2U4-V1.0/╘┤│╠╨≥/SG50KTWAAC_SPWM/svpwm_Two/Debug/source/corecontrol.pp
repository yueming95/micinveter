# FIXED

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/corecontrol.c
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/corecontrol.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Device.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Adc.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DevEmu.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_CpuTimers.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECan.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECap.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EPwm.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EQep.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Gpio.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2c.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieCtrl.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieVect.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Spi.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Sci.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_SysCtrl.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_XIntrupt.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/IQmathLib.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/SVGen.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Pid.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Spi.h
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug/corecontrol.obj: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/can.h

E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/source/corecontrol.c: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/corecontrol.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Device.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Adc.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_DevEmu.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_CpuTimers.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECan.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_ECap.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EPwm.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_EQep.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Gpio.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_I2c.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieCtrl.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_PieVect.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Spi.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_Sci.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_SysCtrl.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/DSP280x_XIntrupt.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/IQmathLib.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/SVGen.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Pid.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/Spi.h: 
E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/include/can.h: 
