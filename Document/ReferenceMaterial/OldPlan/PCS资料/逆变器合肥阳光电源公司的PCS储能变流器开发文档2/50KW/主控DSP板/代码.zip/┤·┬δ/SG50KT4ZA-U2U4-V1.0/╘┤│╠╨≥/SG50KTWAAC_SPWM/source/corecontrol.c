#define corecontrol_GLOBALS
#include "corecontrol.h"
#include "SVGen.h"
#include "Pid.h"
#include "Spi.h"
#include "can.h"
SVGEN svgen;
#pragma CODE_SECTION(GridControl, "ramfuncs");
#pragma CODE_SECTION(Alg_Int_AgingRptReg, "ramfuncs");
#pragma CODE_SECTION(ProtectFun, "ramfuncs");
#pragma CODE_SECTION(StateFun, "ramfuncs");
_iq VAlpha,VBeta;
_iq Ubus;
#if DEBUGMODE == 0
_iq thetawutiaojian;
#endif
void GridControl()
{
	_iq sintemp,costemp,tempr,temptheta;
	costemp=_IQcos(PllRegs.Theta);
	sintemp=_IQsin(PllRegs.Theta);
	InputSignal.UoutD = _IQmpy(_IQmpy(_2DIV3, costemp), InputSignal.Uouta) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) - _IQmpy(_1SQRT3, sintemp)), InputSignal.Uoutb) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) + _IQmpy(_1SQRT3, sintemp)), InputSignal.Uoutc);
	InputSignal.UoutQ = - _IQmpy(_IQmpy(_2DIV3, sintemp), InputSignal.Uouta) +
		  _IQmpy((_IQmpy(_1DIV3, sintemp) + _IQmpy(_1SQRT3, costemp)), InputSignal.Uoutb) +
		  _IQmpy((_IQmpy(_1DIV3, sintemp) - _IQmpy(_1SQRT3, costemp)), InputSignal.Uoutc);
//	IslandFun();

	InputSignal.UinvD = _IQmpy(_IQmpy(_2DIV3, costemp), InputSignal.Uinva) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) - _IQmpy(_1SQRT3, sintemp)), InputSignal.Uinvb) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) + _IQmpy(_1SQRT3, sintemp)), InputSignal.Uinvc);

	InputSignal.IgD = _IQmpy(_IQmpy(_2DIV3, costemp), InputSignal.Iga) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) - _IQmpy(_1SQRT3, sintemp)), InputSignal.Igb) -
		  _IQmpy((_IQmpy(_1DIV3, costemp) + _IQmpy(_1SQRT3, sintemp)), InputSignal.Igc);
	InputSignal.IgQ = - _IQmpy(_IQmpy(_2DIV3, sintemp), InputSignal.Iga) +
		  _IQmpy((_IQmpy(_1DIV3, sintemp) + _IQmpy(_1SQRT3, costemp)), InputSignal.Igb) +
		  _IQmpy((_IQmpy(_1DIV3, sintemp) - _IQmpy(_1SQRT3, costemp)), InputSignal.Igc);
//	DQtemp.Theta=IsTheta;
	InputSignal.UoutDF=_IQmpy(InputSignal.UoutDF,_IQ(0.999))+_IQmpy(InputSignal.UoutD,_IQ(0.001));
	InputSignal.IgDF=_IQmpy(InputSignal.IgDF,_IQ(0.999))+_IQmpy(InputSignal.IgD,_IQ(0.001));

	PllRegs.Pi1 += _IQmpy(PllRegs.PKi1, InputSignal.UoutQ);
	PllRegs.Pwg = _IQmpy(PllRegs.Kp, InputSignal.UoutQ) + PllRegs.Pi1;
	PllRegs.Pi2 += _IQmpy(PllRegs.PKi2 , PllRegs.Pwg);


	PllRegs.Pwgfilter=_IQmpy(PllRegs.Pwg,_IQ(0.01))+_IQmpy(PllRegs.Pwgfilter,_IQ(0.99));//hf add

	SysFlag.bit.CrossZero=0;
	if(PllRegs.Pi2>_IQ(804.24771931898706904643670611955))
	{
		PllRegs.Pi2 = PllRegs.Pi2-_IQ(804.24771931898706904643670611955);
		SysFlag.bit.CrossZero=1;
	}
	PllRegs.Theta = (PllRegs.Pi2>>7);
/**************************************/

	QPid.Tf=InputSignal.IgQ;
	QPid.Ref=0;
	PidCalc(&QPid);
	DPid.Tf=InputSignal.IgD;
	DPid.Ref=Id_Given;//Id_Given UoutQPid.Out;
	PidCalc(&DPid);
/****************************************/
	Ubus=InputSignal.UdcP+InputSignal.UdcN;
	Vd0=Udref+DPid.Out+RptUd;
	Vq0=Uqref+QPid.Out+RptUq;



/******************************************/
	VAlpha = _IQmpy(Vd0, costemp) - _IQmpy(Vq0, sintemp);
	VBeta = _IQmpy(Vd0, sintemp) + _IQmpy(Vq0, costemp);
#if DEBUGMODE == 0
	thetawutiaojian=thetawutiaojian+_IQ27(0.02617993877991494365385536152733);
	if(thetawutiaojian>=_IQ27(6.283185307179586476925286766559)) thetawutiaojian=_IQ(0);
	svgen.Ualpha = (_IQ27mpy(_IQ27(0.9), _IQ27cos(thetawutiaojian)))>>6;//VAlpha;
    svgen.Ubeta = (_IQ27mpy(_IQ27(0.9), _IQ27sin(thetawutiaojian)))>>6;//VBeta;
#else
	svgen.Ualpha = VAlpha;
	svgen.Ubeta = VBeta;
#endif
	svgen_calc(&svgen); 

}
void Alg_Int_AgingRptReg(void)
{
	_iq	temp1,temp2;

	temp1 = Id_Given-InputSignal.IgD;							// D�����
	IdErroF = _IQmpy(_IQ(0.125),temp1)+_IQmpy(_IQ(0.875),IdErroF);
	if(IdErroF>_IQ(20))
	{
		IdErroF=_IQ(20);
	}else if(IdErroF<_IQ(-20))
	{
		IdErroF=_IQ(-20);
	}
	temp2 = -InputSignal.IgQ;							// D�����
	IqErroF = _IQmpy(_IQ(0.125),temp2)+_IQmpy(_IQ(0.875),IqErroF);
	if(IqErroF>_IQ(20))
	{
		IqErroF=_IQ(20);
	}else if(IqErroF<_IQ(-20))
	{
		IqErroF=_IQ(-20);
	}

	if(SysCnt.Binv3cnt>=TM3S) //&& ( m_i16AgingIerrMd_0 >= -400) )  //���3���
	{
		CycleSave = CycleCnt-6;			//��ǰ��������,��λ����
		if(CycleSave < 0) 
		{
			CycleSave = CyclePoint+CycleSave;
		}
// �ظ����ƻ��ּ���
		IdRpt[CycleSave] =_IQmpy(IdRpt[CycleSave],_IQ(0.9765625))+IdErroF;
		IqRpt[CycleSave] = _IQmpy(IqRpt[CycleSave],_IQ(0.9765625))+IqErroF;
		if(IdRpt[CycleSave]>_IQ(300)) IdRpt[CycleSave]=_IQ(300);
		if(IdRpt[CycleSave]<_IQ(-300)) IdRpt[CycleSave]=_IQ(-300);
		if(IqRpt[CycleSave]>_IQ(300)) IqRpt[CycleSave]=_IQ(300);
		if(IqRpt[CycleSave]<_IQ(-300)) IqRpt[CycleSave]=_IQ(-300);

		// �ظ����Ʋ���������
		RptUd = _IQmpy(IdRpt[CycleCnt],Krpt);
		RptUq = _IQmpy(IqRpt[CycleCnt],Krpt); 

		CycleCnt++;
		if(CycleCnt > 250)	
		{
			CycleCnt = 250;
		}
	}
	else 
	{
		 RptUd = 0;
		 RptUq = 0;		
		 CycleCnt = 0;
		 CycleSave = 0;
		 IdErroF=0;
		 IqErroF=0;
		 tempAx = 499;
		 asm(" MOVL XAR4,#_IdRpt");
		 asm(" RPT @_tempAx || MOV *XAR4++,#0");    //��������

		 asm(" MOVL XAR4,#_IqRpt");
		 asm(" RPT @_tempAx || MOV *XAR4++,#0");
	} 
	Pointcnt++;
	if(SysFlag.bit.CrossZero==1)
	{
		CyclePoint=Pointcnt;
		if(CyclePoint>250) CyclePoint=250;
		if(CyclePoint<230) CyclePoint=230;
		Pointcnt=0;
		CycleCnt=0;
	}
}

void ProtectFun()
{

	if(SysCnt.StartCheck<TM5S)
	{
		SysCnt.StartCheck++;
		PllRegs.Pi1=_IQ(314.16);
		BitSignal.bit.bInvID=BitSignalin2.bit.bInvID;
	}
	ProtectIn.bit.UserStop=SysFlag.bit.Open;

	if(BitSignalin2.bit.bRev1==1)   // IGBT����
	{
		ProtectCnt.IGBT++;
		if(ProtectCnt.IGBT>=TM5MS)
		{
			ProtectIn.bit.IGBT=1;
			ProtectRegs.bit.IGBT=1;	
			ProtectCnt.IGBT=TM10S;
		}
	}else
	{
		ProtectCnt.IGBT--;
		if(ProtectCnt.IGBT<=1)
		{
			ProtectCnt.IGBT=1;
			ProtectIn.bit.IGBT=0;
		}	
	}

	if(BitSignalin2.bit.bOcp==1)   // Ӳ������
	{
		ProtectCnt.IgHH++;
		if(ProtectCnt.IgHH>=TM1MS)
		{
			ProtectIn.bit.IgHH=1;
			ProtectRegs.bit.IgHH=1;	
			ProtectCnt.IgHH=TM10S;
		}
	}else
	{
		ProtectCnt.IgHH--;
		if(ProtectCnt.IgHH<=1)
		{
			ProtectCnt.IgHH=1;
			ProtectIn.bit.IgHH=0;
		}	
	}

	if(BitSignalin3.bit.bRecOff==1)//&&(StateRegs.bit.binv>0))  // DC��ͣ��
	{
		ProtectIn.bit.DCstop=1;
		ProtectRegs.bit.DCstop=1;

	}else
	{
		ProtectIn.bit.DCstop=0;	
	}

/*	if(BitSignalin2.bit.bModuleReady==0)
	{
		ProtectIn.bit.bModuleReadyOk=1;
		ProtectRegs.bit.bModuleReadyOk=1;

	}else
	{
		ProtectIn.bit.bModuleReadyOk=0;	
	}*/

	if(InputSignal.UoutD<=_IQ(264.418))   // �311.08  85%  Ƿѹ
	{
		if(InputSignal.UoutD<=_IQ(155.54))    // 50%
		{
			ProtectCnt.UgL=ProtectCnt.UgL+20;
		}else
		{
			ProtectCnt.UgL++;
		}
		if(ProtectCnt.UgL>=TM1S)
		{
			ProtectIn.bit.UgL=1;
	    	ProtectRegs.bit.UgL=1;
			ProtectCnt.UgL=TM10S;
		}
	}else
	{
		ProtectCnt.UgL--;
		if(ProtectCnt.UgL<=1)
		{
			ProtectCnt.UgL=1;
			ProtectIn.bit.UgL=0;
		}	
	}

	if((InputSignal.UdcN>=_IQ(480))||(InputSignal.UdcP>=_IQ(480)))  // ĸ�߹�ѹ
	{
		ProtectCnt.UdcH++;
		if(ProtectCnt.UdcH>=TM1MS)
		{
			ProtectIn.bit.UdcH=1;
			ProtectRegs.bit.UdcH=1;
			ProtectCnt.UdcH=TM10S;
		}
	}else
	{
		ProtectCnt.UdcH--;
		if(ProtectCnt.UdcH<=1)
		{
			ProtectCnt.UdcH=1;
			ProtectIn.bit.UdcH=0;
		}	
	}


	if((InputSignal.IgAdd>=_IQ(5))||(InputSignal.IgAdd<=_IQ(-5)))   // ������ƽ��
	{
		ProtectCnt.Igbalance++;
		if(ProtectCnt.Igbalance>=TM100MS)
		{
			ProtectIn.bit.Igbalance=1;
			ProtectRegs.bit.Igbalance=1;
			ProtectCnt.Igbalance=TM10S;
		}
	}else
	{
		ProtectCnt.Igbalance--;
		if(ProtectCnt.Igbalance<=1)
		{
			ProtectCnt.Igbalance=1;
			ProtectIn.bit.Igbalance=0;
		}
	}

	if((InputSignal.IgQ>=_IQ(128))||(InputSignal.IgD>=_IQ(128)))  // �������
	{
		ProtectCnt.IgH++;
		if(ProtectCnt.IgH>=TM1MS)
		{
			ProtectIn.bit.IgH=1;
			ProtectRegs.bit.IgH=1;	
			ProtectCnt.IgH=TM10S;
		}
	}else
	{
		ProtectCnt.IgH--;
		if(ProtectCnt.IgH<=1)
		{
			ProtectCnt.IgH=1;
			ProtectIn.bit.IgH=0;
		}	
	}

	if((InputSignal.UdcN<=_IQ(300))||(InputSignal.UdcP<=_IQ(300)))  // ĸ��Ƿѹ
	{
		ProtectCnt.UdcL++;
		if(ProtectCnt.UdcL>=TM100MS)
		{
			ProtectIn.bit.UdcL=1;
			ProtectRegs.bit.UdcL=1;
			ProtectCnt.UdcL=TM10S;
		}
	}else
	{
		ProtectCnt.UdcL--;
		if(ProtectCnt.UdcL<=1)
		{
			ProtectCnt.UdcL=1;
			ProtectIn.bit.UdcL=0;
		}	
	}

	if(_IQabs(InputSignal.UdcN-InputSignal.UdcP)>=_IQ(10))	// ĸ�߲�ƽ��
	{
		ProtectCnt.Udcbalance++;
		if(ProtectCnt.Udcbalance>=TM1MS)
		{
			ProtectIn.bit.Udcbalance=1;
			ProtectRegs.bit.Udcbalance=1;
			ProtectCnt.Udcbalance=TM5S;
		}
	}else
	{
		ProtectCnt.Udcbalance--;
		if(ProtectCnt.Udcbalance<=1)
		{
			ProtectCnt.Udcbalance=1;
			ProtectIn.bit.Udcbalance=0;
		}	
	}
	if(_IQabs(InputSignal.IgD-InputSignal.IgdBark)>=_IQ(5))  // ����������
	{
		ProtectCnt.DetaIH++;
		if(ProtectCnt.DetaIH>=TM1MS)
		{
			ProtectIn.bit.DetaIH=1;
			ProtectRegs.bit.DetaIH=1;
			ProtectCnt.DetaIH=TM5S;
		}
	}else
	{
		ProtectCnt.DetaIH--;
		if(ProtectCnt.DetaIH<=1)
		{
			ProtectCnt.DetaIH=1;
			ProtectIn.bit.DetaIH=0;
		}
	}
	InputSignal.IgdBark=InputSignal.IgD;

	if(InputSignal.UoutD>=_IQ(357))    // ��ѹ  �311.08  110%  hf add  342.19
	{
		if(InputSignal.UoutD>=_IQ(419.96))    // 135%
		{
			ProtectCnt.UgH=ProtectCnt.UgH+40;//0.025s
		}else
		{
			ProtectCnt.UgH++;
		}
		if(ProtectCnt.UgH>=TM1S)
		{
			ProtectIn.bit.UgH=1;
			ProtectRegs.bit.UgH=1;
			ProtectCnt.UgH=TM10S;//?1S
		}
	}else
	{
		ProtectCnt.UgH--;
		if(ProtectCnt.UgH<=1)
		{
			ProtectCnt.UgH=1;
			ProtectIn.bit.UgH=0;
		}	
	}

		if(PllRegs.Pwgfilter<=_IQ(307)) //49.5    311.02       //  ǷƵ  hf add
		{
			if(PllRegs.Pwgfilter<=_IQ(301.59))//48
			{
				ProtectCnt.FreqL=ProtectCnt.FreqL+6000;//0.1S
			}else
			{
				ProtectCnt.FreqL++;
			}
			if(ProtectCnt.FreqL>=TM10min)
			{
				ProtectIn.bit.FreqL=1;
				ProtectRegs.bit.FreqL=1;
				ProtectCnt.FreqL=TM10min;
			}
		}else
		{
			ProtectCnt.FreqL--;
			if(ProtectCnt.FreqL<=1)
			{
				ProtectCnt.FreqL=1;
				ProtectIn.bit.FreqL=0;
			}
		}

	     if(PllRegs.Pwgfilter>_IQ(320)) //50.2   315.4       //  ��Ƶ hf add
		{
			if(PllRegs.Pwgfilter>_IQ(323.4))//_IQ(50.5)) 317.3
			{
				ProtectCnt.FreqH=ProtectCnt.FreqH+1200;//0.1S
			}else
			{
				ProtectCnt.FreqH++;
			}
			if(ProtectCnt.FreqH>=TM2min)
			{
				ProtectIn.bit.FreqH=1;
				ProtectRegs.bit.FreqH=1;
				ProtectCnt.FreqH=TM2min;
			}
		}else
		{
			ProtectCnt.FreqH--;
			if(ProtectCnt.FreqH<=1)
			{
				ProtectCnt.FreqH=1;
				ProtectIn.bit.FreqH=0;
			}
		}

	if(SysFlag.bit.Reset==1)
	{
		ProtectRegs.all=0;
		ProtectIn.all=(ProtectIn.all & 0x00010000);
	}

}

void StateFun()
{
		_iq temp;
	if((ProtectIn.all & 0x00027fff)>0)
	{
		StateRegs.bit.binv=0;
	}
	if((ProtectIn.all & 0x00018000)>0)
	{
		if(StateRegs.bit.binv==3)
		{
			StateRegs.bit.binv=2;
		}
		if(StateRegs.bit.binv==1)
		{
			StateRegs.bit.binv=0;
		}
	}
	if(StateRegs.bit.binv==2)
	{
		if(Id_Given>_IQ(0))
		{
			Id_Given-=_IQ(0.01);
			Udref=InputSignal.UoutD;
			Uqref=InputSignal.UoutQ;
		}else
		{
			StateRegs.bit.binv=0;
			Id_Given=_IQ(0);
		}
		
	}
//++++++++++++++++++++++++++++++++++++++++++++//
	if(StateRegs.bit.binv==0)
	{
		if(ProtectIn.all==0)
		{
			if(_IQabs(InputSignal.UdcP-InputSignal.UdcN)<=_IQ(20))
			{
				SysCnt.StartCnt++;
				if(SysCnt.StartCnt>=TM3S)
				{
					StateRegs.bit.binv=1;
					ProtectRegs.all=0;
					SysCnt.StartCnt=TM3S;
				}
			}else
			{
				ProtectRegs.bit.Udcbalance=1;
			}
		}else
		{
			SysCnt.StartCnt=0;
		}
		Drv_PWMInactive();
		//add code for var initial
		DPid.Pi=_IQ(0);
		QPid.Pi=_IQ(0);
		Id_Given=_IQ(0);
		ProtectCnt.Invfault=0;
		BitSignal.bit.bInvKM=0;
		InvStateCnt=0;
		Udref=0;
		Uqref=0;
		 RptUd = 0;
		 RptUq = 0;
		EPwm1Regs.CMPA.half.CMPA=0;
		EPwm2Regs.CMPA.half.CMPA=0;
		EPwm3Regs.CMPA.half.CMPA=0;
		EPwm4Regs.CMPA.half.CMPA=0;
		EPwm5Regs.CMPA.half.CMPA=0;
		EPwm6Regs.CMPA.half.CMPA=0;
		InvStateCnt=0;
		ProtectCnt.Invfault=0;
	}
//++++++++++++++++++++++++++++++++++++++++++++//
	if(StateRegs.bit.binv==1)
	{
		if(_IQabs(InputSignal.UoutD-InputSignal.UinvD)<=_IQ(10))
		{
			InvStateCnt++;
		}else
		{
			if(InvStateCnt>0)
			{
				InvStateCnt--;
			}
		}

		if(ProtectCnt.Invfault>=TM10S)
		{
			ProtectRegs.bit.Invfault=1;
			ProtectIn.bit.Invfault=1;
		}
		if(InvStateCnt>=TM1S)
		{
			StateRegs.bit.binv=3;		//zsc
			InvStateCnt=0;
			ProtectCnt.Invfault=0;
		}else
		{
			ProtectCnt.Invfault++;
		}
		if(InputSignal.UoutD>Udref)
		{
			Udref+=_IQ(0.006);
		}else if(InputSignal.UoutD<Udref)
		{
			Udref-=_IQ(0.006);
		}
		if(InputSignal.UoutQ>Uqref)
		{
			Uqref+=_IQ(0.003);
		}else if(InputSignal.UoutQ<Uqref)
		{
			Uqref-=_IQ(0.003);
		}
		DPid.Pi=_IQ(0);
		QPid.Pi=_IQ(0);
		Id_Given=_IQ(0);
		InterfaceCan.RdatL1.all=0;
		BitSignal.bit.bInvKM=0; 
		if(SysFlag.bit.CrossZero==1)
		{
			Drv_PWMActive();
		}
	}
//++++++++++++++++++++++++++++++++++++++++++++//
	if(StateRegs.bit.binv==3)
	{
		BitSignal.bit.bInvKM=1;
		Udref=InputSignal.UoutD;
		Uqref=InputSignal.UoutQ;
		SysCnt.Binv3cnt++;
		temp=InterfaceCan.RdatL1.all;
		Id_Given=(temp<<2);
		if(SysCnt.Binv3cnt>=TM5S)
		{
			SysCnt.Binv3cnt=TM5S;
	//		Id_Given=Id_Given  +_IQ(0.00003);
		}
		if(Id_Given>=_IQ(110))  Id_Given=_IQ(110);
	}else
	{
		SysCnt.Binv3cnt=0;
	}
//++++++++++++++++++++++++++++++++++++++++++++//
}


