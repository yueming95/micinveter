################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
cmd/DSP280x_Headers_nonBIOS.exe: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/DSP280x_Headers_nonBIOS.cmd $(GEN_CMDS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Linker'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" -z -m"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/Debug/svpwmtest.map" --stack_size=0x380 --warn_sections -i"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/lib" -i"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" -i"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/svpwm_Two" -i"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM" -i"E:/work/SG50KT4ZA/program/SPWM/include" --reread_libs --display_error_number --diag_wrap=off --xml_link_info="svpwm_Two_linkInfo.xml" --entry_point=_c_int00 --rom_model -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '

cmd/F2808.exe: E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/F2808.cmd $(GEN_CMDS)
	@echo 'Building file: $<'
	@echo 'Invoking: C2000 Linker'
	"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/bin/cl2000" -v28 -ml -g --define="_DEBUG" --define="LARGE_MODEL" --diag_warning=225 --display_error_number --diag_wrap=off --asm_listing --output_all_syms --asm_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" --obj_directory="E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/Debug" -z -m"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/cmd/Debug/svpwmtest.map" --stack_size=0x380 --warn_sections -i"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/lib" -i"C:/ti/ccsv5/tools/compiler/c2000_6.2.0/include" -i"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM/svpwm_Two" -i"E:/work/SG50KT4ZA/program/SPWM/SG50KTWAAC_SPWM" -i"E:/work/SG50KT4ZA/program/SPWM/include" --reread_libs --display_error_number --diag_wrap=off --xml_link_info="svpwm_Two_linkInfo.xml" --entry_point=_c_int00 --rom_model -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


